function [ Out_, Spill_indx, IRF_o, IRF_g, V_decom_o, V_decom_g, stable_ ] = SpillOverDY(VAR_lag, nMA_lags, Dat_, plot_) 
%%
% Spillover analysis using variance-decomposition, i.e. following 
%    the Diebold-Yilmaz approach (http://financialconnectedness.org/research.html). However, in addition to 
%    Cholesky decomposition, I also implement the generalised variance decomposition
%    relying on Peseran-Shin (Economics Letters 1998)
%
%  Input:
%  -------------------------------------------------------------------------------
%  VAR_lag  =  number of lags in the VAR
%  nMA_lags =  horizon at which the Spillovers are calculated
%  Dat_     =  the data ( nObs-by-nSeries )
%  plot_    =  -> 1  IRF and VDs are plotted    ->0  no plotting
%
%  Output:
%  -------------------------------------------------------------------------------
%  Out_   contains the spillovers 'from others' and 'to other' for each variable
%         for orthogonal and generalised variance decompositions
%         [ orthogonal from, orthogonal to, generalised from, generalised to ]
%
%  Spill_indx   is the spillover index  [ orthogonal  generalised]
%
%  The IRF are 3D-arrays containing stacked matrices of: 
%       
%       irf( lags, response of variable{j}, shock to variable{i} )
%   
% Ken Nyholm: 2016
% Ken Nyholm: 2018 (Nov), update to cater for the discontinuation of  
%                         MATLAB's vgx functions. The companion VAR form
%                         is generated and the matching VMA(q) specification
%                         is found.
%

[nObs, nSeries ] = size(Dat_);
spec_new         = varm(nSeries,VAR_lag);
[Est_new ]       = estimate(spec_new, Dat_(VAR_lag+1:end,:), 'Y0', Dat_(1:VAR_lag,:) );
%
% ... Convert VAR to VMA(q) specification 
Rho1              = zeros(nSeries*VAR_lag,nSeries*VAR_lag);
Rho1(1:nSeries,:) = cell2mat(Est_new.AR);                     % setting up the companion form VAR
if ( VAR_lag>2 )
    Rho1(nSeries+1:end,1:(end-nSeries)) = eye((VAR_lag-1)*nSeries);
end

SpecMA.MA{1,1} = eye(nSeries);
SpecMA.MA{2,1} = Rho1(1:nSeries,1:nSeries);
for (j=3:nMA_lags)
    tmp = Rho1^j;
    SpecMA.MA{j,1} = tmp(1:nSeries,1:nSeries);
end
stable_.AReig                       = real(max(eig(Rho1)));

%
% ...  Impulse Response Functions
%
IRF_o  = zeros(nMA_lags,nSeries,nSeries);     % [1:nlags, 1:nvariables, shocked variable ]       
IRF_g  = zeros(nMA_lags,nSeries,nSeries);
IRF_g1 = zeros(nMA_lags,nSeries,nSeries);

P      = chol(Est_new.Covariance,'lower');
sig_jj = diag(Est_new.Covariance);
for ( j=1:nSeries )
    indx_      = zeros(nSeries,1);
    indx_(j,1) = 1;
    for ( k=1:nMA_lags )   % k counts the lag
        IRF_o(k,:,j)  = SpecMA.MA{k}*P*indx_;                              % P-S eqn 7
        IRF_g1(k,:,j) = SpecMA.MA{k}*Est_new.Covariance*indx_;  
        IRF_g(k,:,j)  = sig_jj(j,1).^(-0.5).*IRF_g1(k,:,j);                % P-S eqn 10    
    end
end
%
% ...  Variance Decompositions
%
VD_o1     = zeros(nMA_lags,nSeries,nSeries);     % [1:nlags, 1:nvariables, shocked variable 1:n ]
VD_o      = zeros(nMA_lags,nSeries,nSeries);
VD_oa     = zeros(nMA_lags,nSeries,nSeries);
VD_g1     = zeros(nMA_lags,nSeries,nSeries);
VD_g      = zeros(nMA_lags,nSeries,nSeries);

denom_tmp = zeros(nMA_lags,nSeries);
denom     = zeros(nMA_lags,nSeries);

for ( k=1:nMA_lags )  % diagonal elements of denominator on P-S p.20
    denom_tmp(k,:) = diag(SpecMA.MA{k}*Est_new.Covariance*SpecMA.MA{k}');
end
denom = cumsum(denom_tmp,1);

VD_o1   = cumsum(IRF_o.^2);    % column-wise cumsum of the squared IRF P-S p.20
VD_g1   = cumsum(IRF_g.^2);
denom_o = sum(VD_o1,3);
denom_g = sum(VD_g1,3);
%  dim(IRF) = nHorizon, nSeries, nSeries and is organised as 
%             nHorizon, Response Variables (in each columns), shocked Variables (in each 3d layer) 
%
for (j=1:nSeries)
    VD_oa(:,:,j) = VD_o1(:,:,j)./ denom;  
    VD_o(:,:,j)  = VD_o1(:,:,j)./ denom_o;     
    VD_g(:,:,j)  = VD_g1(:,:,j)./ denom_g;    % using the definition from Lanne et al
end                                                             

%% Plotting
if (plot_==1)
    figure
    title('IRF - Cholesky')
    n=1;
    for ( j=1:nSeries )        % ... x-axis=shocks  and  y-axis  responses
        for ( k=1:nSeries )
            subplot(nSeries,nSeries,n), plot( squeeze(IRF_o(:,j,k)) )
            str_=['Resp ', num2str(j), ' ', ' shk ', num2str(k)];
            title(str_)
            n=n+1;
        end
    end

    % figure
    % title('CUMSUM IRF - Cholesky')
    % n=1;
    % for ( j=1:nSeries )        % ... x-axis=shocks  and  y-axis  responses
    %     for ( k=1:nSeries )
    %         subplot(nSeries,nSeries,n), plot( cumsum(squeeze(IRF_o(:,j,k))) )
    %         str_=['CumResp ', num2str(j), ' ', ' shk ', num2str(k)];
    %         title(str_)
    %         n=n+1;
    %     end
    % end

    figure
    title('IRF - Generalised')
    n=1;
    for ( j=1:nSeries )        % ... x-axis=shocks  and  y-axis  responses
        for ( k=1:nSeries )
            subplot(nSeries,nSeries,n), plot( squeeze(IRF_g(:,j,k)) )
            str_=['Resp ', num2str(j), ' ', ' shk ', num2str(k)];
            title(str_)
            n=n+1;
        end
    end

    % figure
    % title('CUMIRF - Generalised')
    % n=1;
    % for ( j=1:nSeries )        % ... x-axis=shocks  and  y-axis  responses
    %     for ( k=1:nSeries )
    %         subplot(nSeries,nSeries,n), plot( cumsum(squeeze(IRF_g(:,j,k))) )
    %         str_=['CumResp ', num2str(j), ' ', ' shk ', num2str(k)];
    %         title(str_)
    %         n=n+1;
    %     end
    % end
    % 
    % figure
    % title('VD - Cholesky')
    % n=1;
    % for ( j=1:nSeries )
    %     for ( k=1:nSeries )
    %         subplot(nSeries,nSeries,n), plot( 100.*squeeze(VD_oa(:,j,k)) )
    %         str_=['Resp ', num2str(j), ' ', ' shk ', num2str(k)];
    %         title(str_)
    %         n=n+1;
    %     end
    % end


    figure
    title('VD - Cholesky')
    n=1;
    for ( j=1:nSeries )
        for ( k=1:nSeries )
            subplot(nSeries,nSeries,n), plot( 100.*squeeze(VD_o(:,j,k)) )
            str_=['Resp ', num2str(j), ' ', ' shk ', num2str(k)];
            title(str_)
            n=n+1;
        end
    end

    figure
    title('VD - Generalised')
    n=1;
    for ( j=1:nSeries )
        for ( k=1:nSeries )
            subplot(nSeries,nSeries,n), plot( 100.*squeeze(VD_g(:,j,k)) )
            str_=['Resp ', num2str(j), ' ', ' shk ', num2str(k)];
            title(str_)
            n=n+1;
        end
    end
end
%% Spillover calculation following Diebold-Yilmaz(2009)
%
Spill_o_from = zeros(nSeries,nMA_lags);
Spill_o_to   = zeros(nSeries,nMA_lags);
Spill_g_from = zeros(nSeries,nMA_lags);
Spill_g_to   = zeros(nSeries,nMA_lags);

for (j=1:nMA_lags)
    Spill_o_from(:,j) = sum( squeeze(VD_o(j,:,:)),2)-diag(squeeze(VD_o(j,:,:)));
    Spill_o_to(:,j)   = sum( squeeze(VD_o(j,:,:)),1)'-diag(squeeze(VD_o(j,:,:)));
    Spill_g_from(:,j) = sum( squeeze(VD_g(j,:,:)),2)-diag(squeeze(VD_g(j,:,:)));
    Spill_g_to(:,j)   = sum( squeeze(VD_g(j,:,:)),1)'-diag(squeeze(VD_g(j,:,:)));   
end

indx_o = sum(Spill_o_from(:,nMA_lags),1)/(sum(diag(squeeze(VD_o(nMA_lags,:,:))))+sum(Spill_o_from(:,nMA_lags),1) );
indx_g = sum(Spill_g_from(:,nMA_lags),1)/(sum(diag(squeeze(VD_g(nMA_lags,:,:))))+sum(Spill_g_from(:,nMA_lags),1) );

% disp('')
% disp('Summary')
% disp('')
% disp('SpilOver From - Cholesky, Generalised')
% disp(round([Spill_o_from(:,end) Spill_g_from(:,end)].*100,0) )
% disp('')
% disp('')
% disp('SpilOver To - Cholesky, Generalised')
% disp(round([Spill_o_to(:,end) Spill_g_to(:,end)].*100) )

Out_       = [ Spill_o_from(:,nMA_lags) Spill_o_to(:,nMA_lags) Spill_g_from(:,nMA_lags) Spill_g_to(:,nMA_lags) ];
Spill_indx = [indx_o; indx_g];

V_decom_o  = squeeze(VD_o(nMA_lags,:,:));
V_decom_g  = squeeze(VD_g(nMA_lags,:,:));







