%% Calling the Diebold Yilmaz function 
%
% The Diebold-Yilmaz Spillover index and metrics are calculated using example data similar to that 
% used in Diebold&Yilmaz(2009). The excel sheet contains 19 equity return and volatility series. 
% 
% Ken Nyholm: 2016
% Ken Nyholm: Updates Nov, 2018
%
warning('off','all');
% ........USER INPUT...............
nPred   = 4;                        % Insert here the prediction horizon
wl      = 104-1;                    % number of observations in a window minus 1
step_   = 50;                        % number of days between each window (i.e. the step length)
nLags   = 2;                        % number of lags in the VAR model
% .................................

disp('... Loading Data')  % insert the path, excel sheet name, and range that contain the relevant data:
load('diebold_yilmaz.mat')

disp('... Done')
dat_         = returns;         % insert here the data that forms the basis for the spill-over analysis   
[nObs,nVars] = size(dat_);

figure
    plot(dat_),title('Data')

%% Rolling-Window Estimation
%
start_ = flipud((nObs-wl:-step_:1)');
slut_  = start_+wl; 
nIter  = length(start_);
%%
% In total there are then a total of sub-period estimations equal to:
% disp(nIter)

% %%  Optimal lag-length for the full VAR
% % 
% p_lags   = zeros(nIter,2);
% lags_    = 4;
% h        = waitbar(0,'...Finding the optimal lag length...');
% for ( k= 1:nIter )
%     waitbar(k/nIter,h)
%     opti_Lag = zeros(lags_,4);
%     wData    = dat_(start_(k,1):slut_(k,1),:);
%     for ( j = 1:lags_ )
%             Model_1    = [];
%             Est_Model1 = [];
%             Model_1 = varm(nVars,j);
%             [Est_Model1, Est_StdErrs1, LLF1, W1] = estimate( Model_1, wData(j+1:end,:), 'Y0', wData(1:j,:) );
%             temp_     = summarize(Est_Model1);
%             opti_Lag(j,:) = [ j, temp_.AIC, temp_.BIC, isstable(Est_Model1) ];
%     end
%     disp(' ')
%     disp('     ... Optimal Lag length... ')
%     disp('     Lag      AIC        BIC     isStable   isInvertible')
%     disp(opti_Lag)  
%     opt_AIC     = find(opti_Lag(:,2)==min(opti_Lag(:,2)));
%     opt_BIC     = find(opti_Lag(:,3)==min(opti_Lag(:,3)));
%     p_lags(k,:) = [ opt_AIC opt_BIC ]; 
% end
% figure
%     hist(p_lags(:,1),lags_), title('AIC')
% figure
%     hist(p_lags(:,2),lags_), title('BIC')

    
%% Spillover for the full sample
%
[ Out_, Spill_indx, IRF_o, IRF_g, FS_V_decom_o, FS_V_decom_g ] = SpillOverDY(nLags, nPred, dat_, 0);

%% Rolling-Window calculations
% This section performs the rolling-window calculations. It calls the sub-function "SpillOverDY" which 
% performs the VAR estimation, calculates IRFs and variance decompositions, and calculates the spillover
% indices. 
%help SpillOverDY

%%
% Calculations are performed for generalised and orthogonalised IRFs/Variance decompositions.
%
Decom_g = zeros(nVars,nVars,nIter);
Decom_o = zeros(nVars,nVars,nIter);
indx_g  = zeros(nIter,1);
indx_o  = zeros(nIter,1);
max_eig = zeros(nIter,1);
h       = waitbar(0,'Calculating SpillOvers...');
for ( j=1:nIter )
    waitbar(j/nIter,h)
    wData  = dat_(start_(j,1):slut_(j,1),:);
    [ Out_, Spill_indx, IRF_o, IRF_g, V_decom_o, V_decom_g, stable_ ] = SpillOverDY(nLags, nPred, wData, 0);
    Decom_o(:,:,j) = V_decom_o.*100;     
    Decom_g(:,:,j) = V_decom_g.*100;
    indx_o(j,1)    = Spill_indx(1,1)*100;
    indx_g(j,1)    = Spill_indx(2,1)*100;
    max_eig(j,1)   = max(abs(stable_.AReig));
end
close(h)
%% Generating Output
%
% The spillover indices are calculated and presented for calculations based on generalised and orthogonal
% impulse-responses/variance decompositions.
%
% Plots that read: "(spillovers) to Others" show the results of the variance decompositions in terms of how 
% much of the variability one variable contribute to the variability of other variables.
%
% Plots that read: "(spillovers) from Others" show how other variables contribute to the variability of one 
% particular variable. These plots are therefore summing to 100%.
%

Variable1_toOthers_g  = squeeze(Decom_g([1:nVars ],1,:))';
Variable2_toOthers_g  = squeeze(Decom_g([1:nVars ],2,:))';
Variable3_toOthers_g  = squeeze(Decom_g([1:nVars ],3,:))';
Variable4_toOthers_g  = squeeze(Decom_g([1:nVars ],4,:))';

Variable1_fromOthers_g  = squeeze(Decom_g(1,[1:nVars ],:))';
Variable2_fromOthers_g  = squeeze(Decom_g(2,[1:nVars  ],:))';
Variable3_fromOthers_g  = squeeze(Decom_g(3,[1:nVars  ],:))';
Variable4_fromOthers_g  = squeeze(Decom_g(4,[1:nVars  ],:))';

% ... Example Plots
figure
    plot([indx_g ] ), title('SpillOver Index'), legend('Generalised','Location','SouthOutside','Orientation','Horizontal')
   
% %
% %... plot of - spillovers TO others -
% %
figure
    area(Variable1_toOthers_g), title('Variable 1 to others'),
    
%figure
%    area(dates_(wl+1:end,1), Variable2_toOthers_g), title('From Variable 2 to All Others'), 
%    datetick('x','keepticks','keeplimits')
    
%    
%... plot of - spillovers FROM others -
%
figure
    area(Variable1_fromOthers_g), title('Variable 1 from All Others'), 
    
    
    