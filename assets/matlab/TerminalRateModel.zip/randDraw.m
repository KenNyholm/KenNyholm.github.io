% Parameters
m = pDiag;  % Mean vector
S = pPhiCov;  % Covariance matrix

% Step 2: Calculate critical value for 99% confidence level
d = size(m, 1);  % Dimensionality
alpha = 0.05;  % Significance level (1 - confidence level)
critical_value = chi2inv(1 - alpha, d);

% Step 3: Cholesky decomposition of the covariance matrix
L = chol(S, 'lower');

% Step 4: Generate independent standard normal random variables
z = randn(d, 1);

% Step 5: Transform standard normal variables to multivariate normal
x = m + L * z;

% Confidence Cone
radius = sqrt(critical_value) * sqrt(diag(S));  % Radius of the confidence cone
cone_lower = m - radius;  % Lower bound of the confidence cone
cone_upper = m + radius;  % Upper bound of the confidence cone

% Display the results
disp("Random draw from a multivariate normal distribution:");
disp(x);
disp("99% Confidence Cone:");
disp("Lower Bound:");
disp(cone_lower);
disp("Upper Bound:");
disp(cone_upper);

