%% Generating results for the paper: On term premia 2023
% Requires:
%   TPdata.mat
%   TSM_est.m  
%   ACM.m 
%
% author: KN 25-Jul-2023
%
rng(42)
%% The following term structure models can be estimated using the TSM_est class:
%  .getSAA          -> Short rate based model with the slope and curvature of the term structure of 
%                      term premia as factors, and a long term attraction point for the short rate (C*)
%  .getDNS          -> Dynamic Nelson-Siegel model and related metrics
%  .getJSZ          -> Joslin, Singleton, Zhu (2011)
% 
% The ACM model is estimated using the code: ACM.m
% 
% Lineplots are generated using: lineplot.m

%% Loading data
clear
clc
load('TPdata.mat');
startDate  = datetime('30-Jun-1961');
Y          = GSWmonthly(GSWmonthly.time>=startDate,:)./100;
dates      = Y.time;
RstarNominal = interp1(datenum(LW_rstar.time),LW_rstar.rstar,datenum(dates),'pchip')+2;
RstarConst   = ones(size(RstarNominal,1),1)*2+2;


%% ... estimate the yield curve models
% 
YCM              = TSM_estimate_local;                     % create an instance of the TSM_est class
YCM.Yields       = [Y.m3, Y.m12, Y.m24, Y.m36, Y.m48, Y.m60, Y.m72, Y.m84, Y.m96, Y.m108, Y.m120];                          
YCM.dataRange    = Y.time; 
YCM.tau          = [3 12:12:120 ]';                  
YCM.nTau         = size(YCM.tau,1);

YCM.dataFreq     = 12;      % monthly data frequency
YCM.nF           =  3;      % 3 yield curve factors in addition to C*
% ... estimate term structure models with 3 factors
%
DNS  = YCM.getDNS;    % dynamic nelson-siegel
JSZ  = YCM.getJSZ;    % Joslin, Singleton, Zhu

% ... estimate the ACM model
ACM

% ... estimate the terminal-rate model with different attraction points for the short rate
SAA_DNS            = YCM;
SAA_DNS.Cstar      = DNS.Er(:,end);
SAA_DNS.gridSearch = 1;
SAA_DNS = SAA_DNS.getSAA;

SAA_JSZ            = YCM;
SAA_JSZ.Cstar      = JSZ.Er(:,end);
SAA_JSZ.gridSearch = 1;
SAA_JSZ = SAA_JSZ.getSAA;

SAA_ACM            = YCM;
SAA_ACM.Cstar      = ACM_Er(:,end);
SAA_ACM.gridSearch = 1;
SAA_ACM = SAA_ACM.getSAA;

SAA_HLW            = YCM;
SAA_HLW.Cstar      = RstarNominal./100;
SAA_HLW.gridSearch = 1;
SAA_HLW = SAA_HLW.getSAA;

SAA_const          = YCM;
SAA_const.Cstar    = RstarConst./100;
SAA_const.gridSearch = 1;
SAA_const = SAA_const.getSAA;

% ... TP replication errors
%
DNS_RMSRE = sqrt(mean((DNS.TP-SAA_DNS.TP).^2));
JSZ_RMSRE = sqrt(mean((JSZ.TP-SAA_JSZ.TP).^2));
ACM_RMSRE = sqrt(mean((ACM_TP(:,[3 12:12:120])-SAA_ACM.TP).^2));

%% ... Output

% ... Term premia and expectations for each model
%
plt.title      = []; %'GSW data';
plt.ylabel     = 'Yield (%)'; 
plt.legend     = {'3m','1y','2y','3y','4y','5y','6y','7y','8y','9y','10y'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, YCM.Yields.*100, plt)
%print -depsc data

plt.title      = []; %'10y term premia';
plt.ylabel     = 'Yield (%)'; 
plt.legend     = {'DNS','JSZ','ACM'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [DNS.TP(:,end), JSZ.TP(:,end), ACM_TP(:,end)].*100, plt)
%print -depsc premia

plt.title      = []; %'10y expectations';
plt.ylabel     = 'Yield (%)'; 
plt.legend     = {'DNS','JSZ','ACM'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [DNS.Er(:,end), JSZ.Er(:,end), ACM_Er(:,end)].*100, plt)
%print -depsc expectations

% ... replicated using the terminal-rate model with C* set equal to each model's 10Y rate expectation
%
plt.title      = []; %'DNS, 10y term premia';
plt.ylabel     = '%'; 
plt.legend     = {'DNS','Replication'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [DNS.TP(:,end), SAA_DNS.TP(:,end)].*100, plt)
%print -depsc dnsReplication

plt.title      = []; %'JSZ, 10y term premia';
plt.ylabel     = '%'; 
plt.legend     = {'JSZ','Replication'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [JSZ.TP(:,end), SAA_JSZ.TP(:,end)].*100, plt)
%print -depsc jszReplication

plt.title      = []; %'ACM, 10y term premia';
plt.ylabel     = '%'; 
plt.legend     = {'ACM','Replication'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [ACM_TP(:,end), SAA_ACM.TP(:,end)].*100, plt)
%print -depsc acmReplication

plt.title      = [];  %'DNS, short rate fit';
plt.ylabel     = '(%)'; 
plt.legend     = {'Obs','DNS','JSZ','ACM'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [DNS.Yields(:,1), DNS.Yields_fit(:,1), JSZ.Yields_fit(:,1), ACM_Yfit(:,3)].*100, plt)

plt.title      = []; %'ACM, 10y term premia';
plt.ylabel     = '%'; 
plt.legend     = {'JSZ', 'LW', 'Const'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [SAA_JSZ.TP(:,end), SAA_HLW.TP(:,end), SAA_const.TP(:,end)].*100, plt)
%print -depsc TPcomparison

plt.title      = []; %'Comparing rate convergence points estimates from the terminal rate model';
plt.ylabel     = '%'; 
plt.legend     = {'JSZ', 'LW-estimate', 'R* nominal'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [SAA_JSZ.Er(:,end), SAA_HLW.Er(:,end), RstarNominal./100].*100, plt)
%print -depsc ExpectedRatecomparison

plt.title      = []; %'Comparing rate convergence points estimates from the terminal rate model';
plt.ylabel     = '%'; 
plt.legend     = {'JSZ', 'LW-estimate', 'R* nominal'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [SAA_JSZ.TP(:,end), SAA_HLW.TP(:,end)].*100, plt)
%print -depsc TPcomparison

plt.title      = []; %'Short rate attraction points';
plt.ylabel     = '%'; 
plt.legend     = {'LW', 'Const'};
plt.dateformat = 'yyyy'; 
plt.font       = 'consolas'; 
plt.fontsize   = 16;
plt.linewidth  = 2;
lineplot(YCM.dataRange, [RstarNominal, RstarConst], plt)
%print -depsc TPcomparison


% ... RMSE of the estimated models
%
RMSE_tab1 = table([DNS.RMSE; JSZ.RMSE; ACM_RMSE].*10000);        % RMSE in bps 
RMSE_tab2 = table([SAA_DNS.RMSE; SAA_JSZ.RMSE; SAA_ACM.RMSE].*10000);
RMSRE     = table([DNS_RMSRE; JSZ_RMSRE; ACM_RMSRE].*10000);

%% ... calculating sensitivities of the 10y term premium to the input parameters
% %
% nObs       = size(JSZ.Yields_fit,1);
% % ... using a state-space model to estimate the covariance between m and Phi parameters
% % 
% p0  = [ 0;     0;      0;    0;
%         0.5;  
%         0.95;  0;      0;
%         0;     0.95;   0;
%         0;     0;      0.95;
%         0.01;  0.01;   0.01;
%         0.05;
%         0.05;
%         0.05 ];
% 
% options = optimoptions('fmincon','Display','iter','MaxFunctionEvaluations',1e5);
% Dat    = [JSZ.Yields(:,1), JSZ.Factors.*100, ones(nObs,1)];
% mdl    = ssm(@(p0) paramMap(p0));
% [estMdl, estParams, estParamCov, logL, Output] = estimate(mdl,Dat,p0,'CovMethod','sandwich','options',options);
% pPhi    = JSZ.PhiP;
% pDiag   = diag(pPhi);
% pPhiCov = estParamCov([6,10,14],[6,10,14]);    % covariances between the diagonal of Phi
% kP      = JSZ.kP;
% kCov    = estParamCov([1:3],[1:3]);
% mAR     = kP;
% S       = kCov;
% % ... uncertainty on PhiP
% %mAR = pDiag;    % Mean vector
% %S = pPhiCov;    % Covariance matrix
% 
% % ... calculating the sensitivity of the 10y term premium to the input parameters
% %
% nScenarios = 1e3;
% TPscenario = NaN(nObs,nScenarios);
% f = waitbar(0,'Iterating');
% for (k=1:nScenarios)
%     waitbar(k/nScenarios)
%     n   = 120;
%     rho = JSZ.rho1;
%     xx  = drawMean(mAR,S,0.01);
%     %m   = JSZ.kP;                                    % testing sensitivity to Phi
%     %PP  = JSZ.PhiP-diag(diag(JSZ.PhiP))+diag(xx);
%     %m   = [xx(1,1);JSZ.kP(2:3,1)];                    % testing sensitivity to m
%     PP  = JSZ.PhiP;
%     m   = [JSZ.kP(1,1)+randn()*norminv(0.10)*sqrt(S(1,1)); JSZ.kP(2:3,1)];
%     p   = [m(:);PP(:)];
%     for (j=1:nObs)      
%         y   = JSZ.Yields_fit(j,end);
%         r   = JSZ.Yields_fit(j,1);
%         X   = JSZ.Factors(j,:)';
%         fun = @(p) termpremiumN(p,y,n,r,rho,X);
%         TPscenario(j,k) = fun(p);     
%     end
% end
% close(f)
% TP = JSZ.TP(:,end);
% TPmax_ = max(TPscenario,[],2);
% TPmin_ = min(TPscenario,[],2);
% 
% % ... checking visually that the TP estimates from above is equal to the ones
% %     calculated by the main code TSM_estimate.m
% plt.title      = 'JSZ, 10y term premium';
% plt.ylabel     = '%'; 
% plt.legend     = [];
% plt.dateformat = 'yyyy'; 
% plt.font       = 'consolas'; 
% plt.fontsize   = 16;
% plt.linewidth  = 2;
% lineplot(YCM.dataRange, [TP, TPmax_, TPmin_], plt)

%% Helper functions
%
function [A,B,C,D,Mean0,Cov0,StateType] = paramMap(p) 
%
% setting up the state-space model to determine the covariance matrix of
% the parameters
%
    A = [ p(6)  p(7)   p(8)   p(15) ;
          p(9)  p(10)  p(11)  p(16) ;
          p(12) p(13)  p(14)  p(17) ;
          0     0      0      1     ];

    B = [ p(18)  0      0      ;
          0      p(19)  0      ;
          0      0      p(20)  ;
          0      0      0      ];
    
    C = [ p(1) p(2)  p(3)   p(4) ;
          1     0     0     0 ;
          0     1     0     0 ;
          0     0     1     0 ;
          0     0     0     1 ];

    D = [ p(5); 0; 0; 0; 0];

    Mean0 = [];
    Cov0  = [];
    StateType = [0 0 0 1];
end

function [TP] = termpremiumN(phat,y,n,r,rho,X)
%
% calculates the term premium at maturity n
% input: 
%        y   - fitted yield at maturity n 
%        n   - maturity in months, e.g n=120
%        r   - short rate at time t
%        rho - r = rho'*X
%        m   - mean(X)
%        Phi - VAR(1) matrix of autoregressive coefficients
%        X   - factor observations at time t
%    
    m = [ phat(1);phat(2);phat(3)];
    Phi = [ phat(4), phat(7), phat(10);
            phat(5), phat(8), phat(11);
            phat(6), phat(9), phat(12) ];
    TP = y-1/n*(r+rho'*(m.*(n-1)+(Phi^n-Phi)*(Phi-eye(3))^-1 * (X-m))); 
end

function [x] = drawMean(m,S,cl) 
% calculates a mean that is within the 1-alpha cone
% alpha is the Significance level (1 - confidence level), e.g. cl=0.05%
    ok = 0;
    while (ok==0)
        % Step 1: Calculate critical value for 99% confidence level
        d = size(m, 1);  % Dimensionality
        
        critical_value = chi2inv(cl, d);

        % Step 2: Cholesky decomposition of the covariance matrix
        L = chol(S, 'lower');

        % Step 3: Generate independent standard normal random variables
        z = randn(d, 1);

        % Step 4: Transform standard normal variables to multivariate normal
        x = m + L * z;

        % Confidence Cone
        radius = sqrt(critical_value) * sqrt(diag(S));  % Radius of the confidence cone
        cone_lower = m - radius;  % Lower bound of the confidence cone
        cone_upper = m + radius;  % Upper bound of the confidence cone
        if (x<cone_upper & x>cone_lower)
            ok=1;
        end
    end
end