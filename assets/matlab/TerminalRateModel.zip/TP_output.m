%% Generating plots for the paper on the uncertainty of term premium estimates
%  
% calculating 1,5,10,90,95,99 percentiles of the TP calculations
clear
clc
%
load('TPsummary.mat')
%
p = [0.5,5,95,99.5];
TP25Y = prctile(TP25,p,2)-mean(TP25,2)+TPfullSample.TP(:,end);
TP30Y = prctile(TP30,p,2)-mean(TP30,2)+TPfullSample.TP(:,end);
TP40Y = prctile(TP40,p,2)-mean(TP40,2)+TPfullSample.TP(:,end);
TP50Y = prctile(TP50,p,2)-mean(TP50,2)+TPfullSample.TP(:,end);
TP60Y = prctile(TP60,p,2)-mean(TP60,2)+TPfullSample.TP(:,end);

avg_diff = [ mean(TP25Y(:,4)-TP25Y(:,1)), mean(TP25Y(:,3)-TP25Y(:,2)) ;
               std(TP25Y(:,4)-TP25Y(:,1)), std(TP25Y(:,3)-TP25Y(:,2)) ;
             mean(TP30Y(:,4)-TP30Y(:,1)), mean(TP30Y(:,3)-TP30Y(:,2)) ;
               std(TP30Y(:,4)-TP30Y(:,1)), std(TP30Y(:,3)-TP30Y(:,2)); 
             mean(TP40Y(:,4)-TP40Y(:,1)), mean(TP40Y(:,3)-TP40Y(:,2)) ;
               std(TP40Y(:,4)-TP40Y(:,1)), std(TP40Y(:,3)-TP40Y(:,2));
             mean(TP50Y(:,4)-TP50Y(:,1)), mean(TP50Y(:,3)-TP50Y(:,2)) ;
               std(TP50Y(:,4)-TP50Y(:,1)), std(TP50Y(:,3)-TP50Y(:,2))]*10000;  % in basis points

figure
    plot(TPfullSample.dataRange,TPfullSample.TP(:,end)*100,'LineWidth',2,'Color',[0,0.196078431372549,0.6])
    hold on
    plot(TPfullSample.dataRange,TP25Y(:,[1,4])*100,'LineWidth',1,'Color',[0.882352941176471,0.705882352941177,0] )
    hold on
    plot(TPfullSample.dataRange,TP25Y(:,[2,3])*100,'LineWidth',1,'Color',[0.882352941176471	0.294117647058824 0] )
    legend('Full sample', '0.5%', '99.5%','5%','95%')
    ylabel('Percent')
    set(gcf,'position',[25 25 898 690])
    print -depsc TP25Ysample

figure
    plot(TPfullSample.dataRange,TPfullSample.TP(:,end)*100,'LineWidth',2,'Color',[0,0.196078431372549,0.6])
    hold on
    plot(TPfullSample.dataRange,TP50Y(:,[1,4])*100,'LineWidth',1,'Color',[0.882352941176471,0.705882352941177,0] )
    hold on
    plot(TPfullSample.dataRange,TP50Y(:,[2,3])*100,'LineWidth',1,'Color',[0.882352941176471	0.294117647058824 0] )
    legend('Full sample', '0.5%', '99.5%','5%','95%')
    ylabel('Percent')
    set(gcf,'position',[25 25 898 690])
    print -depsc TP50Ysample

    % colororder([0 0.196078431372549 0.6;
    %       0.882352941176471	0.705882352941177 0;
    %       0.882352941176471	0.294117647058824 0;
    %       0.396078431372549	0.721568627450980 0;
    %       0 0.694117647058824 0.917647058823529;
    %       0 0.470588235294118 0.0862745098039216;
    %       0.505882352941176	0.223529411764706 0.776470588235294;
    %       0.360784313725490	0.360784313725490 0.360784313725490;
    %       0.596078431372549	0.631372549019608 0.815686274509804;
    %       0.992156862745098	0.866666666666667 0.654901960784314;
    %       0.964705882352941	0.694117647058824 0.513725490196078;
    %       0.807843137254902	0.882352941176471 0.686274509803922;
    %       0.843137254901961	0.933333333333333 0.972549019607843;
    %       0.552941176470588	0.721568627450980 0.552941176470588;
    %       0.682352941176471	0.592156862745098 0.780392156862745;
    %       0.662745098039216	0.662745098039216 0.662745098039216;
    %       0.815789473684211	0.815789473684211 0.815789473684211;
    %       0 0 0]);      