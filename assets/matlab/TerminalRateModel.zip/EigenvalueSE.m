A     = JSZ.PhiP; 
S     = 
[V,d] = eig(A);

pA  = A(:);
fun = @(pA) eigenFun(pA,V);
jac = jacobianest(fun,pA);

function D = eigenFun(pA,V)
% calculates the eigenvalues from the matrix A and the matrix of eigen vectors 
% this is needed to approximate the stderr on the eigenvalues
    A = [pA(1) pA(4) pA(7);
         pA(2) pA(5) pA(8);
         pA(3) pA(6) pA(9) ];
    D = V^-1 * A * V;
end