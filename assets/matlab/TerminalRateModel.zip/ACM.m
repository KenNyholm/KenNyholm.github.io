%% ACM, JFE 2013
% replicating the Adrian, Crump, Moench model for pricing the term structure with linear regressions
% author: KN
% date: 15-June-2023
%

%% load data
K = 3;                               % number of extracted principal components
n = [3,12:12:120];           % [6, 12, 18, 24:12:120];          % Use excess returns at these maturities to estimate the model.
N = size(n,2);                       % number of maturities
nAll = (1:1:120)./12;
NAll = size(nAll,2);
% Load data
Ytmp      = Y;                       % this data set is prepared in the code: TermPremia.m - run TermPremia.m before ACM.m
dates     = Ytmp.time;
Y         = Ytmp{:,:};
T         = size(Y, 1)-1;             
logPrices = -Y.*nAll;
rf        = -logPrices(1:end-1, 1);
rx        = logPrices(2:end, 1:end-1) - logPrices(1:end-1, 2:end) - rf;  % 1m excess returns for n=2:120 

%% Extract principal components
[loadings, PC] = pca(Y(:,n));
X = PC(:, 1:K);

%% step 1: VAR(1) on principal components 
VAR = varm(size(X,2),1);        
[Est,EstSE,logL,err] = estimate(VAR,X);
mu  = Est.Constant;
phi = Est.AR{1,1};
Sigma = Est.Covariance;

%% step 2: regress log excess returns on the factors 
a = nan(K,1);
b = nan(N,K);
c = nan(K,K);
e = nan(T,K);
for (j=1:N)
    tmp    = fitlm([err,X(1:end-1,:)], rx(:,n(j)-1) );
    a(j,:) = table2array(tmp.Coefficients(1,1));
    b(j,:) = table2array(tmp.Coefficients(2:K+1,1));
    c(j,:) = table2array(tmp.Coefficients(K+2:2*K+1,1));
    e(:,j) = tmp.Residuals.Raw;
end
b=b';
sigma = trace(e*e')/(N*T); 

%% step 3: determining lambda0 and lambda1
Bstar = nan(N,K^2); 
for (j=1:N)
    tmp = b(:,j)*b(:,j)';
    Bstar(j,:) = tmp(:)';
end
lambda0 = b'\(a + 0.5*(Bstar*Sigma(:) + sigma*ones(N,1) ));
lambda1 = b'\c;

%% determine bond prices and yields
%
delta  = fitlm(X(1:end-1,:),rf);    % regress rf on the factors to determine delta0 and delta1
delta0 = table2array(delta.Coefficients(1,1));
delta1 = table2array(delta.Coefficients(2:end,1));
A = zeros(1, NAll);
BT = zeros(K, NAll)';               % B transposed
A(1, 1)  = -delta0;
BT(1,:)  = -delta1';
Arf  = A;                           
BTrf = BT;                          % for the expectations curve

for (j=1:NAll-1)
    A(1, j+1) = A(1, j) + BT(j,:)*(mu-lambda0)+0.5*(BT(j,:)*Sigma*BT(j,:)'+ sigma) - delta0;
    BT(j+1,:) = BT(j,:)*(phi - lambda1) - delta1';
    Arf(1, j+1) = Arf(1, j) + BTrf(j,:)*(mu)+0.5*(BTrf(j,:)*Sigma*BTrf(j,:)'+ sigma) - delta0;
    BTrf(j+1,:) = BTrf(j,:)*(phi) - delta1';
end
a    = (A./nAll)';
bt   = BT./nAll';
arf  = (Arf./nAll)';
btrf = BTrf./nAll';

% Construct fitted yields
fitLogP   = (a + bt*X')';
fitLogPrf = (arf + btrf*X')'; 
ACM_Yfit      = -fitLogP;
ACM_Er    = -fitLogPrf;
ACM_TP    = ACM_Yfit-ACM_Er;
ACM_Yield_errors    = Y-ACM_Yfit;
RMSE      = sqrt(mean(ACM_Yield_errors.^2)); 
ACM_RMSE  = RMSE(:,[3 12:12:120]);

%% calculating the expectations curve on the basis of the dynamics of the short rate
ARsr   = varm(1,12);   
Est_sr = estimate(ARsr,ACM_Yfit(:,3));
ACM_Er_sr = NaN(T+1,NAll);
for (j=1:T+1)
    tmp            = forecast(Est_sr,NAll,ACM_Yfit(j,1:12)');
    ACM_Er_sr(j,:) = cumsum(tmp)./(1:1:NAll)';
end
ACM_TP_sr = ACM_Yfit-ACM_Er_sr;




