%% Generating results for the paper: On term premia 2023
% Requires:
%   TPdata.mat
%   TSM_est.m  
%   ACM.m 
%
% author: KN 7-Jul-2023
%
rng(555)
%% The following term structure models can be estimated using the TSM_est class:
%  .getSAA          -> Short rate based model with the slope and curvature of the term structure of 
%                      term premia as factors, and a long term attraction point for the short rate (C*)
%  .getDNS          -> Dynamic Nelson-Siegel model and related metrics
%  .getJSZ          -> Joslin, Singleton, Zhu (2011)
% 
% The ACM model is estimated using the code: ACM.m
% 
% Lineplots are generated using: lineplot.m

%% Loading data
clear
clc
load('TPdata.mat');
startDate  = datetime('30-Jun-1961');
Y     = GSWmonthly(GSWmonthly.time>=startDate,:)./100;
dates = Y.time;

%% ... estimate the yield curve models
% 
YCM              = TSM_estimate_local;                     % create an instance of the TSM_est class
YCM.Yields       = [Y.m3, Y.m12, Y.m24, Y.m36, Y.m60, Y.m84, Y.m120];                          
YCM.dataRange    = Y.time; 
YCM.tau          = [3, 12, 24, 36, 60, 84, 120 ]';                  
YCM.nTau         = size(YCM.tau,1);

YCM.dataFreq     = 12;      % monthly data frequency
YCM.nF           =  3;      % 3 yield curve factors in addition to C*
sampleSize       = 12*30;
JSZALL           = YCM.getJSZ;    % Joslin, Singleton, Zhu
F                = JSZALL.Factors;
nObs             = size(F,1);
nRep             = nObs-sampleSize;
TPscenario       = NaN(nObs,nRep);
estFlag          = NaN(nRep,1);
Y                = YCM.Yields;      %[Y.m3, Y.m12, Y.m24, Y.m36, Y.m48, Y.m60, Y.m72, Y.m84, Y.m96, Y.m108, Y.m120];
f = waitbar(0,'Iterating');  
for (k=1:nRep)
    waitbar(k/nRep)
    YCM.Yields   = Y(k:k+sampleSize,:); 
    JSZ          = YCM.getJSZ;
    estFlag(k,1) = JSZ.estFlag; 
    p            = [JSZ.kP(:);JSZ.PhiP(:)];
    for (j=1:nObs)
        TPscenario(j,k) = termpremiumN(p,Y(j,end),120,Y(j,1),JSZ.rho1,JSZALL.Factors(j,:)');
    end
end
close(f)

function [TP] = termpremiumN(phat,y,n,r,rho,X)
%
% calculates the term premium at maturity n
% input: 
%        y   - fitted yield at maturity n 
%        n   - maturity in months, e.g n=120
%        r   - short rate at time t
%        rho - r = rho'*X
%        m   - mean(X)
%        Phi - VAR(1) matrix of autoregressive coefficients
%        X   - factor observations at time t
%    
    m = [ phat(1);phat(2);phat(3)];
    Phi = [ phat(4), phat(7), phat(10);
            phat(5), phat(8), phat(11);
            phat(6), phat(9), phat(12) ];
    TP = y-1/n*(r+rho'*(m.*(n-1)+(Phi^n-Phi)*(Phi-eye(3))^-1 * (X-m))); 
end













