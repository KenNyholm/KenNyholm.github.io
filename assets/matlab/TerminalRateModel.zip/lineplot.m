function [] = lineplot(x,y,in)
%
% line plot 
% if x is datetime format, the x-axis will contain date and time 
% using ECB's color map
% x:              x-axis data
% y:              y-axis data
% in.title:       title
% in.ylabel:      label for the y-axis
% in.legend:      names of the plotted series, for the legend
% in.dateformat:  datetime format, e.g. 'dd-mmm-yyyy'
% in.font:        name of the font to be used
% in.fontsize:    font size
% in.linewidth:   line thickness
%
figure
colororder([0 0.196078431372549 0.6;
          0.882352941176471	0.705882352941177 0;
          0.882352941176471	0.294117647058824 0;
          0.396078431372549	0.721568627450980 0;
          0 0.694117647058824 0.917647058823529;
          0 0.470588235294118 0.0862745098039216;
          0.505882352941176	0.223529411764706 0.776470588235294;
          0.360784313725490	0.360784313725490 0.360784313725490;
          0.596078431372549	0.631372549019608 0.815686274509804;
          0.992156862745098	0.866666666666667 0.654901960784314;
          0.964705882352941	0.694117647058824 0.513725490196078;
          0.807843137254902	0.882352941176471 0.686274509803922;
          0.843137254901961	0.933333333333333 0.972549019607843;
          0.552941176470588	0.721568627450980 0.552941176470588;
          0.682352941176471	0.592156862745098 0.780392156862745;
          0.662745098039216	0.662745098039216 0.662745098039216;
          0.815789473684211	0.815789473684211 0.815789473684211;
          0 0 0]);  
    set(gcf,'position',[25 25 898 690])
    if (isempty(in.linewidth))
        in.linewidth=1;
    end
    plot(x,y,'LineWidth',in.linewidth);
    if (isdatetime(x))
        datetick('x',in.dateformat,'keeplimits','keepticks');
    end
    if (~isempty(in.title))
        title(in.title);
    end
    if (~isempty(in.font))
        set(gca,'fontname',in.font);
    end
    if (~isempty(in.fontsize))
        set(gca,'fontsize',in.fontsize);
    end
    if (~isempty(in.linewidth))
        set(gca,'linewidth',in.linewidth);
    end
    if (~isempty(in.legend))
        legend(in.legend,'Location','NE','box','off');
    end
    if (~isempty(in.ylabel))
        ylabel(in.ylabel);
    end
    grid on 
    set(gca,'GridLineStyle', "-");
    set(gca,'GridColor', [0.360784313725490	0.360784313725490 0.360784313725490]);
    set(gca,'LineWidth',1); 
end