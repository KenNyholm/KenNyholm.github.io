classdef TSM_estimate_local
    % ..................................................
    % Description of the Term Structure Estimation Class
    % ..................................................
    %
    %
    % Usage:   .getSAA          -> Short rate based model with the slope and curvature of the term structure of 
    %                              term premia as factors, and a long term attraction point for the short rate (C*)
    %          .getDNS          -> Dynamic Nelson-Siegel model and related metrics
    %          .getDSS          -> Dynamic Svensson-Soderlind model and related metrics
    %          .getSRB3         -> Short-Rate based 3-factor model and related metrics (following Nyholm 2018)
    %          .getSRB4         -> Short-Rate based 4-factor model and related metrics (following Nyholm 2018)
    %          .getJSZ          -> Joslin, Singleton, Zhu (2011)
    %          .getAFSRB        -> Arbitrage-free SRB model with 2,3, or 4 factors
    %
    % TSM : Dynamic term structure models of the Nelson-Siegel family. 
    %       Arbitrage constraints are not imposed in this modelling
    %       framework. See Nelson-Siegel(1987), Diebold-Li(2011), Nyholm(2018) 
    %       for references.
    %
    %       Small sample bias correction using Pope's closed form solution
    %       can be invoked via the flagg "biasCorrect=1".
    %
    %       The basic model setup is the following:
    %
    %           Y_t(tau) = a  + B(g) * X_t + e_t
    %           X_t      = kP + PhiP * (X_{t-1}-kP) + v_t
    %
    %       The model is estimated using the undcented Kalman-filter, 
    %       because the yield equation is allowed to be non-linear, when
    %       including a shadow short rate.
    %
    %  Input:
    %  ------
    %       Yields    :  panel of yields      ( nObs-by-nTau ) in percent
    %       nF        :  number of factors    ( used only for the arbitrage-free models )
    %       tau       :  vector of maturities ( nTau-by-1 ) in months (e.g. 12=1year)
    %       dataFreq  :  Data frequency of the yield curve data. This is 
    %                    relevant for the calculation of Term Premia.
    %                    The frequency is provided as the 
    %                    "number of observations per year" to allow for
    %                    flexibility, so, e.g.:
    %                                         DataFreq      Interpretation
    %                                         ----------------------------
    %                                             360    =   daily
    %                                              52    =   weekly
    %                                              12    =   Monthly
    %       pope      : flag for bias correction of PhiP following Pope(1990)
    %                   0=no correction,  1=bias correction
    %      ........................
    %       Only for the SAA model
    %      ........................
    %       nSegments    :  number of yield curve segments being modelled
    %                       simultaneously, e.g. [US] = 1 segment
    %                       [US DE] = 2 segments, and so on                     
    %       nTau         :  nSegments by 1, with 2 segments and 11
    %                       maturities in each segment it would be [11;11]
    %       tau          :  [tau_segment1; tau_segment2; ...]
    %       nF           :  1 by 1 with the number of factors. The same
    %                       number of factors is required in each segments
    %       Cstar        :  matrix of long-term attraction points for the 
    %                       short rate ( nObs-by-nSegments )  
    %       Macro        :  matrix of exogenous variables that can impact the
    %                       slope and curvature of the term structure of 
    %                       term premia ( nObs-by-nSegments ). One exogenous 
    %                       variable impacts the slope and curvature per
    %                       segment
    %       rLow         :  lower bound for the short rate ( 1-by-1 ) 
    %                       if no lower bound model is to be estimates,
    %                       set rLow=[]
    %       useParallel  :  flag for using MATLAB's parallel processing 
    %                       capabilities:  0=no , 1=yes
    %       pConstraints :  matrix of 0 and 1 ones imposing zero constraints
    %                       on the parameters of PhiP. 
    %                               0 = no constraint 
    %                               1 = constrained to be zero
    %                       the size is ( 3*nSegments-by-3*nSegments )
    %                       for example  = [ 0 1 1 ;
    %                                        1 0 1 ;
    %                                        1 1 0 ]; 
    %                       imposes zero constraints on the off-diagonal 
    %                       parameters in a model inclusing a single yield
    %                       curve segment
    %       gridSearch   :  when set to 1 it allows for estimation using
    %                       a grid search method rather than ML 
    %       ..........................
    %       For the calculation of C*
    %       ..........................
    %       
    %
    %
    %
    %
    %
    %  Output:
    %  -------
    %       p0            : estimated parameters
    %       kP            : see model description above
    %       PhiP          : see model description above
    %       a             : see model description above
    %       b             : see model description above
    %       g             : time-decay parameter in the loading matrix b
    %       s             : smoothing parameter for the weight given to C*
    %       Factors       : extracted yield curve factors
    %       FactorsA      : extracted yield curve factors when using a lower-bound on the short rate
    %       Yield_vol     : error term variance in the yield equation - equal across maturities 
    %                                   [despite the name of the variable, it is the variance ]
    %       Factor_vol    : error term covariance matrix in the factor eqation (reported for the 
    %                                          models that extract factors via the kalman-filter) 
    %       Yields_fit    : model fitted yields
    %       TP            : term structure of term premia
    %       Er            : risk free term structure / expectation component
    %       PhiP_pope     : bias corrected version of PhiP
    %       Factor_errors : residuals in the VAR of the factors (reported for the models that extract 
    %                                                                  factors via the kalman-filter)
    %       Yield_errors  : residuals in the yield equation (difference between observed and fitted)
    %       RMSE          : root mean squared error (in pct points)
    %       model         : estimated model
    %
    %    For the arbitrage free models:
    %       kQ    : constants in the VAR of the Q-dynamics of the factors
    %       PhiQ  : matrix of autoregressive coefficients in the VAR of the
    %                 Q-dynamics
    %
    % ------------------------------------------------------
    % Ken Nyholm: ken.nyholm@ecb.int 
    % Version 1: September 2021
    % Version 2: March 2022  
    %                      - Shadow rate functionality applied
    %                        beyond the SAA model
    %                      - Additional lower bound functions 
    %                        are added, see variable ssh_fx
    % Version 3: April 2023
    %                      - calculation of C* added with functions
    %                        getPD, Q2M, and funRstar
    % ------------------------------------------------------
    %
    properties (Access=public)
        %
        % ... Inputs ...
        %
        Yields double                                                 % yield curve data; marco data; stacked vector of maturities; VAR means
        Macro, Cstar double                                           % exogenous variable - Macro: impact factors at time t; Rstar is the                                                  %           short rate P-measure attraction level (in the yield equation)
        tau {mustBePositive} = [3 12:12:120]'                         % maturities at which yields are observed
        nSegments {mustBePositive, mustBeInteger} = 1                 % number of yields curve segments being modelled
        nTau {mustBePositive,mustBeInteger} = 11;                     % vector with the number of maturities in each segment
        dataFreq {mustBeMember(dataFreq,[12,52,360])} = 12            % the datafrequency must be the same for all segments
        nF {mustBeMember(nF,[1,2,3,4,5,6])} = 3                       % vector of the number of yield curve factors per yield segment
        pope (1,1) logical = false                                    % flag for small sample bias correction of the VAR parameters
        rLow double = []                                              % []=no lower bound imposed; numerical value=used as the lower bound
        p0 double                                                     % starting parameter values - OPTIONAL
        pConstraints double                                           % zero constraints [1=constraint;  0=no constraint] on the autoregressive 
                                                                      %                            parameters of the factor VAR (state equation) 
        pEst double                                                   % estimated parameters
        useParallel logical = false                                   % allows the use to activate parallel computing by setting value to 'true' 
        gridSearch double = 0                                         % estimation of the TSM model using grid search for the parameters s and g, 
                                                                      %    rather than likelihood estimation:  1=grid search  -  0=likelihood based
        sConstraints double = [];                                     % fixing the values of the smoothing parameter(s) between the short rate and R* 
                                                                      %    to given value(s)
        gConstraints double = [];                                     % fixing the values of the smoothing parameter(s) between the short rate and R* 
                                                                      %    to given value(s)
        %
        % ... Parameters ...
        %
        kP, kQ, PhiP, PhiQ, rho0, rho1, lambda0, lambda1 double
        a, b, aJordan, bJordan, g, s, xm double                       % g=eigenvalue in loading matrix, s=smoothing parameter for R*, xm=parameter for impact of exogenouos data on term premium slope and curvature
        W double                                                      % PCA loadings for the JSZ model
        Factors, FactorsA double
        Yield_vol, Factor_vol double
        Ps_t double
        %
        % ... Calculated and derived metrics
        %
        Yields_fit, Yields_shadow, ForwardRates, TP, Er double
        PhiP_pope double = []                                         % small-sample bias-corrected VAR matrix following Pope
        Factor_errors, Yield_errors double
        RMSE double
        model char
        %
        % ... additional parameters
        %
        zz_ double = [ -5.00; 1.00; 4.00; 1.00 ];  % parameters for the shadow rate conversion
        nObs {mustBeInteger,mustBeNonnegative}    
        s_   {mustBeInteger, mustBeNonnegative}    % counter for the start location of each segment in the maturity dimension
        e_   {mustBeInteger,mustBeNonnegative}     % counter for the end location of each segment in the maturity dimension
        p0count double                             % keeping track of the location of parameters in p0
        %
        % ... relevant for the calculation of C*
        %
        lgd {mustBePositive}                   = 0.70;              % from Moody's historical defaults
        hp_monthlysmoothing {mustBePositive}   = 14400;             % HP-filter smoothing for Monthly data
        hp_quarterlysmoothing {mustBePositive} = 1600;              % HP-filter smoothing for Quarterly data
        assetcorr {mustBePositive}             = 0.50;              % from financial risk and buffers
        a1 {mustBePositive}                    = 0.70;              % for the calculation of C*
        a2 {mustBePositive}                    = 3.50;              % for the calculation of C*
        rating  
        sharperatio {double} 
        pd {double}                                                 % probability of default, P-measure
        Qpd {double}                                                % probability of default, Q-measure
        econ = struct('cpi', [], 'logip', [], 'loggdp', [], 'Rstar',[]);  % container for the macroeconomic variables
        dataRange                                                   % vector of datetime observations covering the estimation period
        bs = [];                                                     % container for yield curve loadings when more than 1 segment is estimated 
        gs = [];
        ss = [];
        Fs = [];
        estFlag = [];
    end
    methods (Access=private)
        function [TSM_estimate]        = CheckInputs(TSM_estimate)
            %
            % Housekeeping, checking consistency of inputs    
            %
            if (isempty(whos))
                msgbox('Error: It looks like the workspace is empty. Please load the data needed for the model estimation');
                error('Error: It looks like the workspace is empty. Please load the data needed for the model estimation');
            end         
            TSM_estimate.nObs  = size(TSM_estimate.Yields,1);
            TSM_estimate.s_    = [1;cumsum(TSM_estimate.nTau)+1];
            TSM_estimate.e_    = cumsum(TSM_estimate.nTau);
            %TSM_estimate.nF    = repmat(TSM_estimate.nF,TSM_estimate.nSegments,1);
            TSM_estimate.Ps_t  = eye(sum(TSM_estimate.nF)).*0.10; 
            if ( ~iscolumn(TSM_estimate.nTau) || ~iscolumn(TSM_estimate.nF) || ~iscolumn(TSM_estimate.tau) )
                msgbox('Error: please check inputs {.nTau, .nF, .tau} : column vectors are required');
                error('Error: please check inputs {.nTau, .nF, .tau} : column vectors are required');
            end
            if ( TSM_estimate.nObs<sum(TSM_estimate.nTau) )
                msgbox('Error: please check inputs {.Yields} : an nObs -by- nTau matrix is required');
                error('Error: please check inputs {.Yields} : an nObs -by- nTau matrix is required');
            end
            if ( size(TSM_estimate.Yields,2)~=sum(TSM_estimate.nTau) )
                msgbox('Error: please check inputs {.Yields, .nTau} : there is something wrong with the supplied dimensions ');  
                error('Error: please check inputs {.Yields, .nTau} : there is something wrong with the supplied dimensions ');
            end
            if (strcmp(TSM_estimate.model,'DNS') || strcmp(TSM_estimate.model,'SRB3') || strcmp(TSM_estimate.model,'SAA') )
                if (~(TSM_estimate.nF==3))
                    msgbox('Error: Please ensure that .nF=3 for this model type');
                    error('Error: Please ensure that .nF=3 for this model type');
                end
            end
            if (strcmp(TSM_estimate.model,'DSS') || strcmp(TSM_estimate.model,'SRB4') )
                if (~(TSM_estimate.nF==4))
                    msgbox('Error: Please ensure that .nF=4 for this model type');
                    error('Error: Please ensure that .nF=4 for this model type');
                end
            end
            if (size(TSM_estimate.nTau,1)~=TSM_estimate.nSegments)
                msgbox('Error: Please ensure that .Tau have entries for each yield curve segment to be estimated');
                error('Error: Please ensure that .Tau have entries for each yield curve segment to be estimated');            
            end
        end
        function [TSM_estimate]        = AllocateStartingValues(TSM_estimate)
            %
            % Allocating the parameter starting values for the 
            % different models covered by the TSM class.
            % The ordering of the parameters is as follow:
            %     .p0 =  k, PhiP, rho0, rho1, lambda0, lambda1, 
            %            g, s, xm (impact of macro on TP slope and curvature)
            %            Yield_vol, Factor_vol
            %
            
            disp('... Allocating starting values where necessary')
            if (isempty(TSM_estimate.kP) || size(TSM_estimate.kP,1)~=sum(TSM_estimate.nF) )                        %  constant in the state eq
                TSM_estimate.kP = zeros(sum(TSM_estimate.nF),1);
            end
            if (isempty(TSM_estimate.PhiP) || sum(size(TSM_estimate.PhiP)~= [sum(TSM_estimate.nF), sum(TSM_estimate.nF)]))   %  autoregressive part of state eq
                TSM_estimate.PhiP = diag(ones(sum(TSM_estimate.nF),1)).*0.96;
            end
            if ( isempty(TSM_estimate.Factor_vol) || size(TSM_estimate.Factor_vol,1)~=(sum(TSM_estimate.nF)*(sum(TSM_estimate.nF)-1)/2)+sum(TSM_estimate.nF))  % error vols in the state eq
               TSM_estimate.Factor_vol = diag(ones(sum(TSM_estimate.nF),1)).*0.10;
            end
            if ( isempty(TSM_estimate.Yield_vol) || ~isscalar(TSM_estimate.Yield_vol) )                       %  error vols in the observation equation
               TSM_estimate.Yield_vol = 0.10.*ones(TSM_estimate.nSegments,1);
            end
            if ( ~isempty(TSM_estimate.Macro))
               TSM_estimate.xm = zeros(2*TSM_estimate.nSegments,1);
            end
            if (isempty(TSM_estimate.Cstar))
                TSM_estimate.Cstar=zeros(TSM_estimate.nObs,1);
            end
            if (strcmp(TSM_estimate.model,'SAA'))
                TSM_estimate.s = 0.07.*ones(TSM_estimate.nSegments,1);                 % smoothing parameter for the weight of R* across maturities
                TSM_estimate.g = 0.97.*ones(TSM_estimate.nSegments,1);                 % eigen value for PhiQ for each yield curve segment
                TSM_estimate.rho0 = 0;                                            % constant in the short rate eq
                %TSM_estimate.rho1 = [ 1; zeros(sum(TSM_estimate.nF)-1,1) ];           % defining the short rate as a function of the factors 
                TSM_estimate.rho1 = zeros(sum(TSM_estimate.nF),TSM_estimate.nSegments);
                for (j=1:TSM_estimate.nSegments)
                    TSM_estimate.rho1(3*j-2,j)=1;
                end
            elseif (strcmp(TSM_estimate.model,'JSZ'))
                TSM_estimate.g = 0.06.*ones(TSM_estimate.nSegments,1);                 % eigen value for PhiQ for each yield curve segment
                TSM_estimate.s = 0.06.*ones(TSM_estimate.nSegments,1);
                TSM_estimate.rho0 = 0;                                            % constant in the short rate eq
                TSM_estimate.rho1 = [ ones(sum(TSM_estimate.nF),1) ];                  % normalisation constraints             
            elseif (strcmp(TSM_estimate.model,'DNS')||strcmp(TSM_estimate.model,'SRB3'))
                TSM_estimate.g = 0.06.*ones(TSM_estimate.nSegments,1);                 % time-decay parameter for the loading matrix
                TSM_estimate.s = 0.06.*ones(TSM_estimate.nSegments,1);
                TSM_estimate.rho0 = 0;                                            % constant in the short rate eq
                if (strcmp(TSM_estimate.model,'DNS'))
                    TSM_estimate.rho1 = [ 1; 1; 0; zeros(sum(TSM_estimate.nF)-3,1) ];      % defining the short rate as a function of the factors 
                elseif  strcmp(TSM_estimate.model,'SRB3')
                    TSM_estimate.rho1 = [ 1; 0; 0; zeros(sum(TSM_estimate.nF)-3,1) ];
                else
                    disp('Something is wrong');
                end
            elseif (strcmp(TSM_estimate.model,'DSS')||strcmp(TSM_estimate.model,'SRB4'))
                TSM_estimate.g = 0.06.*ones(2*TSM_estimate.nSegments,1);                        % time-decay parameter for the loading matrix
                TSM_estimate.s = 0.06.*ones(2*TSM_estimate.nSegments,1);
                TSM_estimate.rho0 = 0;                                                     % constant in the short rate eq
                if (strcmp(TSM_estimate.model,'DSS'))
                    TSM_estimate.rho1 = [ 1; 1; 0; zeros(sum(TSM_estimate.nF)-3,1) ];           % defining the short rate as a function of the factors             
                elseif (strcmp(TSM_estimate.model,'SRB4'))
                    TSM_estimate.rho1 = [ 1; 0; 0; zeros(sum(TSM_estimate.nF)-3,1) ];
                else
                    disp('Something is wrong');
                end
            elseif (strcmp(TSM_estimate.model,'AFSRB'))
                TSM_estimate.g    = 0.96.*ones(2*TSM_estimate.nSegments,1);                     % time-decay parameter for the loading matrix
                TSM_estimate.s    = 0.96.*ones(2*TSM_estimate.nSegments,1);
                TSM_estimate.rho0 = 0;                                                     % constant in the short rate eq
                TSM_estimate.rho1 = zeros(sum(TSM_estimate.nF),1);                              % defining the short rate as a function of the factors
                TSM_estimate.rho1(1,1)  = 1;
                TSM_estimate.kQ         = zeros(sum(TSM_estimate.nF),1);
                TSM_estimate.Factor_vol = eye(sum(TSM_estimate.nF));
            end       
        end
        function [c,ceq]               = CheckEigVal(p0,TSM_estimate)
            %
            %  Nonlinear constraint function for the UKF estimation
            %  ensuring that the eigenvalues of PhiP are all less than 1,
            %  i.e. that the VAR in the state equation is stationary
            %
            zmax   = 1-(1e-6);
            F      = reshape(p0(TSM_estimate.p0count(2):TSM_estimate.p0count(3)-1),sum(TSM_estimate.nF),sum(TSM_estimate.nF));
            E      = sort(real(eig(F)),'descend');
            c(1,1) = E(1,1)-zmax;
            c(2,1) = -E(end,1);
            ceq    = [];
        end
        function [TSM_estimate]        = Shadow2Yield(TSM_estimate)
        % 
        % Converts shadow yields to observed yields
        % 
        % ... Defining the shadow rate transformations
        %
            alfa_   = @(X_,zz) ( tanh(zz(1,1).*X_(2,:)+zz(2,1))+3 )./2 .*( tanh( zz(3,1).*X_(3,:)+zz(4,1) )+3 )./2;  
            yCalc_  = @(yS_,alpha_,rL_) rL_+(yS_-rL_)./(1-exp(-alpha_.*(yS_-rL_)));

        % ... calculating shadow yields
        %
            if ( TSM_estimate.model=='SAA' )
                TSM_estimate.Yields_shadow = ( TSM_estimate.b*[TSM_estimate.Factors TSM_estimate.Cstar ]')';
            else
                TSM_estimate.Yields_shadow = ( TSM_estimate.b*TSM_estimate.Factors')';
            end
                TSM_estimate.Yields_fit    = zeros(size(TSM_estimate.Yields_shadow));
            for (j=1:TSM_estimate.nObs)
                alpha                    = alfa_(TSM_estimate.Factors(j,:)',TSM_estimate.zz_);
                TSM_estimate.Yields_fit(j,:)  = yCalc_(TSM_estimate.Yields_shadow(j,:)',alpha,TSM_estimate.rLow);     
            end
        end
        function [TSM_estimate]        = Pope(TSM_estimate)
            %
            % Samll sample bias correction of the state-eq VAR following Pope(1990)
            %
            %k      = size(TSM_estimate.PhiP,1);
            Gamma0 = reshape( (eye(size(TSM_estimate.PhiP,1)^2) - kron(TSM_estimate.PhiP, TSM_estimate.PhiP))^(-1) * TSM_estimate.Factor_vol(:), size(TSM_estimate.PhiP,1), size(TSM_estimate.PhiP,1));  % long run variance Var(X_t)
            tmpsum = zeros(size(TSM_estimate.PhiP,1),size(TSM_estimate.PhiP,1));
            eig_ = eig(TSM_estimate.PhiP);
            for (j=1:size(TSM_estimate.PhiP,1))
                tmpsum = tmpsum + eig_(j)*( eye(size(TSM_estimate.PhiP,1)) - eig_(j)*TSM_estimate.PhiP' )^(-1);
            end
            bb                = TSM_estimate.Factor_vol * ( ( eye(size(TSM_estimate.PhiP,1))-TSM_estimate.PhiP' )^(-1) + TSM_estimate.PhiP'*inv(eye(size(TSM_estimate.PhiP,1))-(TSM_estimate.PhiP'*TSM_estimate.PhiP')) + tmpsum ) * (Gamma0)^(-1);
            TSM_estimate.PhiP_pope = TSM_estimate.PhiP+bb/TSM_estimate.nObs;                       % following Wang, Phillips, Yu
            k_indx = ( 0.99:-0.01:0 )';
            q = 1;
            while ( max(abs(eig(TSM_estimate.PhiP_pope)))>0.9999 && q<=length(k_indx) )  % ensuring stationarity following Killian
                TSM_estimate.PhiP_pope = TSM_estimate.PhiP + (bb./TSM_estimate.nObs).*k_indx(q,1);
                q = q+1;
                if ( q==length(k_indx) )
                    disp('NOTE: VAR(1) matrix may not be stationary')
                end
            end    
        end        
        function [TSM_estimate]        = TermPremia(TSM_estimate)
            %
            % Calculating term premia and expectations component (risk free term structure)
            %                
            ExpR_calc = @(V_,D_,n_,X0_,mP_,rho1_,I_)  (1/n_)*(( X0_'*rho1_ ) +  ( ( n_-1 ).*mP_ + ... 
                         ((( V_*D_^n_*V_^(-1) ) - ( V_*D_*V_^(-1) )) *( V_*D_*V_^(-1)-I_ )^(-1) )*(X0_-mP_))'*rho1_);
            alfa_     = @(Xshdw,zz) ( tanh(zz(1,1).*Xshdw(2,:)+zz(2,1)) ...
                         +3 )./2 .*( tanh( zz(3,1).*Xshdw(3,:)+zz(4,1) )+3 )./2;                                             
            TSM_estimate.Er = NaN( TSM_estimate.nObs, sum(TSM_estimate.nTau) );
            I      = eye(size(TSM_estimate.Factors,2));
            [V,D]  = eig(TSM_estimate.PhiP);
            if ( ~isempty(TSM_estimate.PhiP_pope) )      
                [V,D] = eig(TSM_estimate.PhiP_pope);
            end          
            if (strcmp(TSM_estimate.model,'JSZ'))
                %cP = repmat(( I-V*D*V^(-1) )*TSM_estimate.kP,1,TSM_estimate.nObs);
                cP = repmat(TSM_estimate.kP,1,TSM_estimate.nObs);
            else
                cP = repmat(TSM_estimate.kP,1,TSM_estimate.nObs);
            end
            if ( ~strcmp(TSM_estimate.model,'SAA') && isempty(TSM_estimate.rLow) )      % not SAA model and no shadow short rate
                for ( j=1:TSM_estimate.nObs )
                    tmp = [];
                    for (z=1:TSM_estimate.nSegments)
                        tmp=[tmp;ones(TSM_estimate.nTau(z,1),1)*z];
                    end
                    for ( k=1:sum(TSM_estimate.nTau) )
                        n_              = TSM_estimate.tau(k,1)*TSM_estimate.dataFreq/12;
                        TSM_estimate.Er(j,k) = ExpR_calc(V,D,n_,TSM_estimate.Factors(j,:)',cP(1:sum(TSM_estimate.nF),j),TSM_estimate.rho1(:,tmp(k,1)),I);
                    end
                end 
                TSM_estimate.Er = real(TSM_estimate.Er);
                TSM_estimate.TP = TSM_estimate.Yields_fit(:,1:sum(TSM_estimate.nTau))-real(TSM_estimate.Er);
            elseif ( strcmp(TSM_estimate.model,'SAA') && isempty(TSM_estimate.rLow) )
                if (TSM_estimate.nSegments==1)
                    indx       = (1:3:TSM_estimate.nF*TSM_estimate.nSegments); 
                    TSM_estimate.Er = ( TSM_estimate.b(:,[indx TSM_estimate.nF*TSM_estimate.nSegments+1:end]) * [TSM_estimate.Factors(:,[indx TSM_estimate.nF*TSM_estimate.nSegments+1:end]) TSM_estimate.Cstar]')'; 
                    TSM_estimate.TP = TSM_estimate.Yields_fit-TSM_estimate.Er;
                end
            elseif ( strcmp(TSM_estimate.model,'SAA') && ~isempty(TSM_estimate.rLow) )
                TSM_estimate.FactorsA = NaN(size(TSM_estimate.Factors));
                for ( j=1:size(TSM_estimate.FactorsA,1) )
                    TSM_estimate.FactorsA(j,:) = (TSM_estimate.b(:,[1:1:TSM_estimate.nF*TSM_estimate.nSegments])\(TSM_estimate.rLow + (TSM_estimate.Yields_fit(j,:)' - TSM_estimate.rLow)./ ...
                                            ( 1-exp(-alfa_(TSM_estimate.Factors(j,:)',TSM_estimate.zz_).*(TSM_estimate.Yields_fit(j,:)'-TSM_estimate.rLow)) )))'; 
                end
                TSM_estimate.FactorsA = [TSM_estimate.FactorsA TSM_estimate.Cstar]; 
                indx_TP = sort([[2:TSM_estimate.nF:TSM_estimate.nF*TSM_estimate.nSegments]';[3:TSM_estimate.nF:TSM_estimate.nF*TSM_estimate.nSegments]']);        
                %indx_Er = [1:1:(TSM_estimate.nF*TSM_estimate.nSegments)+size(TSM_estimate.Cstar,2)]';
                %indx_Er(indx_TP)=[];
                TSM_estimate.TP = (TSM_estimate.b(:,indx_TP)*TSM_estimate.FactorsA(:,indx_TP)')';
                TSM_estimate.Er = TSM_estimate.Yields_fit-TSM_estimate.TP;  
            elseif ( ~strcmp(TSM_estimate.model,'SAA') && ~isempty(TSM_estimate.rLow))       % not SAA but with lower bound
                % not implemented yet
                TSM_estimate.TP = [];
                TSM_estimate.Er = [];
            else
                error('Error: something is wrong. Please check inputs');
            end             
        end
        function [logLik,TSM_estimate] = UKF(p0, TSM_estimate)
            %  
            % The Unscented Kalman Filter 
            %     based on Ch.7 "The Unscented KF" 
            %     by Wan and van der Merwe
            %
           
            % ... Allocating parameters to be estimated
            % 
            m     = p0(TSM_estimate.p0count(1):TSM_estimate.p0count(2)-1);          % X_t = m + F * ( X_{t-1}-m ) + S*v_t
            F     = reshape(p0(TSM_estimate.p0count(2):TSM_estimate.p0count(3)-1),sum(TSM_estimate.nF),sum(TSM_estimate.nF));            
            S     = reshape(p0(TSM_estimate.p0count(3):TSM_estimate.p0count(4)-1),sum(TSM_estimate.nF),sum(TSM_estimate.nF));                                                 
            r     = p0(TSM_estimate.p0count(4):TSM_estimate.p0count(5)-1);          % vol in obs eq (vol of yields)
            if (~isempty(TSM_estimate.Macro))
                xxm = [ zeros(1,TSM_estimate.nSegments); reshape(p0(TSM_estimate.p0count(7):TSM_estimate.p0count(8)-1), 2, TSM_estimate.nSegments)];   
            end
            rr    = [];
            for (j=1:TSM_estimate.nSegments)
                rr = [rr;ones(TSM_estimate.nTau(j),1).*r(j)];
            end
            R     = diag(rr);
            Q     = S*S';
            
            % ... Defining necessary functions and containers
            %
            L_lik   = zeros( 1,TSM_estimate.nObs );                                      % likelihood values
            K       = zeros( 1,TSM_estimate.nObs );                                      % Kalman Gain
            alfa_Fx = @(X_,zz) ( tanh(zz(1,1).*X_(2,:)+zz(2,1))+3 )./2 .*( tanh( zz(3,1).*X_(3,:)+zz(4,1) )+3 )./2;  % shadow conversion
             
            % ... Kalman Filter iterations
            % ... equation references refer to Ch.7 The Unscented KF by Wan and van der Merwe
            %
            Xs_t  = m;                                                % ... Initialise sigma-points  [7.50]  using E(X)
            %Ps_t  = eye(sum(TSM_estimate.nF)).*0.10;                      % ...                          [7.51]  using E[(x0-x0_hat)(x0-x0_hat)']
            kappa = 0;                                                % ... page 6
            alpha = 0.99;                                             % 0.99 
            b_    = 2;                                                % b_ = beta                 (notation ch7)
            LL    = alpha^2*(sum(TSM_estimate.nF)+kappa)-sum(TSM_estimate.nF);  % scaling factor: LL=lambda (notation ch7) 
            gamma = sqrt(sum(TSM_estimate.nF)+LL);

            W_m0   = LL/(sum(TSM_estimate.nF)+LL);                          % weights, see page 6 for specification
            W_c0   = LL/(sum(TSM_estimate.nF)+LL)+(1-alpha^2+b_);           %
            W_i    = repmat( 1/(2*(sum(TSM_estimate.nF)+LL)),1,2*sum(TSM_estimate.nF) );  %
            W_m    = [ W_m0 W_i ];                                              % weights for the mean equation
            W_c    = [ W_c0 W_i ];                                              % weights for the variance
            beta_  = zeros(sum(TSM_estimate.nF),TSM_estimate.nObs);
            TSM_estimate.Ps_t = eye(sum(TSM_estimate.nF)).*0.10;
            for ( t=2:TSM_estimate.nObs ) 
                % ... Initialising state variables
                % ... Checking that Ps_t is positive definite (prediction error on state variables)
                % 
                t2=0;
                [~,t2] = chol(TSM_estimate.Ps_t);
                if ( t2==0 )
                    Ps_t_sq  = chol(TSM_estimate.Ps_t)';
                elseif (isnan(TSM_estimate.Ps_t) | isinf(TSM_estimate.Ps_t) )
                    Ps_t_sq = eye(sum(TSM_estimate.nF));     
                else
                    [vv, dd]      = eig(TSM_estimate.Ps_t); dd = diag(dd);
                    dd            = (dd<0)+1e-6+(dd>0).*dd;
                    TSM_estimate.Ps_t  = vv*diag(dd)*(vv\eye(length(vv)));
                    [~,t3]        = chol(TSM_estimate.Ps_t);
                    if (t3==0)
                        Ps_t_sq  = chol(TSM_estimate.Ps_t)';
                        ok_=1;
                    else
                        Ps_t_sq  = eye(sum(TSM_estimate.nF));
                    end
                end
                % ... Calculate sigma-points                                               [ 7.51, 7.52 ]     
                Xs_tm1   = [ Xs_t ...
                             repmat(Xs_t,1,sum(TSM_estimate.nF))+gamma*Ps_t_sq ...
                             repmat(Xs_t,1,sum(TSM_estimate.nF))-gamma*Ps_t_sq ];   
                % ... Prediction step
                if (isempty(TSM_estimate.Macro))
                    Xs_tl = repmat(m,1,1+sum(TSM_estimate.nF)*2) + F * ( Xs_tm1-repmat(m,1,1+sum(TSM_estimate.nF)*2) );    % [ 7.53 ]
                else                   
                    Xs_tl = repmat(m,1,1+sum(TSM_estimate.nF)*2) + F * ( Xs_tm1-repmat(m,1,1+sum(TSM_estimate.nF)*2) ) + reshape(xxm.*TSM_estimate.Macro(t-1,:),[],1);    % updated with exogenouos macrovariable
                end
                Xs_t_ = Xs_tl * W_m';                                                                           % [ 7.54 ]
                err_X = ( Xs_tl - repmat(Xs_t_,1,(1+sum(TSM_estimate.nF)*2)) );                                       % [ 7.55 ] 
                P_t_  = zeros(sum(TSM_estimate.nF),sum(TSM_estimate.nF));                                                  % .
                for ( j=1:(1+sum(TSM_estimate.nF)*2) )                                                                % .
                    P_t_ = P_t_ + W_c(1,j).*(err_X(:,j)*err_X(:,j)');                                            % .
                end                                                                                              % .        
                P_t_ = P_t_ + Q;
                %
                % ... Observation equation
                %
                [~, J]    = size(Xs_tl);
                [TSM_estimate] = LoadingMatrix(p0,TSM_estimate);                                                          % get a and b for the observation equation
                if ( strcmp(TSM_estimate.model,'SAA') )
                    Ys_t_ssr  = TSM_estimate.a + TSM_estimate.b * [ Xs_tl; repmat(TSM_estimate.Cstar(t,:)',1,length(Xs_tl)) ];                     
                else
                    Ys_t_ssr  = TSM_estimate.a + TSM_estimate.b * Xs_tl;
                end
                if ( ~isempty(TSM_estimate.rLow) )                                                                   % shadow rate version
                    Ys_t = zeros(size(Ys_t_ssr));
                    for ( j=1:J )
                        Ys_t(:,j) = TSM_estimate.rLow + (Ys_t_ssr(:,j) - TSM_estimate.rLow)./( 1-exp(-alfa_Fx(Xs_tl(:,j),TSM_estimate.zz_).*(Ys_t_ssr(:,j)-TSM_estimate.rLow)) ); 
                        if ( ~isreal(Ys_t(:,j)) || sum(isnan(Ys_t(:,j)))>0 || abs(sum(Ys_t(:,j)))>1e3  )
                            Ys_t(:,j) = zeros(sum(TSM_estimate.nTau),1);
                        end
                    end
                else
                    Ys_t = Ys_t_ssr;
                end                
                Y_t  = Ys_t * W_m';
                % ... Variance on prediction error
                Pyy   = zeros(sum(TSM_estimate.nTau), sum(TSM_estimate.nTau));    % [ 7.58 ]
                err_Y = Ys_t-repmat(Y_t,1,size(Ys_t,2));
                for (j=1:size(Ys_t,2))                                  % .
                    Pyy   = Pyy + W_c(1,j).*(err_Y(:,j)*err_Y(:,j)');   % .
                end                                                     % .
                eps_y  = ( TSM_estimate.Yields(t,:)' - Y_t);
                Py  = Pyy+R;                                            % .
                Pxy = zeros(sum(TSM_estimate.nF),sum(TSM_estimate.nTau));         % [ 7.59 ]
                for (j=1:(1+sum(TSM_estimate.nF)*2))                         % .
                    Pxy   = Pxy + W_c(1,j).*(err_X(:,j)*err_Y(:,j)');   % .
                end                                                     % . 
                                                                        % .        
            % ... Measurement Update 
                Py_inv       = (Py\eye(sum(TSM_estimate.nTau)));
                K            = Pxy*Py_inv;                                   % [ 7.60 ]
                Xs_t         = Xs_t_ + K*eps_y;                              % [ 7.61 ]
                TSM_estimate.Ps_t = P_t_ - K*Py*K';                               % [ 7.62 ]

            % ... Calculating the likelihood 
                L_lik(1,t)   = - log(det(Py)) - eps_y'*Py_inv*eps_y;
                beta_(:,t)   = Xs_t; 
            end
            logLik = -sum(L_lik(1,1:end));
            TSM_estimate.kP           = m;
            TSM_estimate.PhiP         = F; 
            TSM_estimate.Yield_vol    = R;
            TSM_estimate.Factor_vol   = Q; 
            TSM_estimate.Factors      = beta_';
            TSM_estimate.Factors(1,:) = TSM_estimate.Factors(2,:);
            if (~isempty(TSM_estimate.rLow))
                [ TSM_estimate ] = Shadow2Yield(TSM_estimate);
            else
                TSM_estimate.Yields_fit = (repmat(TSM_estimate.a,1,size(TSM_estimate.Factors,1)) + TSM_estimate.b*[TSM_estimate.Factors TSM_estimate.Cstar]')';    
            end
            TSM_estimate.Yields_fit(1,:) = TSM_estimate.Yields(1,:);
            TSM_estimate.Yield_errors    = TSM_estimate.Yields-TSM_estimate.Yields_fit;
            TSM_estimate.RMSE            = sqrt(mean(TSM_estimate.Yield_errors.^2));
        end
        function [TSM_estimate]        = runOptimSAA(TSM_estimate)
            %
            % Performs the generic optimisation steps
            %
            TSM_estimate         = CheckInputs(TSM_estimate);
            TSM_estimate         = AllocateStartingValues(TSM_estimate);
            TSM_estimate.p0      = [ TSM_estimate.kP(:); TSM_estimate.PhiP(:); ...
                                TSM_estimate.Factor_vol(:); TSM_estimate.Yield_vol(:); ...
                                TSM_estimate.s(:); TSM_estimate.g(:); TSM_estimate.xm(:) ];
            TSM_estimate.p0count = cumsum([ 1;length(TSM_estimate.kP(:)); length(TSM_estimate.PhiP(:)); ...
                                length(TSM_estimate.Factor_vol(:)); length(TSM_estimate.Yield_vol(:)); ...
                                length(TSM_estimate.s(:)); length(TSM_estimate.g(:)); length(TSM_estimate.xm(:))]);

            fLik    = @(p0) UKF( p0, TSM_estimate );
            nonlcon = @(p0) CheckEigVal(p0,TSM_estimate);

            optOptions_ = optimset('TolFun', 1e-8, 'TolX', 1e-8, 'MaxFunEvals', 1e12, ...
                           'MaxIter', 1e12, 'Display', 'iter', ...
                           'Algorithm','interior-point', 'UseParallel',TSM_estimate.useParallel );             
            A_Ineq = [];
            b_Ineq = []; 
            lb_    = -inf(size(TSM_estimate.p0,1),1);
            ub_    =  inf(size(TSM_estimate.p0,1),1);
            
            lb_(TSM_estimate.p0count(2):TSM_estimate.p0count(3)-1,1) = -0.5;   % PhiP
            ub_(TSM_estimate.p0count(2):TSM_estimate.p0count(3)-1,1) =  0.5;   % PhiP            
            for (j=0:sum(TSM_estimate.nF)+1:TSM_estimate.p0count(3)-sum(TSM_estimate.nF)-1)
                lb_(TSM_estimate.p0count(2)+j,1) = 0.25;                   % diagonal of PhiP
                ub_(TSM_estimate.p0count(2)+j,1) = 1.25;                   % diagonal of PhiP
            end
            lb_(TSM_estimate.p0count(4):TSM_estimate.p0count(5)-1) = 1e-3;      % vol in Yield equation (otherwise we can sometimes get inf issues in the kalman filter)
            lb_(TSM_estimate.p0count(5):TSM_estimate.p0count(6)-1) = 1e-3;      % smoothing constant for R*
            lb_(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = 1e-3;      % smoothing constant for TP loadings
            ub_(TSM_estimate.p0count(4):TSM_estimate.p0count(5)-1) = inf;       % vol in Yield equation
            ub_(TSM_estimate.p0count(5):TSM_estimate.p0count(6)-1) = 1-1e-3;    % smoothing constant for R*
            ub_(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = 1-1e-3;    % smoothing constant for TP loadings
            A_eq=[];
            b_eq=[];
            if (~isempty(TSM_estimate.pConstraints))                       % zero-constraints on the VAR parameters
                indx            = (TSM_estimate.p0count(2):1:TSM_estimate.p0count(3)-1)'.*TSM_estimate.pConstraints(:); % parameter number for which zero constraints apply
                indx(indx==0)   = []; 
                A_eq            = zeros(sum(TSM_estimate.pConstraints(:)),size(TSM_estimate.p0,1));
                for (j=1:size(A_eq,1))
                    A_eq(j,indx(j,1)) = 1;
                end
                b_eq = zeros(sum(TSM_estimate.pConstraints(:)),1);
            end
            if (~isempty(TSM_estimate.sConstraints))                                 % fixing the smoothing parameter(s) between the short rate and R* to a given value
                nn             = size(A_eq,1);
                indx           = (TSM_estimate.p0count(5):1:TSM_estimate.p0count(6)-1)';  % parameter number for for active constraint(s) 
                A_eq           = [ A_eq; zeros(TSM_estimate.nSegments,size(TSM_estimate.p0,1)) ];
                A_eq(nn+1:end,indx) = eye(TSM_estimate.nSegments);
                b_eq = [b_eq;TSM_estimate.sConstraints(:)];
            end
            if (~isempty(TSM_estimate.gConstraints))                                 % fixing the time-decay parameter(s) for the term structure of term premia to a given value
                nn             = size(A_eq,1);
                indx           = (TSM_estimate.p0count(6):1:TSM_estimate.p0count(7)-1)';  % parameter number for for active constraint(s) 
                A_eq           = [ A_eq; zeros(TSM_estimate.nSegments,size(TSM_estimate.p0,1)) ];
                A_eq(nn+1:end,indx) = eye(TSM_estimate.nSegments);
                b_eq = [b_eq;TSM_estimate.gConstraints(:)];               
            end  
            % performing the estimation
            if (~isempty(TSM_estimate.Macro))
                lb_(end-1,1) = -inf;    % constraints for the free-float impact
                lb_(end,1)   = -0.01;
                ub_(end-1,1) = 0;
                ub_(end,1)   = 0.01;
            end
            [ TSM_estimate.pEst ] = fmincon(fLik, TSM_estimate.p0, ...
                                       A_Ineq, b_Ineq, A_eq, b_eq, ...
                                       lb_, ub_, nonlcon, optOptions_);         

            [ ~, TSM_estimate ] = UKF(TSM_estimate.pEst, TSM_estimate ); 
            TSM_estimate.s  = TSM_estimate.pEst(TSM_estimate.p0count(5):TSM_estimate.p0count(6)-1);
            TSM_estimate.g  = TSM_estimate.pEst(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);             
            TSM_estimate.xm = TSM_estimate.pEst(TSM_estimate.p0count(7):TSM_estimate.p0count(8)-1);
            if (TSM_estimate.pope==1)
                disp('... Bias correcting the VAR parameters')
                TSM_estimate = Pope(TSM_estimate);
            end
            [TSM_estimate]   = TermPremia(TSM_estimate);
        end     
        function [err2,TSM_estimate]   = runOptimJSZ(p0,TSM_estimate)
            %
            % finds PhiQ, and kQ for the JSZ specification
            %
            TSM_estimate.PhiQ = diag(p0(1:TSM_estimate.nF));
            TSM_estimate.kQ   = [p0(end,1);zeros(TSM_estimate.nF-1,1)];
            [ TSM_estimate ]  = LoadingMatrix(p0,TSM_estimate);
            % ... now rotate to PCA form
            TSM_estimate.a    = (( eye(TSM_estimate.nTau) - TSM_estimate.bJordan*(TSM_estimate.W*TSM_estimate.bJordan)^(-1)*TSM_estimate.W )*TSM_estimate.aJordan);
            TSM_estimate.b    = (TSM_estimate.bJordan*(TSM_estimate.W*TSM_estimate.bJordan)^(-1));     
            TSM_estimate.Yields_fit = 100.*(TSM_estimate.a + TSM_estimate.b*TSM_estimate.Factors')';
            err2 = sum(sum( (TSM_estimate.Yields-TSM_estimate.Yields_fit).^2 ));
        end        
        function [err2,TSM_estimate]   = runOptimAFSRB(p0,TSM_estimate)
            %
            % finds mQ of the ARSRB model
            %        
            TSM_estimate.kQ    = p0;
            [ TSM_estimate ]   = LoadingMatrix(p0,TSM_estimate);
            err2          = sum(sum((TSM_estimate.Yields - (TSM_estimate.a + TSM_estimate.b*TSM_estimate.Factors(:,1:TSM_estimate.nF)')').^2));
        end
        function [TSM_estimate]        = generateOutput(TSM_estimate)
            %
            % Output for the DNS type models
            %
            TSM_estimate.Factors = (TSM_estimate.b\TSM_estimate.Yields')';
            TSM_estimate.kP      = mean(TSM_estimate.Factors)';
            TSM_estimate.PhiP    = ((TSM_estimate.Factors(1:end-1,:)-repmat(TSM_estimate.kP',TSM_estimate.nObs-1,1))\(TSM_estimate.Factors(2:end,:)-repmat(TSM_estimate.kP',TSM_estimate.nObs-1,1)))';
            TSM_estimate.Factor_errors = (TSM_estimate.Factors(2:end,:)'-TSM_estimate.PhiP*TSM_estimate.Factors(1:end-1,:)')';
            TSM_estimate.Factor_vol    =  1/TSM_estimate.nObs*(TSM_estimate.Factor_errors'*TSM_estimate.Factor_errors); 
            TSM_estimate.Yields_fit    = (TSM_estimate.b*TSM_estimate.Factors')'; 
            TSM_estimate.Yield_errors  = TSM_estimate.Yields-TSM_estimate.Yields_fit;
            TSM_estimate.Yield_vol     = 1/TSM_estimate.nObs*(TSM_estimate.Yield_errors'*TSM_estimate.Yield_errors);
            TSM_estimate.RMSE          = (mean(TSM_estimate.Yield_errors.^2)).^(0.5);            
        end
        function [TSM_estimate]        = funRstar(TSM_estimate)        
            %
            % calculating R* following Roberts(2018)
            %
            tmp = ( 100*TSM_estimate.econ.gdpcycle_interp(2:end,1) - TSM_estimate.a1*100*TSM_estimate.econ.gdpcycle_interp(1:end-1,1) )/TSM_estimate.a2 ...
                + TSM_estimate.Yields(2:end,end) - TSM_estimate.econ.cpi(2:end,1) + TSM_estimate.econ.cpitrend(2:end,1); 
            TSM_estimate.econ.Rstar = [tmp(1,1);tmp];   % adding the first obs to adjust for missing obs introduced by the lag operator 
        end
        function [out]                 = Q2M(TSM_estimate)
            % Generates inter-quarter observations for the quaterly data series 
            % (Qseries) using the monthly series (Mseries). 
            %
            % Qseries: missing 'monthly' observations must be NaN 
            % Qseries and Mseries must be of equal length
            Q = TSM_estimate.econ.gdpcycle;     %Qseries(:);
            M = TSM_estimate.econ.ipcycle;      %Mseries(:);
            if ( ~size(Q,1)==size(M,1) )
                disp('Please ensure that the Q and M series have the same number of observations')
                disp('Indicate by NaN where the Qseries needs to be interpolated')
            end
            nn = size(M,1);
            indx = ~isnan(Q);
            n1 = find(indx==1, 1, 'first');
            n2 = find(indx==1, 1, 'last');
            %x  = repmat([1;2/3;1/3;0],n2-n1,1);
            w  = [ ones(n1-1,1); repmat([1;2/3;1/3],(n2-n1)/3,1); ones(nn+1-n2,1) ];
            d  = Q-M;
            nn = find(~isnan(d),2,'first');      % position of obs for 1st and 2nd quarter
            d1 = fillmissing(fillmissing(d,'previous'),'nearest');
            d2 = fillmissing(fillmissing([zeros(n1-1,1); d(nn(2,1):end,1); zeros(nn(2,1)-n1,1)],'previous'),'nearest');
            out = M+w.*d1+(1-w).*d2;
        end 
        function [out]                 = getPDp(TSM_estimate,k)           
            %
            % in  = rating (cell array), e.g. AAA
            % out = probability of default corresponding to RAN 
            %
            in = TSM_estimate.rating.rating(k);
            switch in     
                case 'AAA'
                    out = 0.0100/100;
                case 'AA+'
                    out = 0.0120/100;
                case 'AA'
                    out = 0.0160/100;
                case 'AA-'	
                    out = 0.0600/100;
                case 'A+'	
                    out = 0.0610/100;
                case 'A'	
                    out = 0.0620/100;
                case 'A-'	
                    out = 0.0690/100;
                case 'BBB+'	
                    out = 0.0960/100;
                case 'BBB' 
                    out = 0.1190/100;
                case 'BBB-'	
                    out = 0.2440/100;
                case 'BB+'	
                    out = 0.3570/100;
                case 'BB'	
                    out = 0.5780/100;
                case 'BB-'	
                    out = 1.2170/100;
                case 'B+'	
                    out = 1.9870/100;
                case 'B'	
                    out = 2.9980/100;
                case 'B-'	
                    out = 5.1340/100;
                case 'CCC'	
                    out = 30.2420/100;
                case 'AAAu'	
                    out = 0.0100/100;
                case 'AA+u'	
                    out = 0.0120/100;
                case 'AAu' 
                    out = 0.0160/100;
                case 'AA-u'	
                    out = 0.0600/100;
                case 'A+u'	
                    out = 0.0610/100;
                case 'Au'	
                    out = 0.0620/100;
                case 'A-u'	
                    out = 0.0690/100;
                case 'BBB+u'	
                    out = 0.0960/100;
                case 'BBBu'	
                    out = 0.1190/100;
                case 'BBB-u'	
                    out = 0.2440/100;
                case 'BB+u'	
                    out = 0.3570/100;
                case 'BBu'	
                    out = 0.5780/100;
                case 'BB-u'	
                    out = 1.2170/100;
                case 'B+u'	
                    out = 1.9870/100;
                case 'Bu'	
                    out = 2.9980/100;
                case 'B-u'	
                    out = 5.1340/100;
                case 'SD'	
                    out = 100.0000/100;
                case 'AAA *-'	
                    out = 0.0100/100;
                case 'AA+ *-'	
                    out = 0.0120/100;
                case 'AA *-'	
                    out = 0.0160/100;
                case 'AA- *-'	
                    out = 0.0600/100;
                case 'A+ *-'	
                    out = 0.0610/100;
                case 'A *-'	
                    out = 0.0620/100;
                case 'A- *-'	
                    out = 0.0690/100;
                case 'BBB+ *-'	
                    out = 0.0960/100;
                case 'BBB *-'	
                    out = 0.1190/100;
                case 'BBB- *-'	
                    out = 0.2440/100;
                case 'BB+ *-'	
                    out = 0.3570/100;
                case 'BB *-'	
                    out = 0.5780/100;
                case 'BB- *-'	
                    out = 1.2170/100;
                case 'B+ *-'	
                    out = 1.9870/100;
                case 'B *-'	
                    out = 2.9980/100;
                case 'B- *-'	
                    out = 5.1340/100;
                case 'CCC+'	
                    out = 30.2420/100;
                case 'AAAu *-'	
                    out = 0.0100/100;
                case 'AA+u *-'	
                    out = 0.0120/100;
                case 'AAu *-'	
                    out = 0.0160/100;
                case 'AA-u *-'	
                    out = 0.0600/100;
                case 'A+u *-'	
                    out = 0.0610/100;
                case 'Au *-'	
                    out = 0.0620/100;
                case 'A-u *-'	
                    out = 0.0690/100;
                case 'BBB+u *-'	
                    out = 0.0960/100;
                case 'BBBu *-' 
                    out = 0.1190/100;
                case 'BBB-u *-'	
                    out = 0.2440/100;
                case 'BB+u *-'	
                    out = 0.3570/100;
                case 'BBu *-'	
                    out = 0.5780/100;
                case 'BB-u *-'	
                    out = 1.2170/100;
                case 'B+u *-'	
                    out = 1.9870/100;
                case 'Bu *-'	
                    out = 2.9980/100;
                case 'B-u *-'	
                    out = 5.1340/100;
                case 'CC'	
                    out = 30.2420/100;
                case 'CCC-'	
                    out = 30.2420/100;
                otherwise
                    disp('No value assigned during the call to getPD(in)')
                    out = [];
            end
        end
    end
    methods (Access=public)
        function [TSM_estimate] = getCstar(TSM_estimate)
            % 
            % ... Calculating C* needed for the SAA term structure model
            %
            % ... calculate Q-measure probabilities
            %
            nObss = size(TSM_estimate.rating,1);
            TSM_estimate.pd  = NaN(nObss,1);
            for j=1:nObss
                TSM_estimate.pd(j,1) = getPDp(TSM_estimate,j);      % probability of default
            end
            TSM_estimate.Qpd        = cdf('Normal',(norminv(TSM_estimate.pd) + TSM_estimate.assetcorr.*TSM_estimate.sharperatio),0,1);    % translate P-prob to Q-prob
            TSM_estimate.econ.creditspreadraw10Y = TSM_estimate.lgd*100*( 1-( (1-cdf('Normal',(norminv(TSM_estimate.pd) + TSM_estimate.assetcorr.*TSM_estimate.sharperatio),0,1)).^10) );    % c-star measured in bps at the 10y maturity
            TSM_estimate.econ.creditspreadraw10Y = fillmissing(TSM_estimate.econ.creditspreadraw10Y,'nearest');
            TSM_estimate.econ.creditspread10Y    = max(hpfilter(TSM_estimate.econ.creditspreadraw10Y, TSM_estimate.hp_monthlysmoothing),0);         

            % ... determine inflation trend and cycle
            [TSM_estimate.econ.cpitrend, TSM_estimate.econ.cpicycle] = hpfilter(TSM_estimate.econ.cpi, TSM_estimate.hp_monthlysmoothing);      
            
            % ... determine industrial production trend and cycle 
            [TSM_estimate.econ.iptrend, TSM_estimate.econ.ipcycle] = hpfilter(TSM_estimate.econ.logip, TSM_estimate.hp_monthlysmoothing);
            
            % ... determine gdp trend and cycle
            [tmp1, tmp2] = hpfilter(TSM_estimate.econ.loggdp, TSM_estimate.hp_monthlysmoothing);  
            TSM_estimate.econ.gdptrend = TSM_estimate.econ.loggdp;                     % to make sure that NaNs are shown also in trend and cycle
            TSM_estimate.econ.gdpcycle = TSM_estimate.econ.loggdp;
            TSM_estimate.econ.gdptrend(~isnan(TSM_estimate.econ.gdptrend))=tmp1;
            TSM_estimate.econ.gdpcycle(~isnan(TSM_estimate.econ.gdpcycle))=tmp2;

            % ... interpolate quarterly gdp to monthly gdp using ip
            %macrodata                 = synchronize(cpi,ip,gdp);
            %macrodata                 = addvars(macrodata,creditspreadraw10Y,creditspread10Y,pd,Qpd);
            TSM_estimate.econ.gdptrend_interp = fillmissing(TSM_estimate.econ.gdptrend, 'pchip');
            TSM_estimate.econ.gdpcycle_interp = Q2M(TSM_estimate);                                               %TSM_estimate.econ.gdpcycle, TSM_estimate.econ.ipcycle);
            TSM_estimate.econ.gdpM            = TSM_estimate.econ.gdptrend_interp+TSM_estimate.econ.gdpcycle_interp;
            if (sum(ismissing(TSM_estimate.econ.gdpcycle_interp))>0)
                TSM_estimate.econ.gdpcycle_interp = fillmissing(TSM_estimate.econ.gdpcycle_interp, 'pchip');
            end
            % ... calculate R* and C*
            TSM_estimate = funRstar(TSM_estimate);     % TSM_estimate.econ.gdpcycle_interp, TSM_estimate.Yields(:,end), TSM_estimate.econ.cpi, TSM_estimate.econ.cpitrend, TSM_estimate.a1, TSM_estimate.a2
            [TSM_estimate.econ.rstartrend, TSM_estimate.econ.rstarcycle] = hpfilter(TSM_estimate.econ.Rstar, TSM_estimate.hp_monthlysmoothing); 
            TSM_estimate.econ.cstar_raw = TSM_estimate.econ.Rstar+ TSM_estimate.econ.creditspread10Y./100;
            TSM_estimate.Cstar          = TSM_estimate.econ.rstartrend + TSM_estimate.econ.creditspread10Y./100;                      % c.star is in bps and Rstar is in pct   
        end
        function [TSM_estimate] = getSAA(TSM_estimate)
            %
            % ... SAA model with C*
            %
            TSM_estimate.model = 'SAA';
            disp('... Estimating the SAA yield curve model including C* ');
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
            end
            if ( TSM_estimate.gridSearch==0 )
                [TSM_estimate] = runOptimSAA(TSM_estimate);
            else
                disp('... Estimating using grid search ');
                TSM_estimate = CheckInputs(TSM_estimate);
                if (TSM_estimate.nSegments==1)
                    q     = 1;
                    sList = (0.02:0.0005:0.100)';
                    gList = (0.90:0.0005:0.999)';
                    res = nan(size(sList,1)*size(gList,1),3);
                    for (k=1:size(sList,1))
                        for (z=1:size(gList,1))
                            tmp  = LoadingMatrix([sList(k,1);gList(k,1)],TSM_estimate);
                            F1   = tmp.b(:,2:3)\(TSM_estimate.Yields-(tmp.b(:,[1 4])*[TSM_estimate.Yields(:,1) TSM_estimate.Cstar(:,1)]')')' ;
                            F    = [TSM_estimate.Yields(:,1) F1' TSM_estimate.Cstar(:,1) ];
                            y_fit = (tmp.b*F')';
                            rmse  = (mean((TSM_estimate.Yields-y_fit).^2)).^0.50;  
                            res(q,:)  = [sList(k,1)  gList(k,1)  sum(rmse)];
                            q=q+1;
                        end
                    end
                    indx = find(res(:,3)==min(res(:,3)),1,'first');
                    TSM_estimate.s = res(indx,1);
                    TSM_estimate.g = res(indx,2);
                    tmp            = LoadingMatrix([TSM_estimate.s;TSM_estimate.g],TSM_estimate);
                    TSM_estimate.b = tmp.b;
                    F1             = TSM_estimate.b(:,2:3)\(TSM_estimate.Yields-(TSM_estimate.b(:,[1 4])*[TSM_estimate.Yields(:,1) TSM_estimate.Cstar(:,1)]')')' ;
                    TSM_estimate.Factors    = [ TSM_estimate.Yields(:,1) F1' ];
                    TSM_estimate.Yields_fit = (TSM_estimate.b*[TSM_estimate.Factors TSM_estimate.Cstar]')';
                    TSM_estimate.RMSE       = (mean((TSM_estimate.Yields-TSM_estimate.Yields_fit).^2)).^0.50; 
                    TSM_estimate.kP   = mean(TSM_estimate.Factors);
                    TSM_estimate.PhiP = ((TSM_estimate.Factors(1:end-1,:)-TSM_estimate.kP)\(TSM_estimate.Factors(2:end,:)-TSM_estimate.kP))';
                else
                    TSM_estimate.b = [TSM_estimate.bs(1:TSM_estimate.nTau(1,1),:), zeros(TSM_estimate.nTau(1,1),4); ...
                                      zeros(TSM_estimate.nTau(2,1),4), TSM_estimate.bs(TSM_estimate.nTau(1,1)+1:end,:) ];
                    TSM_estimate.Factors    = TSM_estimate.Fs;
                    TSM_estimate.Yields_fit = (TSM_estimate.b*TSM_estimate.Factors')';
                    TSM_estimate.RMSE       = (mean((TSM_estimate.Yields-TSM_estimate.Yields_fit).^2)).^0.50; 
                    TSM_estimate.kP   = mean(TSM_estimate.Factors);
                    TSM_estimate.PhiP = ((TSM_estimate.Factors(1:end-1,:)-TSM_estimate.kP)\(TSM_estimate.Factors(2:end,:)-TSM_estimate.kP))';
                end
                if (~isempty(TSM_estimate.Macro))
                    %TSM_estimate.xm = TSM_estimate.Macro\(TSM_estimate.Factors-TSM_estimate.kP); 
                    F_tmp      = (TSM_estimate.Factors(1:end-1,:)-TSM_estimate.kP)*TSM_estimate.PhiP'-(TSM_estimate.Factors(2:end,:)-TSM_estimate.kP);
                    F_tmp      = [0 0 0;F_tmp];
                    TSM_estimate.xm = TSM_estimate.Macro\F_tmp;
                    TSM_estimate.xm(1,1)=0;   % ignoring any impact from macro on the short rate
                end
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                [TSM_estimate]          = TermPremia(TSM_estimate);
                TSM_estimate.Yield_vol  = cov(TSM_estimate.Yields-TSM_estimate.Yields_fit);
                TSM_estimate.Factor_vol = cov(TSM_estimate.Factors(2:end,:)-(TSM_estimate.kP+(TSM_estimate.Factors(1:end-1,:)-TSM_estimate.kP)*TSM_estimate.PhiP'));
                disp('... Done')
            end
        end
        function [TSM_estimate] = getJSZ(TSM_estimate)
            %
            % ... Joslin, Singleton, Zhu (2011)
            %
            TSM_estimate.model = 'JSZ';
            disp(['... Estimating the JSZ model ']);
            TSM_estimate = CheckInputs(TSM_estimate);
            TSM_estimate = AllocateStartingValues(TSM_estimate);
            TSM_estimate.W       = pcacov(cov(TSM_estimate.Yields./100));
            TSM_estimate.W       = TSM_estimate.W(:,1:TSM_estimate.nF)';                % PCA weights
            TSM_estimate.Factors = (TSM_estimate.W'\(TSM_estimate.Yields./100)')';      % PCA factors
            TSM_estimate.kP      = [ mean(TSM_estimate.Factors,1)]';
            Xt                   = (TSM_estimate.Factors - repmat(TSM_estimate.kP',TSM_estimate.nObs,1))';
            TSM_estimate.PhiP    = (Xt(:,1:end-1)'\Xt(:,2:end)')'; 
            TSM_estimate.Factor_errors = TSM_estimate.Factors(2:end,:) - ( repmat(TSM_estimate.kP',TSM_estimate.nObs-1,1) + ...
                                    (TSM_estimate.PhiP*(TSM_estimate.Factors(1:end-1,:)-repmat(TSM_estimate.kP',TSM_estimate.nObs-1,1))')');
            TSM_estimate.Factor_vol = 1/TSM_estimate.nObs.*(TSM_estimate.Factor_errors'*TSM_estimate.Factor_errors);            
            %            
            % ... Bias correcting - if specified to be done 
            %
            if (TSM_estimate.pope==1)
                disp('... Bias correcting the VAR parameters')
                TSM_estimate = Pope(TSM_estimate);
            end
            %
            % ... estimating the Q-dynamics
            %
            [e2] = @(p0) runOptimJSZ(p0,TSM_estimate);
            % ... finding good starting values
            disp('... Trying to find good starting values ')
            nI   = 1e4;
            tmp0 = NaN(nI,TSM_estimate.nF+2); 
            parfor (zj=1:nI)
                x0          = [ 0.995;
                                0.90 + 0.10*rand();
                                0.90 + 0.10*rand();
                                0.03 ]; 
                tmp         = e2(x0);
                tmp0(zj,:)  = [tmp x0'];
            end
            indx = find(min(tmp0(:,1))==tmp0(:,1),1,'first'); 
            clear x0;
            x0   = tmp0(indx,2:end)';
            %x0 = [0.999;0.95;0.85;0.03];
            nP   = size(x0,1);               
            lb_ =  zeros(nP,1); lb_(1:TSM_estimate.nF,1) = 0.*ones(TSM_estimate.nF,1);
            ub_ =  inf(nP,1); ub_(1:TSM_estimate.nF,1)   = 1-1e-16.*ones(TSM_estimate.nF,1);
            Aeq_ = [];
            beq_ = [];
            
            options = optimoptions(@fmincon,'Algorithm','interior-point',...
                                            'MaxIterations',1e3, ...
                                            'MaxFunctionEvaluations',1e6, ...
                                            'TolFun', 1e-12, 'TolX', 1e-12, ...
                                            'display','iter');
            
            disp('... Estimating the model ')                            
            [pHat,~,flagg] = fmincon(e2,x0,[],[],Aeq_,beq_,lb_,ub_,[],options);   
            
            % ... generating the output
            [~,TSM_estimate]   = runOptimJSZ(pHat,TSM_estimate);
            rho0x         = 0;
            rho1x         = ones(TSM_estimate.nF,1);
            TSM_estimate.g     = diag(TSM_estimate.PhiQ); 
            TSM_estimate.rho0  = (100/TSM_estimate.dataFreq)*(rho0x - rho1x'*(TSM_estimate.W*TSM_estimate.bJordan)^(-1)*TSM_estimate.W*TSM_estimate.aJordan); 
            TSM_estimate.rho1  = ((100/TSM_estimate.dataFreq)*(rho1x'*(TSM_estimate.W*TSM_estimate.bJordan)^(-1)))';                                
            TSM_estimate.Yield_errors = TSM_estimate.Yields-TSM_estimate.Yields_fit;
            TSM_estimate.RMSE  = (mean(TSM_estimate.Yield_errors.^2)).^(0.5);
            [TSM_estimate]     = TermPremia(TSM_estimate);
            TSM_estimate.Yield_vol = 1/TSM_estimate.nObs*(TSM_estimate.Yield_errors'*TSM_estimate.Yield_errors);
            TSM_estimate.estFlag = flagg;
        end
        function [TSM_estimate] = getDNS(TSM_estimate)
            % 
            %... Dynamic Nelson-Siegel model
            % 
            TSM_estimate.model = 'DNS';
            disp(['... Estimating the Dynamic Nelson-Siegel model ']);
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
                [TSM_estimate] = runOptimSAA(TSM_estimate);  
            else
                TSM_estimate         = CheckInputs(TSM_estimate);
                TSM_estimate         = AllocateStartingValues(TSM_estimate);
                TSM_estimate.p0      = [ TSM_estimate.kP(:); TSM_estimate.PhiP(:); ...
                                    TSM_estimate.Factor_vol(:); TSM_estimate.Yield_vol(:); ...
                                    TSM_estimate.s(:); TSM_estimate.g(:); TSM_estimate.xm(:) ];
                TSM_estimate.p0count = cumsum([ 1;length(TSM_estimate.kP(:)); length(TSM_estimate.PhiP(:)); ...
                                    length(TSM_estimate.Factor_vol(:)); length(TSM_estimate.Yield_vol(:)); ...
                                    length(TSM_estimate.s(:)); length(TSM_estimate.g(:)); length(TSM_estimate.xm(:))]);
                L    = [0.0001:0.0001:0.25]';
                res_ = NaN(size(L,1),2); 
                for (j=1:size(L,1))
                    TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = L(j,1);
                    [TSM_estimate] = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                    res_(j,:) = [L(j,1) sum(sum((TSM_estimate.Yields-(TSM_estimate.b*(TSM_estimate.b\TSM_estimate.Yields'))').^2))];
                end
                indx = find(res_(:,2)==min(res_(:,2)));
                TSM_estimate.g       = res_(indx,1);
                TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1)=res_(indx,1);
                [TSM_estimate]       = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                [TSM_estimate]       = generateOutput(TSM_estimate);
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                [TSM_estimate]   = TermPremia(TSM_estimate);
            end
        end
        function [TSM_estimate] = getDSS(TSM_estimate)
            %
            % ... Dynamic Svensson-Soderlind model
            %
            warning ('off','all');
            TSM_estimate.model = 'DSS';
            disp(['... Estimating the Dynamic Svensson-Soderlind model ']);
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
                [TSM_estimate] = runOptimSAA(TSM_estimate);  
            else
                TSM_estimate         = CheckInputs(TSM_estimate);
                TSM_estimate         = AllocateStartingValues(TSM_estimate);
                TSM_estimate.p0      = [ TSM_estimate.kP(:); TSM_estimate.PhiP(:); ...
                                    TSM_estimate.Factor_vol(:); TSM_estimate.Yield_vol(:); ...
                                    TSM_estimate.s(:); TSM_estimate.g(:); TSM_estimate.xm(:) ];
                TSM_estimate.p0count = cumsum([ 1;length(TSM_estimate.kP(:)); length(TSM_estimate.PhiP(:)); ...
                                    length(TSM_estimate.Factor_vol(:)); length(TSM_estimate.Yield_vol(:)); ...
                                    length(TSM_estimate.s(:)); length(TSM_estimate.g(:)); length(TSM_estimate.xm(:))]);
                L1   = [0.01:0.01:0.25]';
                L2   = [0.01:0.01:0.25]';
                res_ = NaN(size(L1,1)^2,3);
                z    = 1;
                for (j=1:size(L1,1))
                    for (k=1:size(L2,1))
                        TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = [L1(j,1);L2(k,1)];
                        [TSM_estimate] = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                        res_(z,:) = [L1(j,1) L2(k,1) sum(sum((TSM_estimate.Yields-(TSM_estimate.b*(TSM_estimate.b\TSM_estimate.Yields'))').^2))];
                        z         = z+1;
                    end
                end
                indx = find(res_(:,3)==min(res_(:,3)));
                TSM_estimate.g       = res_(indx,1:2)';
                TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1)=res_(indx,1:2);
                [TSM_estimate]       = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                [TSM_estimate]       = generateOutput(TSM_estimate);
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                [TSM_estimate]   = TermPremia(TSM_estimate);
            end   
        end
        function [TSM_estimate] = getSRB3(TSM_estimate)
            % 
            %... Dynamic Short Rate Based model
            % 
            TSM_estimate.model = 'SRB3';
            disp(['... Estimating the SRB3 model ']);
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
                [TSM_estimate] = runOptimSAA(TSM_estimate);  
            else
                TSM_estimate         = CheckInputs(TSM_estimate);
                TSM_estimate         = AllocateStartingValues(TSM_estimate);
                TSM_estimate.p0      = [ TSM_estimate.kP(:); TSM_estimate.PhiP(:); ...
                                    TSM_estimate.Factor_vol(:); TSM_estimate.Yield_vol(:); ...
                                    TSM_estimate.s(:); TSM_estimate.g(:); TSM_estimate.xm(:) ];
                TSM_estimate.p0count = cumsum([ 1;length(TSM_estimate.kP(:)); length(TSM_estimate.PhiP(:)); ...
                                    length(TSM_estimate.Factor_vol(:)); length(TSM_estimate.Yield_vol(:)); ...
                                    length(TSM_estimate.s(:)); length(TSM_estimate.g(:)); length(TSM_estimate.xm(:))]);
                L    = [0.70:0.0001:0.9999]';
                res_ = NaN(size(L,1),2); 
                for (j=1:size(L,1))
                    TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = L(j,1);
                    [TSM_estimate] = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                    res_(j,:) = [L(j,1) sum(sum((TSM_estimate.Yields-(TSM_estimate.b*(TSM_estimate.b\TSM_estimate.Yields'))').^2))];
                end
                indx = find(res_(:,2)==min(res_(:,2)));
                TSM_estimate.g       = res_(indx,1);
                TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1)=res_(indx,1);
                [TSM_estimate]       = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                [TSM_estimate]       = generateOutput(TSM_estimate);
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                [TSM_estimate]   = TermPremia(TSM_estimate);
            end
        end   
        function [TSM_estimate] = getSRB4(TSM_estimate) 
            %
            % ... Short Rate Based 4 factor model 
            %
            warning ('off','all');
            TSM_estimate.model = 'SRB4';
            disp(['... Estimating the SRB4 model ']);
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
                [TSM_estimate] = runOptimSAA(TSM_estimate);  
            else
                TSM_estimate         = CheckInputs(TSM_estimate);
                TSM_estimate         = AllocateStartingValues(TSM_estimate);
                TSM_estimate.p0      = [ TSM_estimate.kP(:); TSM_estimate.PhiP(:); ...
                                    TSM_estimate.Factor_vol(:); TSM_estimate.Yield_vol(:); ...
                                    TSM_estimate.s(:); TSM_estimate.g(:); TSM_estimate.xm(:) ];
                TSM_estimate.p0count = cumsum([ 1;length(TSM_estimate.kP(:)); length(TSM_estimate.PhiP(:)); ...
                                    length(TSM_estimate.Factor_vol(:)); length(TSM_estimate.Yield_vol(:)); ...
                                    length(TSM_estimate.s(:)); length(TSM_estimate.g(:)); length(TSM_estimate.xm(:))]);
                L1   = [0.70:0.01:0.99]';
                L2   = [0.70:0.01:0.99]';
                res_ = NaN(size(L1,1)^2,2);
                z    = 1;
                for (j=1:size(L1,1))
                    TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1) = [L1(j,1)];
                    [TSM_estimate] = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                    res_(z,:) = [L1(j,1) sum(sum((TSM_estimate.Yields-(TSM_estimate.b*(TSM_estimate.b\TSM_estimate.Yields'))').^2))];
                    z         = z+1;
                end
                indx = find(res_(:,2)==min(res_(:,2)));
                TSM_estimate.g       = res_(indx,1:2)';
                TSM_estimate.p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1)=res_(indx,1);
                [TSM_estimate]       = LoadingMatrix(TSM_estimate.p0,TSM_estimate);
                [TSM_estimate]       = generateOutput(TSM_estimate);
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                [TSM_estimate]   = TermPremia(TSM_estimate);
            end  
        end
        function [TSM_estimate] = getAFSRB(TSM_estimate)
            %                
            % ... Arbitrage-free Short Rate Based model (2,3, and 4 factors) 
            %
            TSM_estimate.model = 'AFSRB';
            disp(['... Estimating the AFSRB model ']);
            if (~isempty(TSM_estimate.rLow))
                disp('... with a shadow short rate ');
                [TSM_estimate] = runOptimAFSRB(TSM_estimate);  
            else
                TSM_estimate = CheckInputs(TSM_estimate);
                TSM_estimate = AllocateStartingValues(TSM_estimate);
                %
                % ... Finding the optimal shape parameter
                %
                g1  = ( 0.90:0.0001:0.99 )';
                tmp = zeros(length(g1),2);
                disp('... Find optimal shaping parameter')
                for (k=1:length(g1))
                    TSM_estimate.g    = g1(k,1);
                    [ TSM_estimate ]  = LoadingMatrix(0,TSM_estimate);
                    tmp(k,:)  = [ TSM_estimate.g(1,1) sum(sum((TSM_estimate.Yields-(TSM_estimate.b*(TSM_estimate.b\TSM_estimate.Yields'))').^2)) ];
                end    
                indx      = find(tmp(:,2)==min(tmp(:,2)),1,'first');
                TSM_estimate.g = tmp(indx,1); 
                [TSM_estimate] = LoadingMatrix(0,TSM_estimate);
                [TSM_estimate] = generateOutput(TSM_estimate);
                if (TSM_estimate.pope==1)
                    disp('... Bias correcting the VAR parameters')
                    TSM_estimate = Pope(TSM_estimate);
                end
                %
                % ... Estimating the remaining parameters (mQ)
                %
                Fx_err2  = @(p0) runOptimAFSRB(p0,TSM_estimate);
                x0       = zeros(TSM_estimate.nF,1);
                lb_      = -10*ones(TSM_estimate.nF,1);
                ub_      =  10*ones(TSM_estimate.nF,1);
                Aeq_     = [zeros(TSM_estimate.nF-1,1) eye(TSM_estimate.nF-1,TSM_estimate.nF-1)];
                beq_     = zeros(TSM_estimate.nF-1,1); 
                options  = optimoptions(@fmincon,'Algorithm','interior-point',...
                                                     'MaxIterations',1e6, ...
                                                     'MaxFunctionEvaluations',1e6, ...
                                                     'TolFun', 1e-12, 'TolX', 1e-12, ...
                                                     'display','iter');

                disp('... Estimating ')                            
                [pHat] = fmincon(Fx_err2,x0,[],[],Aeq_,beq_,lb_,ub_,[],options);   
                [ ~, TSM_estimate ] = runOptimAFSRB(pHat,TSM_estimate);         
                switch TSM_estimate.nF
                    case 2
                        TSM_estimate.PhiQ = [ 1 1-TSM_estimate.g; 0 TSM_estimate.g];
                    case 3
                        TSM_estimate.PhiQ = [ 1   1-TSM_estimate.g   1-TSM_estimate.g    ; ...
                                         0     TSM_estimate.g     TSM_estimate.g-1  ; ...
                                         0      0            TSM_estimate.g   ];
                    case 4
                        TSM_estimate.PhiQ = [ 1   1-TSM_estimate.g   1-TSM_estimate.g    1-TSM_estimate.g    ; ...
                                         0     TSM_estimate.g     TSM_estimate.g-1    TSM_estimate.g-1  ; ...
                                         0      0            TSM_estimate.g      TSM_estimate.g-1  ;
                                         0      0             0             TSM_estimate.g   ];                    
                end
                [TSM_estimate] = TermPremia(TSM_estimate);    
            end
        end
        function [TSM_estimate] = LoadingMatrix(p0,TSM_estimate)
            %
            % Allocates .a and .b on the basis of the model to be estimated
            %
            % .a : sum(.nTau) -by- 1
            % .b : sum(.nTau) -by- sum(.nF)
            %
            if (strcmp(TSM_estimate.model,'SAA') || ...
                strcmp(TSM_estimate.model,'DNS') || strcmp(TSM_estimate.model,'DSS') || ...
                strcmp(TSM_estimate.model,'SRB3') || strcmp(TSM_estimate.model,'SRB4'))
                if (strcmp(TSM_estimate.model,'SAA'))
                    if (TSM_estimate.gridSearch==1)
                        ss  = p0(1,1);
                        gg  = p0(2,1);
                    else                
                        ss  = p0(TSM_estimate.p0count(5):TSM_estimate.p0count(6)-1);          % smoothing constant for R*
                        gg  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);          % eigenvalue of PhiQ 
                   end
                    H_SAA_Y_1 = @(p,n) [ (1-(1-p).^n)./(p.*n) ];                % short rate 
                    H_SAA_Y_2 = @(p,n) [ 1-(1-p.^n)./((1-p).*n) ];              % term premium slope component
                    H_SAA_Y_3 = @(p,n) [ (1-p.^n)./((1-p).*n) - p.^(n-1) ];     % term premium curvature component 
                    H_SAA_Y_4 = @(p,n) [((1-p).^n + p.*n -1)./(p.*n) ];         % C-star 
                end
                if (strcmp(TSM_estimate.model,'DNS'))
                    ss  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);          % time-decay parameters
                    gg  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);          % to cater for the below structure of the loading matrix calculation
                    H_SAA_Y_1 = @(p,n) [ ones(size(n,1),1) ];                   % level  
                    H_SAA_Y_2 = @(p,n) [ (1-exp(-p.*n))./(p.*n) ];              % slope 
                    H_SAA_Y_3 = @(p,n) [ (1-exp(-p.*n))./(p.*n) - exp(-p.*n)];  % curvature              
                    H_SAA_Y_4 = @(p,n) [ zeros(size(n,1),1)];
                end
                if (strcmp(TSM_estimate.model,'DSS'))
                    ss  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % time-decay parameters
                    gg  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % to cater for the below structure of the loading matrix calculation     
                    H_SAA_Y_1 = @(p,n) [ ones(size(n,1),1) ];                    % level  
                    H_SAA_Y_2 = @(p,n) [ (1-exp(-p.*n))./(p.*n) ];               % slope 
                    H_SAA_Y_3 = @(p,n) [ (1-exp(-p.*n))./(p.*n) - exp(-p.*n) ];  % curvature 1             
                    H_SAA_Y_4 = @(p,n) [ (1-exp(-p.*n))./(p.*n) - exp(-p.*n) ];  % curvature 2
                end
                if (strcmp(TSM_estimate.model,'SRB3'))
                    ss  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % time-decay parameters
                    gg  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % to cater for the below structure of the loading matrix calculation     
                    H_SAA_Y_1 = @(p,n) [ ones(size(n,1),1) ];                            % level  
                    H_SAA_Y_2 = @(p,n) [ 1-(1-p.^n)./((1-p).*n) ];               % slope 
                    H_SAA_Y_3 = @(p,n) [ -(p.^(n-1))+(1-p.^n)./((1-p).*n) ];     % curvature 1             
                    H_SAA_Y_4 = @(p,n) [ zeros(size(n,1),1) ];                   % curvature 2
                end 
                if (strcmp(TSM_estimate.model,'SRB4'))
                    ss  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % time-decay parameters
                    gg  = p0(TSM_estimate.p0count(6):TSM_estimate.p0count(7)-1);           % to cater for the below structure of the loading matrix calculation     
                    H_SAA_Y_1 = @(p,n) [ ones(size(n,1),1) ];                            % level  
                    H_SAA_Y_2 = @(p,n) [ 1-(1-p.^n)./((1-p).*n) ];               % slope 
                    H_SAA_Y_3 = @(p,n) [ -(p.^(n-1))+(1-p.^n)./((1-p).*n) ];     % curvature 1             
                    H_SAA_Y_4 = @(p,n) [ -0.5.*(n-1).*(p-1).*p.^(n-2) ];         % curvature 2 
                end                
                TSM_estimate.a = zeros(sum(TSM_estimate.nTau),1);
                TSM_estimate.b = zeros(sum(TSM_estimate.nTau),sum(TSM_estimate.nF)+size(TSM_estimate.Cstar,2));
                if (TSM_estimate.nSegments==1)
                    j=1;
                    TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-3) = H_SAA_Y_1(ss(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                    TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-2) = H_SAA_Y_2(gg(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                    TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-1) = H_SAA_Y_3(gg(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                    TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-0) = H_SAA_Y_4(ss(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                else
                   for (j=1:TSM_estimate.nSegments)
                       TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),3*j-2) = H_SAA_Y_1(ss(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                       TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),3*j-1) = H_SAA_Y_2(gg(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                       TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),3*j-0) = H_SAA_Y_3(gg(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                   end
                   k=0;
                   for (j=3*TSM_estimate.nSegments+1:3*TSM_estimate.nSegments+size(TSM_estimate.Cstar,2))
                       k=k+1;
                       TSM_estimate.b(TSM_estimate.s_(k,1):TSM_estimate.e_(k,1),j) = H_SAA_Y_4(ss(k),TSM_estimate.tau(TSM_estimate.s_(k,1):TSM_estimate.e_(k,1)));
                   end
                end
                if (strcmp(TSM_estimate.model,'DNS')||strcmp(TSM_estimate.model,'SRB3') )
                    indx = (4:4:TSM_estimate.nSegments*4);
                    TSM_estimate.b(:,indx) = [];        
                end
                if (strcmp(TSM_estimate.model,'DSS')||strcmp(TSM_estimate.model,'SRB4'))
                    indx = (5:5:TSM_estimate.nSegments*5);
                    TSM_estimate.b(:,indx) = []; 
                    if (strcmp(TSM_estimate.model,'DSS'))
                        TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-0) = H_SAA_Y_4(gg(j+1),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));                    
                    elseif (strcmp(TSM_estimate.model,'SRB4'))
                        TSM_estimate.b(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1),4*j-0) = H_SAA_Y_4(gg(j),TSM_estimate.tau(TSM_estimate.s_(j,1):TSM_estimate.e_(j,1)));
                    end                
                end
            end
            if (strcmp(TSM_estimate.model,'JSZ'))
                %
                % The recursive equations for the factor 
                % loadings in the JSZ yield equation, 
                % i.e. based on the Jordan form. 
                % 
                % kQ is the mean of the process i.e. kQ=(I-PhiQ)^-1 * cQ
                %
                nDiv    = ( 1:1:max(TSM_estimate.tau)*TSM_estimate.dataFreq/12 )';
                An      = NaN( size(nDiv,1), 1 );            % NaN( TSM_estimate.tau(end,1), 1 );
                Bn      = NaN( TSM_estimate.nF, size(nDiv,1));    % NaN( TSM_estimate.nF, TSM_estimate.tau(end,1) );
                An(1,1) = TSM_estimate.rho0./TSM_estimate.dataFreq;
                Bn(:,1) = TSM_estimate.rho1./TSM_estimate.dataFreq;
                I       = eye(TSM_estimate.nF);
                for (j=2:size(nDiv,1))                        %( j=2:TSM_estimate.tau(end,1) )
                    An(j,1) = An(j-1,1) + Bn(:,j-1)'*((I-TSM_estimate.PhiQ)*TSM_estimate.kQ) + ... 
                                     0.5*Bn(:,j-1)'*(TSM_estimate.Factor_vol)*Bn(:,j-1); 
                    if ( real(max(eig(TSM_estimate.PhiQ)))<1 )
                        Bn(:,j) = -(( I - TSM_estimate.PhiQ^(j) )*( I - TSM_estimate.PhiQ )^(-1))'*(TSM_estimate.rho1./TSM_estimate.dataFreq);
                    else
                        tmp = zeros(TSM_estimate.nF,TSM_estimate.nF);
                        for ( k=0:j-1 )
                            tmp = tmp+TSM_estimate.PhiQ^(k);
                        end
                        Bn(:,j) = -tmp'*(TSM_estimate.rho1./TSM_estimate.dataFreq);
                    end
                end
                A = -An./nDiv;    %-An./(nDiv*TSM_estimate.dataFreq/12);   
                B = -Bn'./nDiv;   %-Bn'./(nDiv*TSM_estimate.dataFreq/12);  
                TSM_estimate.aJordan = A(TSM_estimate.tau*TSM_estimate.dataFreq/12,1);    % A(TSM_estimate.tau,1);
                TSM_estimate.bJordan = B(TSM_estimate.tau*TSM_estimate.dataFreq/12,:);    % B(TSM_estimate.tau,:)
            end
            if (strcmp(TSM_estimate.model,'AFSRB'))
                % 
                % Loadings for the AFSRB models
                %
                An  = zeros( TSM_estimate.tau(end,1), 1 );
                Bn  = NaN( TSM_estimate.nF, TSM_estimate.tau(end,1) );
                g_  = TSM_estimate.g(1);
                n_  = (1:1:TSM_estimate.tau(end,1)*TSM_estimate.dataFreq/12)';
                i_  = ones(max(n_),1);
                switch TSM_estimate.nF
                    case 2
                        Bn = -[ n_,  n_-(i_-g_.^n_)./(i_-g_) ];
                    case 3
                        Bn = -[ n_,  n_-(i_-g_.^n_)./(i_-g_),   -n_.*g_.^(n_-1) + ( i_-g_.^n_)./ (1-g_) ];   
                    case 4
                        Bn = -[ n_,  n_-(i_-g_.^n_)./(i_-g_),  - n_.*g_.^(n_-1) + ( i_-g_.^n_)./ (1-g_) ...
                                 -(n_./2).*(n_-i_).*(g_-1).*g_.^(n_-2) ];  
                end
                TSM_estimate.b = -Bn(TSM_estimate.tau,:)./repmat(TSM_estimate.tau,1,TSM_estimate.nF);
                for ( j=2:max(n_) )
                    An(j,1) = An(j-1,1) + Bn(j,:)* TSM_estimate.kQ(1:TSM_estimate.nF,1) + 1/2.*Bn(j,:)*(TSM_estimate.Factor_vol(1:TSM_estimate.nF,1:TSM_estimate.nF))*Bn(j,:)';      % d0=0 in this model
                end
                TSM_estimate.a = -(1/(100*TSM_estimate.dataFreq)).*An(TSM_estimate.tau,1)./TSM_estimate.tau;    
            end
        end     
    end
end