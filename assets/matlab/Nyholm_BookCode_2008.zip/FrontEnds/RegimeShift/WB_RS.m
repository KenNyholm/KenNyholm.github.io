function varargout = WB_RS(varargin)
% WB_RS M-file for WB_RS.fig
%      WB_RS, by itself, creates a new WB_RS or raises the existing
%      singleton*.
%
%      H = WB_RS returns the handle to a new WB_RS or the handle to
%      the existing singleton*.
%
%      WB_RS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WB_RS.M with the given input arguments.
%
%      WB_RS('Property','Value',...) creates a new WB_RS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before WB_RS_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to WB_RS_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help WB_RS

% Last Modified by GUIDE v2.5 26-Sep-2008 14:04:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @WB_RS_OpeningFcn, ...
                   'gui_OutputFcn',  @WB_RS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before WB_RS is made visible.
function WB_RS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to WB_RS (see VARARGIN)

% Choose default command line output for WB_RS
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes WB_RS wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = WB_RS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function nMaturities_edit_Callback(hObject, eventdata, handles)
% hObject    handle to nMaturities_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nMaturities_edit as text
%        str2double(get(hObject,'String')) returns contents of nMaturities_edit as a double
handles.nMaturities = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function nMaturities_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nMaturities_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nYields_edit_Callback(hObject, eventdata, handles)
% hObject    handle to nYields_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nYields_edit as text
%        str2double(get(hObject,'String')) returns contents of nYields_edit as a double
handles.nYields = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function nYields_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nYields_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% ..... Populating the input data area
%

function populate_button_Callback(hObject, eventdata, handles)
% hObject    handle to populate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles           = guidata(hObject);
 
    
    
    
nMaturities       = handles.nMaturities;
nYields           = handles.nYields;

tst               = get(handles.auto_panel,'SelectedObject');
handles.Auto_     = get(tst,'String');
tst1              = get(handles.macro_panel,'SelectedObject');
handles.MacroVar_ = get(tst1,'String');

dat_mat         = nan(nMaturities,1);
dat_Y           = nan(nYields,nMaturities);
for ( j=1:nMaturities )
    colnames(1,j) = cellstr(strcat('Y_tau ', num2str(j)));
end

% ... populate input area
uicontrol('Style','text','String','Enter Maturities', 'Position', [315 550 85 15]);
uitable_maturities = uitable(dat_mat, {'tau'}, 'Position', [310 315 105 230]);
uicontrol('Style','text','String','Enter Yields', 'Position', [600 550 100 15]);
uitable_Yields     = uitable(dat_Y, colnames,'Position', [430 315 385 230]);


uitable_params = [];
if ( strcmp(handles.Auto_, 'No') )
    title_(1,1) = cellstr('Param'); title_(1,2) = cellstr('Lower'); title_(1,3) = cellstr('Upper');  
    m_ = nan(4,3);
    uicontrol('Style','text','String','Enter Starting Values, lower and upper bounds', 'Position', [315 230 250 15]);
    uitable_params = uitable(m_, title_, 'Position', [310 135 255 90]); 
end
uitable_MacroVars = [];
uitable_cutoff    = [];

if ( strcmp(handles.MacroVar_,'Yes') )
    title1_(1,1) = cellstr('GDP'); title1_(1,2) = cellstr('CPI');  
    m1_ = nan(nYields,2);
    uicontrol('Style','text','String','Enter Macro Variables', 'Position', [580 230 270 15]);
    uitable_MacroVars = uitable(m1_, title1_, 'Position', [615 20 200 210]);       

    title2_(1,1) = cellstr('GDP'); title2_(1,2) = cellstr('CPI');  
    m2_ = nan(1,2);
    uicontrol('Style','text','String','Enter Macro cut-offs', 'Position', [280 65 250 15]);
    uitable_cutoff = uitable(m2_, title2_, 'Position', [310 20 180 40]);      
end

handles.uitable_MacroVars  = uitable_MacroVars;
handles.uitable_cutoff     = uitable_cutoff; 
handles.uitable_maturities = uitable_maturities;
handles.uitable_Yields     = uitable_Yields;
handles.uitable_params     = uitable_params;
handles.load= 0; %Indicates that the data has not been loaded from a file 
guidata(hObject,handles)


% --- Executes on button press in estimate_button.
%
% ..... Calling the optimisation function and reports resuults
%
function estimate_button_Callback(hObject, eventdata, handles)
% hObject    handle to estimate_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles   = guidata(hObject);

switch get(get(handles.transform_panel,'SelectedObject'),'String')   % Get Tag of selected object
        case 'Yes'
            User.transform=1;
            handles.in_.transform=1;
        case 'No'
            User.transform=0;
            handles.in_.transform=0;
end

switch handles.load
    case 0
        tau       = str2double(cell(handles.uitable_maturities.getData));
        Y         = str2double(cell(handles.uitable_Yields.getData));
        lambda    = handles.Lambda;

        if ( strcmp(handles.MacroVar_, 'Yes') )
            User.macro = 1;
            Macro     = str2double(cell(handles.uitable_MacroVars.getData));
            cut_Macro = str2double(cell(handles.uitable_cutoff.getData));
        else 
            User.macro = 0;
            Macro      = [];
            cut_Macro  = [];
        end
    case 1
        tau       = handles.in_.tau;
        Y         = handles.in_.Y;
        lambda    = handles.Lambda;

        if ( strcmp(handles.MacroVar_, 'Yes') )
            User.macro = 1;
            Macro     = handles.in_.Macro;
            cut_Macro  = handles.in_.cut_Macro;
        else 
            User.macro = 0;
            Macro      = [];
            cut_Macro  = [];
        end
    otherwise
        msgbox('Something went wrong.... Check the input data')
end
                
            
if ( strcmp(handles.Auto_, 'Yes') )
    User.auto = 1;
    User.m    = [];
    User.ml   = [];
    User.mu   = [];
else
    params    = str2double(cell(handles.uitable_params.getData));
    User.auto = 0;
    User.m    = params(:,1);
    User.ml   = params(:,2);
    User.mu   = params(:,3); 
end

try
    [out_] = WB_RS_code(Y, Macro, cut_Macro, tau, lambda, User)
    msgbox('The estimation has been completed succesfully.')
    % ... Adding estimates to structure
    handles.est_.pr=out_.pr;
    handles.est_.beta=out_.beta;
    handles.est_.params=out_.params;
    handles.est_.se=out_.se;
    handles.est_.P_plain=out_.P_plain;
    handles.est_.P_main=out_.P_main;
    handles.est_.P_inf=out_.P_inf;
    handles.est_.P_rec=out_.P_rec;
    handles.est_.AR_mat=out_.AR_mat;
    handles.est_.res_Beta=out_.res_Beta;
    handles.est_.Beta_res_Cov=out_.Beta_res_Cov;
    handles.est_.est=out_.est;
    handles.est_.sd_err_Y=out_.sd_err_Y;
    
    
catch
    msgbox('Something went wrong....')
end




set(handles.save_menu,'Enable','on');

guidata(hObject,handles);

% --- Executes on button press in auto_yes_button.
function auto_yes_button_Callback(hObject, eventdata, handles)
% hObject    handle to auto_yes_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of auto_yes_button




function lambda_edit_Callback(hObject, eventdata, handles)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lambda_edit as text
%        str2double(get(hObject,'String')) returns contents of lambda_edit as a double
handles.Lambda = str2double(get(hObject,'String'));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function lambda_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lambda_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in disp_button.
function disp_button_Callback(hObject, eventdata, handles)
% hObject    handle to disp_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    out_=handles.est_;
    figure
    plot(out_.beta), title('Estimated Nelson-Siegel factors');
    figure
    plot(out_.pr), title('Estimated state probabilities');
    figure
    uitable(out_.beta, {'Level', 'Slope', 'Curvature'}, 'Position', [5 30 270 350]);
    uicontrol('Style','text','String','Factors', 'Position', [70 385 80 15]);  
    uitable(out_.pr, {'State1', 'State2', 'State3'}, 'Position', [285 30 270 350]);
    uicontrol('Style','text','String','Regime Probs.', 'Position', [320 385 100 15]);  

    figure
    uitable(out_.AR_mat(1:3,1:3), {'Level', 'Slope', 'Curvature'}, 'Position', [5 300 245 70]);
    uicontrol('Style','text','String','AR coefficients (Level, Slope, Curvature)', 'Position', [10 380 200 15]);  
    uitable(out_.Beta_res_Cov(1:3,1:3), {'Level', 'Slope', 'Curvature'}, 'Position', [260 300 245 70]);
    uicontrol('Style','text','String','Cov matrix for state-equation residuals (Level, Slope, Curvature)', 'Position', [260 380 300 15]);  

    figure
    uitable(out_.params(1:3,1:3), {'State1', 'State2', 'State3'}, 'Position', [5 300 245 70]);
    uicontrol('Style','text','String','Parameters (Level, Slope, Curvature)', 'Position', [10 380 200 15]);  
    uitable([out_.est(4,1); out_.est(4,1); out_.est(4,1) ], {'Stdev'}, 'Position', [265 300 95 70]);

    if ( strcmp(handles.MacroVar_, 'Yes') )
        uicontrol('Style','text','String','Transition Prob. Norm', 'Position', [10 275 200 15]);  
        uitable(out_.P_main, {'State1', 'State2', 'State3'}, 'Position', [10 200 245 70]);
        uicontrol('Style','text','String','Transition Prob. Recession', 'Position', [260 275 200 15]);  
        uitable(out_.P_rec, {'State1', 'State2', 'State3'}, 'Position', [260 200 245 70]);
        uicontrol('Style','text','String','Transition Prob. Inflation', 'Position', [260 175 200 15]);  
        uitable(out_.P_inf, {'State1', 'State2', 'State3'}, 'Position', [260 100 245 70]);

        
    else
        uicontrol('Style','text','String','Transition Probabilities', 'Position', [10 275 200 15]);  
        uitable(out_.P_plain, {'State1', 'State2', 'State3'}, 'Position', [10 200 245 70]);
    end
catch
    msgbox('Something went wrong....Have you run the estimation or loaded estimates from a.mat file?')
end






% --------------------------------------------------------------------
function data_menu_Callback(hObject, eventdata, handles)
% hObject    handle to data_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function load_menu_Callback(hObject, eventdata, handles)
% hObject    handle to load_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles     = guidata(hObject);

h=msgbox({  'Load a file with a .mat extension, containing at least the input variables needed for running this tool in auto mode and with macro variables, labelled as structure.variable:';...
            '  est_.lambda: NS lambda value (1-by-1), estimated with the NS WB';...
            '  in_.Y: Yield curve data (nObs-by-nTau)';...
            '  in_.tau: maturities corresponding to Y (nTau-by-1)';...
            '  in_.Macro: GDP and CPI growth rates (nObs-by-2)';...
            '  in_.cut_Macro: cut-off values for the macro variables (GDP, CPI)'});
uiwait(h);
[name path]=uigetfile('*.mat') ; 
fullname=strcat(path,name);
load('-mat', fullname);
handles.fullname=fullname;

% ... Unpackaging data and populating input area

try
    handles.in_=in_;
    handles.est_=est_;
    [nYields nMaturities]=size(in_.Y);
    handles.nMaturities=nMaturities;
    handles.nYields=nYields;
    handles.Lambda=est_.lambda;
    set(handles.nMaturities_edit,'String',nMaturities);
    set(handles.nYields_edit,'String',nYields);
    set(handles.lambda_edit,'String',est_.lambda);
    tst               = get(handles.auto_panel,'SelectedObject');
    handles.Auto_     = get(tst,'String');
    tst1              = get(handles.macro_panel,'SelectedObject');
    handles.MacroVar_ = get(tst1,'String');

    dat_mat         = in_.tau;
    dat_Y           = in_.Y;
    for ( j=1:nMaturities )
        colnames(1,j) = cellstr(strcat('Y_tau ', num2str(j)));
    end

    % ... populate input area
    uicontrol('Style','text','String','Loaded Maturities', 'Position', [315 550 85 15]);
    uitable_maturities_load = uitable(dat_mat, {'tau'}, 'Position', [310 315 105 230]);
    uicontrol('Style','text','String','Loaded Yields', 'Position', [600 550 100 15]);
    uitable_Yields_load     = uitable(dat_Y, colnames,'Position', [430 315 385 230]);
    uitable_maturities_load.Editable=0;
    uitable_Yields_load.Editable=0;
    


    uitable_params = [];
    if ( strcmp(handles.Auto_, 'No') )
        title_(1,1) = cellstr('Param'); title_(1,2) = cellstr('Lower'); title_(1,3) = cellstr('Upper');  
        m_ = nan(4,3);
        uicontrol('Style','text','String','Enter Starting Values, lower and upper bounds', 'Position', [315 230 250 15]);
        uitable_params = uitable(m_, title_, 'Position', [310 135 255 90]);   
    end
    uitable_MacroVars_load = [];
%     uitable_cutoff_load    = [];
    if ( strcmp(handles.MacroVar_,'Yes') )
        title1_(1,1) = cellstr('GDP'); title1_(1,2) = cellstr('CPI');  
        m1_ = in_.Macro;
        uicontrol('Style','text','String','Loaded Macro Variables', 'Position', [580 230 270 15]);
        uitable_MacroVars_load = uitable(m1_, title1_, 'Position', [615 20 200 210]);  
        uitable_MacroVars_load.Editable=0;

        title2_(1,1) = cellstr('GDP'); title2_(1,2) = cellstr('CPI');  
        m2_ = in_.cut_Macro;
        uicontrol('Style','text','String','Loaded Macro cut-offs', 'Position', [280 65 250 15]);
        uitable_cutoff_load = uitable(m2_, title2_, 'Position', [310 20 180 40]); 
        uitable_cutoff_load.Editable=0;
    end

    handles.uitable_params     = uitable_params;
    handles.load= 1; % Indicates that the data has been loaded.

    handles.uitable_params     = uitable_params;

    
catch
    msgbox('Something went wrong..... Please check the input file.')
end
guidata(hObject,handles)
% --------------------------------------------------------------------
function save_menu_Callback(hObject, eventdata, handles)
% hObject    handle to save_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[name,path] = uiputfile('*.mat','Save as',handles.fullname);
fullname=strcat(path,name);


save(fullname,'-struct','handles','in_','est_');

% --------------------------------------------------------------------
function help_menu_Callback(hObject, eventdata, handles)
% hObject    handle to help_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

help WB_RS_code

% --------------------------------------------------------------------
function WB_menu_Callback(hObject, eventdata, handles)
% hObject    handle to WB_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function WB_Macro_menu_Callback(hObject, eventdata, handles)
% hObject    handle to WB_Macro_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
WB_Macro




% --------------------------------------------------------------------
function WB_forecasting_menu_Callback(hObject, eventdata, handles)
% hObject    handle to WB_forecasting_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

WB_forecasting
% --------------------------------------------------------------------
function WB_Spreads_menu_Callback(hObject, eventdata, handles)
% hObject    handle to WB_Spreads_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

WB_Spreads
