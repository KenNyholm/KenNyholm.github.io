%   -------------------------------------------------
%  ---------- Shell file for IPT06_yld2beta ----------
%   -------------------------------------------------
%
%  Calls the following files:
%       [out_]                   = IPT06_yld2beta(Prob)         
%       [ln_lik, Beta_TT, F, pr] = IPT06_yld2beta_likeli(S_param)
%
%
% Purpose: 
%       To estimate the Nelson-Siegel yield curve factors from yield curve
%       data, consisting of multiple yield curve segments and possibly
%       exhibiting regime switching behaviour
%           
% Inputs from structure Prob:
%       Y                 : Collects all yield curves [nobs, sum(ntau)]
%       tau               : Collects all maturities
%       ntau              : vector of number of maturity obs in each segment
%       switching         : vector holding 1 if beta element is regime switching 0 otherwise
%       F_restr           : correlation structure for the betas
%       m                 : vector of mean starting parameter value 
%       m_u               : vector of upper constraints on m
%       m_l               : vector of lower constraints on m
%       ar_F              : starting value for autoreg coefficients in state eqn
%       lambda            : starting values for lambdas
%       r                 : starting value for the volatilities in obs eqn
%       q                 : starting value for the volatilities in state eqn
%       cut_off           : cut-off values for the use of transition
%                           matrices in the Hamilton filter
%       nY                : length of the time-series (if specified, it's
%                           used to reshape the variables Y and Macrovars
%
%  Model    : State space Nelson-Siegel with regime shift and multilpe curves
%  obs eq   :                 Y_t(tau) = H * Beta_t + e_t         e->N(0,R)
%  state eq :                 Beta_t   = m + F * Beta_t-1 + v_t   v->N(0,Q)
%  Parameters and dimensions: 
%                             H dim[ sum(ntau)                   , nfactors*ncurves ]
%                             F dim[ nfactors*ncurves            , nfactors*ncurves ]
%                             m dim[ nfactors*ncurves+(nstates+2), 1                ]
%                             R dim[ sum(ntau]                   , sum(ntau)        ] 
%                             Q dim[ nfactor                     , nfactor          ]
%
% Outputs:
%       betas             : estimates Nelson-Siegel yield curve factors
%       out_params        : vector of estimated parameters
%       probs             : estimated state probabilities
%       exitfflag         : status of the optimisation
%       fval              : value of the objective function
%
% UPDATED Feb-2006
% Small contribution added in Jul-2007
%
% Bug report to ken.nyholm@ecb.int
warning off all;

% .............................................
% ... Reshaping the variables -only if needed- 
% .............................................
Y=Y(:,1:sum(ntau'));
if exist('nY')==1
    Y=Y(1:nY,:);
    Macrovars=Macrovars(1:nY,:);
end

% .........................
% ... Packing input data 
% .........................
fact                = 3;
[ncurves, junk]     = size(tau);
lambdas             = lambda(1,1).*ones(ncurves,1);
Prob.user.Y         = Y;
Prob.user.tau       = tau;
Prob.user.ntau      = ntau;
Prob.user.switching = switching;
Prob.user.Macrovars = Macrovars;
Prob.user.fact      = fact;
Prob.user.ncurves   = ncurves;
Prob.user.cut_off   = cut_off;
Prob.user.lambda    = lambda;
Prob.user.states    = states;
Prob.user.F_restr   = F_restr;
Prob.user.m         = m;
Prob.user.m_u       = m_u;
Prob.user.m_l       = m_l;
Prob.user.r         = r;
Prob.user.q         = q;
Prob.user.ar_F      = ar_F;
% .........................
% ... Calling the function
% .........................
[out_] = IPT06_yld2beta(Prob);

% .................................
% ... Unpackaging some output data
% .................................
probs=out_.probs;
betas=out_.betas;
params=out_.params;


