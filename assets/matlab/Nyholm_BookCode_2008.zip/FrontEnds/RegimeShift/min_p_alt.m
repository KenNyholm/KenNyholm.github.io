function [ err2 ] = min_p( p_start, prob )
%
%
%
pr_t_1            = prob.dat_t_1 ;
pr_t              = prob.dat_t ;
m_slope           = prob.m_slope;

[ nObs nVars ] = size(pr_t_1');
if ( prob.state==3 ) % inflation (flat-inverse)
    P  = [ p_start(1,1) 1 1-p_start(3,1);
           0 0 0;
           1-p_start(1,1) 0 p_start(3,1)];             
elseif ( prob.state==2 ) % recession (steep)
    P  = [ p_start(1,1) 1-p_start(2,1) 1;
           1-p_start(1,1) p_start(2,1) 0;
           0 0 0];                
else % normal
    P  = [ p_start(1,1) p_start(5,1) 1-p_start(3,1)-p_start(6,1);
           p_start(4,1) p_start(2,1) p_start(6,1);
           1-p_start(1,1)-p_start(4,1) 1-p_start(2,1)-p_start(5,1) p_start(3,1)];
end


% The errors in the forecasted probabilities are weighted by their effect
% on the forecasted means for the slope
for ( j=1:nObs )
    err2_t(j,1)  = sum((( pr_t (:,j)- (P*pr_t_1(:,j))/sum(P*pr_t_1(:,j)) )).^2);
end
err2 = sum(err2_t);

