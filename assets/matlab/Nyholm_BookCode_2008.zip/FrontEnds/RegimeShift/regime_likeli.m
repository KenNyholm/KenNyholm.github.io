function [ lik, Pr ] = regime_likeli(S_param,Prob)
%
% Likelihood function of the regime switching model 
%   with switches in the mean

% ... unpacking data
dat = Prob.user.dat;
S   = Prob.user.S;
T   = Prob.user.T;
% ...parameters
mean_   = S_param(1:S,1);
sig_    = S_param(S+1,1);
P_      = regime_pmat(S, S_param);
Pr      = (1/S).*ones(S,T);                % Vector of state probabilities on each obs  
Cast_Pr = (1/S).*ones(S,T);                % Vector of forecasts on Pr(i+1) on each obs 
smooth  = Cast_Pr;                         % Vector of smoothed probabilities           
N       = zeros(T,S);                      % Matrix of densities                        
lik     = zeros(T,1);                      % Vector of likelihood values                
for ( j=1:S )
    N(:,j) = regime_normaldensity( mean_(j,1),sig_,dat );
end
N = N';
for i=2:T+1
    lik(i)   = ones(1,S)*( Cast_Pr(:,i-1).*N(:,i-1) );
    Pr(:,i)  = ( Cast_Pr(:,i-1).*N(:,i-1) )./lik(i);
    nan_test = isnan(Pr);                         %errortrap on the regime probabilities 
    nan_test = sum(nan_test(:));                  %starting values are used if problems occur 
    r_test   = 1-isreal(Pr);
    r_test   = sum(r_test(:));
    if ( nan_test > 0 | r_test>0 );                              
        Pr(:,i) = (1/S).* ones(S,1);
        lik(i) = exp(100);
    end
    Cast_Pr(:,i) = P_*Pr(:,i);
    for c=1:S
        if Cast_Pr(c,i) == 0;
            Cast_Pr(c,i) = 0.001;
        end;
        if Pr(c,i)>1;
            Pr(c,i) = 1;
        end;
        if Pr(c,i) <0;
            Pr(c,i) = 0;
        end;
        c = c + 1; 
    end;
    i = i+1;
end;
[row_lik,ol] = size(lik);
lik = log(lik(2:row_lik,1));
if ( sum(1-isreal(lik))>0 )
    lik = 10000;
    Pr  = (1/S).*ones(S,T);
else
    lik = -1*sum(lik);
    Pr  = Pr';
end
    