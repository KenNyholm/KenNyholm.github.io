function [out_] = IPT06_yld2beta(Prob)
%
% Usage: 
%       [out_] = IPT06_yld2beta(Prob)
%
% Purpose: 
%       To estimate the Nelson-Siegel yield curve factors from yield curve
%       data, consisting of multiple yield curve segments and possibly
%       exhibiting regime switching behaviour
%           
% Inputs from structure Prob:
%       Y                 : Collects all yield curves [nobs, sum(ntau)]
%       tau               : Collects all maturities
%       ntau              : vector of number of maturity obs in each segment
%       switching         : vector holding 1 if beta element is regime switching 0 otherwise
%       F_restr           : correlation structure for the betas
%       m                 : vector of mean starting parameter value 
%       m_u               : vector of upper constraints on m
%       m_l               : vector of lower constraints on m
%       ar_F              : starting value for autoreg coefficients in state eqn
%       Lambda            : starting values for lambdas
%       r                 : starting value for variance in obs eqn
%       q                 : starting value for variance in state eqn
%       cut_off           : cut-off values for the use of transition
%                           matrices in the Hamilton filter
%
%  Model    : State space Nelson-Siegel with regime shift and multilpe curves
%  obs eq   :                 Y_t(tau) = H * Beta_t + e_t         e->N(0,R)
%  state eq :                 Beta_t   = m + F * Beta_t-1 + v_t   v->N(0,Q)
%  Parameters and dimensions: 
%                             H dim[ sum(ntau)                   , nfactors*ncurves ]
%                             F dim[ nfactors*ncurves            , nfactors*ncurves ]
%                             m dim[ nfactors*ncurves+(nstates+2), 1                ]
%                             R dim[ sum(ntau]                   , sum(ntau)        ] 
%                             Q dim[ nfactor                     , nfactor          ]
%
% Outputs:
%       betas             : estimates Nelson-Siegel yield curve factors
%       out_p             : vector of estimated parameters
%       probs             : estimated state probabilities
%       exitfflag         : status of the optimisation
%       fval              : value of the objective function
%
% Date Feb/2006
%
% Version 1.0
%
% Bug report to ken.nyholm@ecb.int

global Prob;
warning off all;
% .....................
% ... UnPacking data
% .....................
Y         = Prob.user.Y;
tau       = Prob.user.tau;
ntau      = Prob.user.ntau;
switching = Prob.user.switching;
Macrovars = Prob.user.Macrovars;
fact      = Prob.user.fact;
ncurves   = Prob.user.ncurves;
cut_off   = Prob.user.cut_off;
lambda    = Prob.user.lambda;
states    = Prob.user.states;
F_restr   = Prob.user.F_restr;
m         = Prob.user.m;
m_u       = Prob.user.m_u;
m_l       = Prob.user.m_l;
r         = Prob.user.r;
q         = Prob.user.q;
ar_F      = Prob.user.ar_F;

% ........................
% ... Data and notation
% ........................     

% ... PARAMETER STARTING VALUES
[ncurves, junk]   = size(tau);
lambdas           = lambda(1,1).*ones(ncurves,1);
Prob.user.lambdas = lambdas;
F                 = ar_F(1,1).*F_restr;
R                 = r(1,1).*ones(sum(ntau), 1);                   % imposing diagonality on cov mat obs eqn
Q                 = q(1,1).*ones(fact*ncurves, 1);                % imposing diagonality on cov mat state eqn
m_                = m*(1-ar_F);
m_u_              = m_u*(1-ar_F);
m_l_              = m_l*(1-ar_F);
p_mat_1           = [ 0.90; 0.90; 0.90; 0.05; 0.05; 0.05 ];
p_mat_2           = [ 0.90; 0.90; 0.90; 0.05; 0.05; 0.05 ];
p_mat_3           = [ 0.90; 0.90; 0.90; 0.05; 0.05; 0.05 ];
% ... UPPER AND LOWER CONSTRAINTS
ar_F_u            = 1.*F_restr;
ar_F_l            = -1.*F_restr;
R_u               = ones( sum(ntau), 1 ).*r(2,1) ;
R_l               = ones( sum(ntau), 1 ).*r(3,1) ;
Q_u               = ones( fact*ncurves, 1).*q(2,1);
Q_l               = ones( fact*ncurves, 1).*q(3,1);
lambdas_u         = lambda(2,1).*ones(ncurves,1);
lambdas_l         = lambda(3,1).*ones(ncurves,1);
P_u               = ones(18,1).*0.999;
P_l               = ones(18,1).*0.001;
S_param           = [ m_(:); lambdas(:); F(:); R(:); Q(:); p_mat_1; p_mat_2; p_mat_3 ];
ub                = [ m_u_(:); lambdas_u(:); ar_F_u(:); R_u(:); Q_u(:); P_u ];
lb                = [ m_l_(:); lambdas_l(:); ar_F_l(:); R_l(:); Q_l(:); P_l ];
[nparam, junk]    = size(S_param);
AA                = zeros(9,nparam);
AA(1,nparam-17)=1; AA(1,nparam-14)=1;
AA(2,nparam-16)=1; AA(2,nparam-13)=1;
AA(3,nparam-15)=1; AA(3,nparam-12)=1;
AA(4,nparam-11)=1; AA(4,nparam-8)=1;
AA(5,nparam-10)=1; AA(5,nparam-7)=1;
AA(6,nparam-9)=1; AA(6,nparam-6)=1;
AA(7,nparam-5)=1; AA(7,nparam-2)=1;
AA(8,nparam-4)=1; AA(8,nparam-1)=1;
AA(9,nparam-3)=1; AA(9,nparam-0)=1;
bb_l            = zeros(9,1);
bb_u            = ones(9,1);
% ..................................
% ... SETTING UP OPTIMISATION PROG
% ..................................
% ... OPTIMISING
A_ineq = [AA];
b_ineq = [bb_u];
%'LevenbergMarquardt', 'on',
 options_ = optimset('LevenbergMarquardt', 'on','TolFun',1e-6,'TolX',1e-6, 'HessUpdate', 'steepdesc', 'Display','iter', 'LargeScale', 'off', 'MaxFunEvals', 100000, 'MaxIter', 100000);
% options_ = optimset('LevenbergMarquardt', 'on','TolFun',1e-4,'TolX',1e-4, 'HessUpdate', 'steepdesc', 'Display','iter', 'LargeScale', 'off', 'MaxFunEvals', 10000, 'MaxIter', 10000);
[ out_p, fval, exitfflag ] = fmincon(@IPT06_yld2beta_likeli, S_param, A_ineq, b_ineq, [], [], lb, ub, [], options_);       
[ln_lik, Beta_TT, F, pr] = IPT06_yld2beta_likeli(out_p);
% ... Organising Output
betas = Beta_TT';
probs = pr';
out_.betas     = betas;
out_.probs     = probs;
out_.fval      = fval;
out_.params    = out_p;
out_.exitfflag = exitfflag;
