function [out_] = WB_RS_code(Y, Macro, cut_Macro, tau, lambda, User)  
%%
%  ============================================================================
%              WhiteBox: Regime-Switching Nelson-Siegel yield cuves (ver. 1.0)
%  ============================================================================
%
%   PURPOSE
%   -------
%           To estimate the version of the dynamic Nelson-Siegel yield
%           curve model used in the SAA process of the ECB. A multi-step 
%           estimation methodology is applied to ensure convergence under 
%           all circumstances. It is emphasised that the multi-step approach 
%           is implemented with a view to practical and day-to-day working 
%           of the model and this estimation method is not claimed to produce
%           superior results (in anyway) when compared to jointly estimating 
%           the parameters of the model. Rather, this estimation technique is 
%           implemented to ensure stability of the tool and to deliver reliable 
%           results. Should the user be interested in estimating the model 
%           jointly, or be interested in a more flexible specification of the 
%           model he/she is referred to the function:
%           WB_RSG.m (WhiteBox RegimeSwitchingGeneral)
%           
%
%   CONTENT
%   -------
%
%
%   INPUTS
%   ------
%
%           User.auto  = 1 -> automatic determination of starting values
%                      = 0 -> user provided starting values
%       
%           User.macro = 1 -> transition probabilities depend on macro variables
%                      = 0 -> only one transition probability matrix is
%                               calculated that does not depend on macro
%                               variables
%           User.m     = 3-by-1 vector of starting values for
%                                   regime-switch model
%           User.ml    = 3-by-1 vector of lower parameter bounds
%        
%           User.mu    = 3-by-1 vector of upper parameter bounds

%                                  
%
%   ACTIVATION
%   ----------
%
%
%   OUTPUT
%   ------
%
%
%   REQUIRED FILES
%   --------------
%       
%
%   REFERENCES
%   ----------
%
%
% date: June 2008
% report bugs to: ken.nyholm@ecb.int
%

%
% General variables
%%

L             = lambda;
lagg          = 23;
[ nObs nTau ] = size(Y);
Beta          = [];
Slope_avg     = [];
%
% Estimate the Nelson-Siegel factors
%%
H             = [ ones(nTau,1) ...
                  (1-exp(-L.*tau))./(L.*tau) ...
                  (1-exp(-L.*tau))./(L.*tau)-exp(-L.*tau)];
Beta          = H\Y';
err_Y         = (Y'-H*Beta)'; % measurement errors
sd_err_Y=((sum(err_Y.^2))/((nObs-1))).^0.5; % sd for measurement errors



if User.transform==1;
    Beta=[Beta(1,:);    Beta(2,:)./Beta(1,:);   Beta(3,:)./Beta(1,:)];
end
        
    


Level         = Beta(1,:)';
Slope         = Beta(2,:)';
Curva         = Beta(3,:)';

if ( User.auto==1 )  % auto determine starting values for the regime-switching
    for ( j=1:nObs-lagg )
        Slope_avg(j,1) = mean( Slope(j:j+lagg,1) ); 
    end
    z          = nObs-lagg-2;
    Slope_diff = sign(Slope_avg(2:end,1)-Slope_avg(1:end-1,1));
    ups_       = [0; ((( Slope_diff(2:end,1)~=Slope_diff(1:end-1,1) ) .* ( Slope_avg(2:end-1,1)>mean(Slope_avg(2:end-1,1))) ) .* ( Slope_diff(2:end,1)<Slope_diff(1:end-1,1) )); 0]; %.*((1:1:z)'+1);
    dwn_       = [0; ((( Slope_diff(2:end,1)~=Slope_diff(1:end-1,1) ) .* ( Slope_avg(2:end-1,1)<mean(Slope_avg(2:end-1,1))) ).* ( Slope_diff(2:end,1)>Slope_diff(1:end-1,1) )); 0];  %.*((1:1:z)'+1);
    m(1,1)     = ( sum(~ups_.*Slope_avg) + sum(~dwn_.*Slope_avg) ) / ( sum(~ups_)+sum(~dwn_) );
    m(2,1)     = sum(dwn_.*Slope_avg) / sum(dwn_);
    m(3,1)     = sum(ups_.*Slope_avg) / sum(ups_);
    ml         = m-std(Slope_avg);
    mu         = m+std(Slope_avg);
else
    m  = User.m;
    ml = User.ml;
    mu = User.mu;
end

% Calling RS optimisation code

[ out_ ] = regime(Slope, m, ml, mu, 10000);
pr_      = out_.pr;
% m_Level  = (pr_'*Level)./sum(pr_)';
% m_Curva  = (pr_'*Curva)./sum(pr_)';

m_est    = out_.pr\Beta';
m_Level  = m_est(:,1);
m_Curva  = m_est(:,3);

p_mat    = [ out_.est(5,1) out_.est(9,1) 1-out_.est(7,1)-out_.est(10,1);
             out_.est(8,1) out_.est(6,1) out_.est(10,1);
             1-out_.est(5,1)-out_.est(8,1) 1-out_.est(6,1)-out_.est(9,1) out_.est(7,1)];


% ..... Organisingn output
m_out = [ m_Level out_.est(1:3,1) m_Curva ]';
out_.params     = m_out;
out_.P_plain    = p_mat;
out_.beta       = Beta';
out_.sd_err_Y   = sd_err_Y;

% Calculating transition matrices condition on macro vars
%%
if ( User.macro==1 )
rec_    = (Macro(:,1) < cut_Macro(1,1)) & (Macro(:,2) < cut_Macro(1,2));
inf_    = (Macro(:,2) > cut_Macro(1,2)) & (Macro(:,1) > cut_Macro(1,1));
if ( sum(rec_)==0 )
    msgbox('Please revise the macro cut-off values. The current values lead to no recession classsifications. ')
end
if ( sum(inf_)==0 )
    msgbox('Please revise the macro cut-off values. The current values lead to no inflation classsifications. ')
end

norm_   = (~inf_ & ~rec_);
pr_inf_t_1  = [];
pr_inf_t    =[];
pr_rec_t_1=[];
pr_rec_t=[];
pr_main_t_1=[];
pr_main_t=[];  

k=0; l=0; m=0;
for ( j=1:nObs-1 )
    if ( inf_(j,1)==1 )
        k=k+1;
        pr_inf_t_1(k,:)=pr_(j,:);
        pr_inf_t(k,:)=pr_(j+1,:);
        
    end
    if ( rec_(j,1)==1 )
        l=l+1;
        pr_rec_t_1(l,:)=pr_(j,:);
        pr_rec_t(l,:)=pr_(j+1,:);
        
    end
    if ( norm_(j,1)==1 )
        m=m+1;
        pr_main_t_1(m,:)=pr_(j,:);
        pr_main_t(m,:)=pr_(j+1,:);        
    end
end
p_start = [ diag(p_mat); 0; 0; 0 ];
lb_ = [0.5; 0.5; 0.5; ones(3,1).*0.001];
ub_ = ones(6,1).*0.999;
options = optimset('Display','off','LargeScale','off', 'LevenbergMarquardt', 'on', 'HessUpdate', 'steepdesc', 'MaxFunEvals', 10000, 'TolFun', 1e-12);
% .... Inflation P matrix
prob.dat_t_1   = pr_inf_t_1';
prob.dat_t   = pr_inf_t';

prob.state = 3;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
       1 0 -1 0 0 0 ;
        0 1 -1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_inf  = [ p_out(1,1) 1 1-p_out(3,1);
           0 0 0;
           1-p_out(1,1) 0 p_out(3,1)];
% .... Recession P matrix
prob.dat_t_1    = pr_rec_t_1';
prob.dat_t      = pr_rec_t';
prob.state = 2;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
       1 -1 0 0 0 0 ;
        0 -1 1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_rec  = [ p_out(1,1) 1-p_out(2,1) 1;
           1-p_out(1,1) p_out(2,1) 0;
           0 0 0];                
% .... Normal P matrix
prob.dat_t_1    = pr_main_t_1';
prob.dat_t    = pr_main_t';
prob.state = 1;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
        -1 1 0 0 0 0 ;
        -1 0 1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_main = [ p_out(1,1) p_out(5,1) 1-p_out(3,1)-p_out(6,1);
          p_out(4,1) p_out(2,1) p_out(6,1);
          1-p_out(1,1)-p_out(4,1) 1-p_out(2,1)-p_out(5,1) p_out(3,1)];
out_.P_main = P_main;
out_.P_inf  = P_inf;
out_.P_rec  = P_rec;
end


%% Estimating autorregresive coefficients for factors AR(1), conditional to previously estimated means
% and estimating covariance matrix for residuals of state_equation

        % Compute errors by evolving 1 step forward probabilities using the transition matrices.
        % Estimate AR on the error correction version of the AR, to get AR
        % coefficients.  (X_t+1)=(m_t+1)+a((X_t)-(m_t+1))+(u_t+1), u being
        % the residual
        % with (m_t+1)=pr_t*transition_matrix*m_generic = cast_pr_t*m_generic
        % Therefore (X_t+1)-(m_t+1)=a((X_t)-(m_t+1))+(u_t+1)

cast_m=zeros(nObs-1,3);
cast_pr=zeros(nObs-1,3);


for t=1:nObs-1
    if ( User.macro==0 )
        cast_pr(t,:)=pr_(t,:)*(p_mat)';
    else
        cast_pr(t,:)=norm_(t)*pr_(t,:)*(P_main)'+rec_(t)*pr_(t,:)*(P_rec)'+inf_(t)*pr_(t,:)*(P_inf)';
    end
    cast_m(t,:)=cast_pr(t,:)*m_out';
end

out_.AR_mat=zeros(3);
out_.res_Beta=zeros(nObs-1,3);

for f=1:3
    out_.AR_mat(f,f)=(Beta(f,1:end-1)'-cast_m(:,f))\(Beta(f,2:end)'-cast_m(:,f));   %error to be corrected: difference between mean and value of the lag
    out_.res_Beta(:,f)=(Beta(f,2:end)'-cast_m(:,f))-(Beta(f,1:end-1)'-cast_m(:,f))*out_.AR_mat(f,f);
end

out_.Beta_res_Cov=cov(out_.res_Beta);
    

out_.res_Beta=[0 0 0;out_.res_Beta];


