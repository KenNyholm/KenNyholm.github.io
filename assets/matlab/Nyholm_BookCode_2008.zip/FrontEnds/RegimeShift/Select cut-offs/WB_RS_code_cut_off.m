function [sum_err,perc_rec,perc_inf] = WB_RS_code_cut_off(Macro, cut_Macro, pr_,p_mat)  
%%
%  ============================================================================
%              WhiteBox: Regime-Switching Nelson-Siegel yield cuves (ver. 1.0)
%  ============================================================================
%
%   PURPOSE
%   -------



% Calculating transition matrices condition on macro vars and cut_off
%%
[ nObs nTau ] = size(Macro);
cut_Macro;
rec_    = (Macro(:,1) < cut_Macro(1,1)) & (Macro(:,2) < cut_Macro(1,2));
inf_    = (Macro(:,2) > cut_Macro(1,2)) & (Macro(:,1) > cut_Macro(1,1));

perc_rec=(sum(rec_)/nObs)*100;
perc_inf=(sum(inf_)/nObs)*100;


if ( sum(rec_)==0 )
    msgbox('Please revise the macro cut-off values. The current values lead to no recession classsifications. ')
end
if ( sum(inf_)==0 )
    msgbox('Please revise the macro cut-off values. The current values lead to no inflation classsifications. ')
end

norm_   = (~inf_ & ~rec_);
pr_inf  = [];
pr_rec  = [];
pr_main = [];
k=1; l=1; m=1;
for ( j=1:nObs )
    if ( inf_(j,1)==1 )
        pr_inf(k,:)=pr_(j,:);
        k=k+1;
    end
    if ( rec_(j,1)==1 )
        pr_rec(l,:)=pr_(j,:);
        l=l+1;
    end
    if ( norm_(j,1)==1 )
        pr_main(m,:)=pr_(j,:);
        m=m+1;
    end
end
p_start = [ diag(p_mat); 0; 0; 0 ];
lb_ = [0.5; 0.5; 0.5; ones(3,1).*0.001];
ub_ = ones(6,1).*0.999;
options = optimset('Display','off','LargeScale','off', 'LevenbergMarquardt', 'on', 'HessUpdate', 'steepdesc', 'MaxFunEvals', 10000, 'TolFun', 1e-12);
% .... Inflation P matrix
prob.dat   = pr_inf';
prob.state = 3;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
       1 0 -1 0 0 0 ;
        0 1 -1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_inf  = [ p_out(1,1) 1 1-p_out(3,1);
           p_out(4,1) 0 0;
           1-p_out(1,1)-p_out(4,1) 0 p_out(3,1)];
       err_inf=fval;
% .... Recession P matrix
prob.dat   = pr_rec';
prob.state = 2;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
       1 -1 0 0 0 0 ;
        0 -1 1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_rec  = [ p_out(1,1) 1-p_out(2,1) 1;
           p_out(4,1) p_out(2,1) 0;
           1-p_out(1,1)-p_out(4,1) 0 0];
       err_rec=fval;
% .... Normal P matrix
prob.dat    = pr_main';
prob.state = 1;
A   = [ 1 0 0 1 0 0 ;
        0 1 0 0 1 0 ;
        0 0 1 0 0 1 ;
        -1 1 0 0 0 0 ;
        -1 0 1 0 0 0 ];
A_u = [ 1; 1; 1; -0.0; -0.0 ];
[ p_out, fval, exitflag, outpt, la, g, H ] = fmincon('min_p', p_start, A, A_u, [], [], lb_, ub_, [], options, prob);
P_main = [ p_out(1,1) p_out(5,1) 1-p_out(3,1)-p_out(6,1);
          p_out(4,1) p_out(2,1) p_out(6,1);
          1-p_out(1,1)-p_out(4,1) 1-p_out(2,1)-p_out(5,1) p_out(3,1)];
      err_main=fval;
out_.P_main = P_main;
out_.P_inf  = P_inf;
out_.P_rec  = P_rec;



sum_err=err_inf+err_rec+err_main;


