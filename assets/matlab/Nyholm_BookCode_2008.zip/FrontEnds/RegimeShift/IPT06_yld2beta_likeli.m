function [ln_lik, Beta_TT, F, pr] = yld2beta_likeli(S_param)  
% USAGE:
%        [ln_lik, Beta_TT, F, pr] = IPT06_yld2beta_likeli(S_param)
%
% Purpose: 
%        to calculate the likelihood function values for the general specification 
%        of the nelson-siegel regime-switching model allowing for
%        simultaneous evolution of several yield curves
%
% Inputs from structure Prob:
%        Y          = Matrix of time series observations for the yield curve segments
%        tau        = Maturities in months
%        ntau       = Maximum of number of maturity observations in one yield curve segment
%        switching  = Vector indicating which factors that exhibit regime switching
%        Macrovars  = Matrix of macrovariables  
%        fact       = The number of yield curve factors
%        ncurves    = Number of yield curves
%        states     = Number of different yield curve states
%        cut_off    = Cut-off value for the macroeconomic variables
%        lambdas    = vector of time-decay variables for the nelson siegel representation of each yield curve segment 
%
% Output from the function:
%        ln_lik     = log likelihood value
%        Beta_TT    = calculated yield curve factors
%        F          = matrix of VAR(1) parameters
%        pr         = calculated regime switching probabilities
%


%
% ... UNPACKING DATA
%
global Prob;
Y          = Prob.user.Y';
tau        = Prob.user.tau;
ntau       = Prob.user.ntau;
switching  = Prob.user.switching;
fact       = Prob.user.fact;
ncurves    = Prob.user.ncurves;
states     = Prob.user.states;
lambdas    = Prob.user.lambdas;
[vars obs] = size(Y);
tau        = tau';

% ... Setting up the F, Q and R matrices based on starting values vector
n_m       = (fact*ncurves)+(sum(switching)*2);
n_L       = ncurves;
n_F       = (ncurves*fact)^2;
n_R       = sum(ntau);
n_Q       = fact*ncurves;
m__       = S_param( 1:n_m, 1 );
L         = S_param( n_m+1 : n_m+n_L, 1 );
F         = reshape( S_param( n_m+n_L+1: n_m+n_L+n_F, 1),sqrt(n_F),sqrt(n_F));                          
             
if ( sum(switching)>0 )
    R = eye(n_R).*( S_param(n_m+n_L+n_F+1:n_m+n_L+n_F+1 , 1 ) ).^2;
    Q = eye(n_Q).*( S_param(n_m+n_L+n_F+n_R+1:n_m+n_L+n_F+n_R+1, 1) ).^2;
else
    R = eye(n_R).*( repmat( S_param( n_m+n_L+n_F+1: n_m+n_L+n_F+n_R, 1 ),1,n_R) ).^2;
    Q = eye(n_Q).*( repmat( S_param( n_m+n_L+n_F+n_R+1:n_m+n_L+n_F+n_R+n_Q, 1 ),1,n_Q ) ).^2;
end
P_mat_tot = S_param(n_m+n_L+n_F+n_R+n_Q+1:end,1);
P_mat_1   = [ P_mat_tot(1:6,1) ];

% ... GENERATING THE H-matrix for the observation equation
H               = zeros( sum(ntau), 3*ncurves );
temp            = [0 ntau];
for ( j=1:ncurves )
    H(  sum(temp(1,1:j))+1:sum(temp(1,1:j+1)), 1+((j-1)*fact):j*fact )  = [ ones(ntau(1,j),1) ...
                                                     ((1-exp(-L(j,1).*tau(1:ntau(1,j),j)))./(L(j,1).*tau(1:ntau(1,j),j))) ...
                                                     (((1-exp(-L(j,1).*tau(1:ntau(1,j),j)))./(L(j,1).*tau(1:ntau(1,j),j)))-exp(-L(j,1).*tau(1:ntau(1,j),j)))];
end

% ... REORGANISING THE TRANSITION MATRICES
p_mat_N(1,1) = P_mat_1(1,1);    
p_mat_N(2,2) = P_mat_1(2,1);
p_mat_N(3,3) = P_mat_1(3,1);
p_mat_N(2,1) = P_mat_1(4,1);
p_mat_N(3,2) = P_mat_1(5,1);
p_mat_N(1,3) = P_mat_1(6,1);
p_mat_N(3,1) = 1-p_mat_N(1,1)-p_mat_N(2,1);
p_mat_N(1,2) = 1-p_mat_N(2,2)-p_mat_N(3,2);
p_mat_N(2,3) = 1-p_mat_N(3,3)-p_mat_N(1,3);

if ( sum(switching)>0 )
    pr         = (1/states).*ones(states,obs);                     % regime probabilities
    cast_pr    = (1/states).*ones(states,obs+1);                   % forecasted state probabilities
else
    pr         = zeros(1,1);
    cast_pr    = zeros(1,1);
end
Densities  = zeros(states,obs);                                    % To collect the marginal densities for the data   
lik        = ones(obs,1);                                          % log likelihood function  

% ... CALCULATION WITH NO REGIME SWITCHES
if ( sum(switching)==0 )    
    % ... Calculating initial values for Beta_TL_0 
    Beta_TL_0(:,1) = m__;   %m__./( ones(fact*ncurves,1)-diag(F) );
    % ... To store densities
    D_0 = zeros(1,obs);
    % Kalman filter initiate variables
    % notation
    %           Beta_LL   -> beta(t-1|t-1) 
    %           Beta_TL_0 -> beta(t|t-1,s(t-1)=0)
    %           Beta_TL_1 -> beta(t|t-1,s(t-1)=1)
    %           Beta_TL_2 -> beta(t|t-1,s(t-1)=2)
    %           Beta_TT_0 -> beta(t|t,s(t-1)=0)
    %           Beta_TT_1 -> beta(t|t,s(t-1)=1)
    %           Beta_TT_2 -> beta(t|t,s(t-1)=2)
    %           Beta_TT   -> beta(t|t)                is the probability weighted average of the Beta_TT_0,1
    %
    %           P_TL                                  is the covariance of the betas
    %           P_TT
    %           N_TL_0                                is the prediction errors from state 0 
    %           N_TL_1                                is the prediction errors from state 1
    %           N_TL_2                                is the prediction errors from state 2
    %           f_TL                                  is the prediction error variance

    Beta_LL     = zeros(n_Q,obs);                % Beta_(t-1|t-1)
    Beta_TT     = zeros(n_Q,obs);                % Beta_(t  |t  )            Prob weighted/collapsed Beta
    P_LL        = eye(n_Q).*150;                 % P_(t-1|t-1)               Initial variance on P_LL
    P_TL        = eye(n_Q).*150;                 % P_(t  |t-1)               Initial variance on P_TL
    P_TT        = eye(n_Q).*150;                 % P_(t  |t  )               Updated P
    N_TL_0     = zeros(vars,1);                  % Prediction error in measurement eq
    f_TL       = zeros(vars,vars);                % variancs of prediction error
    % ...................Kalman filter..................
    % starting values
    Beta_TT(:,1) = Beta_TL_0(:,1);
    P_TT         = eye(n_Q).*150;

    % ... STARTING ITERATION LOOP
    t = 2;
    while t <= obs
        Y_t = Y(:,t);                                            % yields at time t to the measurement eq  
    % ... Initialising filter values
        Beta_LL(:,t)  = Beta_TT(:,t-1);
        P_LL          = P_TT;
    % ... Prediction step
        Beta_TL_0(:,t) = m__ + F * (Beta_LL(:,t)-m__ ); 
        P_TL           = F * P_LL * F' + Q;
    % ... Prediction error
        N_TL_0         = Y_t - H * Beta_TL_0(:,t);
    % ... Variance on prediction error
        f_TL           = H * P_TL * H' + R; 
    % ... Calculating marginal densities
        pinvf_TL = pinv(f_TL); 
        D_0(1,t) =  exp(-0.5*log(det(f_TL)) - 0.5 * (N_TL_0'*pinvf_TL*N_TL_0));
        lik(t,1) = D_0(1,t);
        K_gain   = P_TL * H' * pinvf_TL;
        Beta_TT_0(:,t) = Beta_TL_0(:,t) + K_gain * N_TL_0;
        P_TT           = P_TL - K_gain * H * P_TL;
        Beta_TT(:,t)  = Beta_TT_0(:,t);
        t = t+1;
    end
    L_lik=log(lik(3:obs-1,1));
    tempo = -1*sum(L_lik);
    if isnan(tempo) | isinf(tempo) | ~isreal(tempo) 
        tempo = 1e+4;
    end
    ln_lik = tempo;
end
% .......................
% ... REGIME SWITCHES ...
% .......................
if ( sum(switching)>0 )    
    % Calculating initial values for Beta_TL_0, Beta_TL_1, Beta_TL_2 
    % Kalman filter initiate variables
    % notation
    %           Beta_LL   -> beta(t-1|t-1) 
    %           Beta_TL_0 -> beta(t|t-1,s(t-1)=0)
    %           Beta_TL_1 -> beta(t|t-1,s(t-1)=1)
    %           Beta_TL_2 -> beta(t|t-1,s(t-1)=2)
    %           Beta_TT_0 -> beta(t|t,s(t-1)=0)
    %           Beta_TT_1 -> beta(t|t,s(t-1)=1)
    %           Beta_TT_2 -> beta(t|t,s(t-1)=2)
    %           Beta_TT   -> beta(t|t)                is the probability weighted average of the Beta_TT_0,1
    %
    %           P_TL                                  is the covariance of the betas
    %           P_TT
    %           N_TL_0                                is the prediction errors from state 0 
    %           N_TL_1                                is the prediction errors from state 1
    %           N_TL_2                                is the prediction errors from state 2
    %           f_TL                                  is the prediction error variance

    Beta_LL     = zeros(n_Q,obs);                % Beta_(t-1|t-1)
    Beta_TL_0   = zeros(n_Q,obs);                % Beta_(t  |t-1,s(t-1)=0)
    Beta_TL_1   = zeros(n_Q,obs);                % Beta_(t  |t-1,s(t-1)=1)
    Beta_TL_2   = zeros(n_Q,obs);                % Beta_(t  |t-1,s(t-1)=2)
    Beta_temp   = zeros(n_Q,3);

    Beta_TT_0   = zeros(n_Q,obs);                % Beta_(t  |t  ,s(t-1)=0)   Updated Beta
    Beta_TT_1   = zeros(n_Q,obs);                % Beta_(t  |t  ,s(t-1)=1)   Updated Beta
    Beta_TT_2   = zeros(n_Q,obs);                % Beta_(t  |t  ,s(t-1)=2)   Updated Beta

    Beta_TT     = zeros(n_Q,obs);                % Beta_(t  |t  )            Prob weighted/collapsed Beta

    P_LL        = eye(n_Q).*150;                 % P_(t-1|t-1)               Initial variance on P_LL
    P_TL        = eye(n_Q).*150;                 % P_(t  |t-1)               Initial variance on P_TL
    P_TT        = eye(n_Q).*150;                 % P_(t  |t  )               Updated P

    N_TL_0     = zeros(vars,1);                   % Prediction error in measurement eq
    N_TL_1     = zeros(vars,1);
    N_TL_2     = zeros(vars,1);

    f_TL       = zeros(vars,vars);                % variancs of prediction error
   
% ... KALMAN FILTER
    Beta_TT(:,1) = pr(1,1).*Beta_TL_0(:,1) + pr(2,1).*Beta_TL_1(:,1) + pr(3,1).*Beta_TL_2(:,1);
    Beta_TT(:,1) = Beta_TL_0(:,1);
    P_TT         = eye(fact*ncurves).*150;
       
    j=1;
    k=1;
    while ( k<=n_Q )
         if ( switching(k,1)==1 )
             Beta_temp(k,:) = m__(j:j+2,1)';
             j=j+3;
         else
             Beta_temp(k,:) = m__(j,1);
             j=j+1;
         end
         k=k+1;
    end
     
    m__0(:,1) = Beta_temp(:,1);
    m__1(:,1) = Beta_temp(:,2);
    m__2(:,1) = Beta_temp(:,3);
    Beta_TL_0(:,1) = m__0./( ones(fact*ncurves,1)-diag(F) );
    Beta_TL_1(:,1) = m__1./( ones(fact*ncurves,1)-diag(F) );
    Beta_TL_2(:,1) = m__2./( ones(fact*ncurves,1)-diag(F) );
    
    % ... to store densities
    D_0 = zeros(1,obs);
    D_1 = zeros(1,obs);
    D_2 = zeros(1,obs);

    %
    % ... STARTING ITERATION LOOP
    %
    t = 2;
    while t <= obs
    
    % ... Data
        Y_t = Y(:,t);                                            % yields at time t to the measurement eq  
    
    % ... Initialising filter values
        Beta_LL(:,t)  = Beta_TT(:,t-1);
        P_LL          = P_TT;

    % ... Prediction step
        Beta_TL_0(:,t) = m__0 + F * (Beta_LL(:,t)-m__0); 
        Beta_TL_1(:,t) = m__1 + F * (Beta_LL(:,t)-m__1);
        Beta_TL_2(:,t) = m__2 + F * (Beta_LL(:,t)-m__2);
        P_TL           = F * P_LL * F' + Q;
    
    % ... Prediction error
        N_TL_0         = Y_t - H * Beta_TL_0(:,t);
        N_TL_1         = Y_t - H * Beta_TL_1(:,t);
        N_TL_2         = Y_t - H * Beta_TL_2(:,t);
    
    % ... Variance on prediction error    
        f_TL           = H * P_TL * H' + R; 
    
    % ... Calculating marginal densities
     %konst = (2*pi)^(-obs/2);
     %konst = 1;  
        pinvf_TL = pinv(f_TL);
        D_0(1,t) =  exp(-0.5*log(det(f_TL)) - 0.5 * (N_TL_0'*pinvf_TL*N_TL_0));
        D_1(1,t) =  exp(-0.5*log(det(f_TL)) - 0.5 * (N_TL_1'*pinvf_TL*N_TL_1));
        D_2(1,t) =  exp(-0.5*log(det(f_TL)) - 0.5 * (N_TL_2'*pinvf_TL*N_TL_2));
        Densities(:,t) = [D_0(1,t); D_1(1,t); D_2(1,t)];
    %lik(t,1) = D_0(1,t);
    % ... Hamilton filter
        lik(t,1)        = ones(1,states)*(cast_pr(:,t).*Densities(:,t));           % Likelihood as weighted sum of the densities   
        pr(:,t)         = (cast_pr(:,t).*Densities(:,t))./lik(t,1);
        cast_pr(:,t+1)  = p_mat_N * pr(:,t);                                       
        
    % ... just checking values for the probabilities
        for j = 1:states
            if cast_pr(j,t+1) < 0.001
                cast_pr(j,t+1) = 0.001;
            end
            if pr(j,t) > 1
                pr(j,t) = 1;
            end
            if pr(j,t) < 0
               pr(j,t) = 0;
            end
        end
    
    % ... Update 
        K_gain = P_TL * H' * pinvf_TL;
        Beta_TT_0(:,t) = Beta_TL_0(:,t) + K_gain * N_TL_0;
        Beta_TT_1(:,t) = Beta_TL_1(:,t) + K_gain * N_TL_1;
        Beta_TT_2(:,t) = Beta_TL_2(:,t) + K_gain * N_TL_2;
        P_TT           = P_TL - K_gain * H * P_TL;
    
    % ... Collapsing dimension of beta
        Beta_TT(:,t)  = pr(1,t).*Beta_TT_0(:,t) + pr(2,t).*Beta_TT_1(:,t) + pr(3,t).*Beta_TT_2(:,t);
    t = t+1;
    end
    L_lik=log(lik(1:obs,1));
    tempo = -1*sum(L_lik);
    if isnan(tempo) | isinf(tempo) | ~isreal(tempo) 
        tempo = 1e+4;
    end
    ln_lik = tempo;
end
......EOF...IPT06_yld2beta_likeli