function [ out_ ] = regime(dat,m,ml,mu,maxiter)
%
% Estimate Univariate Regime Switching Model on data (dat)
%
%      dat      -   data to be used in the estimation
%      m        -   starting values for the mean
%                   number of states equal to nobs in m are estimated (max=4)
%      ml       -   lower bounds for the estimated parameters
%      mu       -   upper bounds for the estimated parameters 
%      maxiter  -   maximum number of iterations
%
% Output
%      out_.pr   = estimated state probabilities
%      out_.est  = estimates parameters
%      out_.se   = standard errors of estimated parameters


% ...checking and setting up data 
warning off all;
dat      = dat(:,1);           % ensuring that data is univariate
S        = length(m(:));       % number of states
sig      = std(dat)/5;         % starting value for the standard dev
P_diag   = 0.95;
[T,junk] = size(dat);
P        = ones(S,1).*P_diag;
%.............................................
% parameter constraints on transition matrices
%.............................................
if ( S==2 )
    A   = [];
    A_l = [];
    A_u = [];
end
if ( S==3 )
    A   = [ 0 0 0 0 1 0 0 1 0 0 ;
            0 0 0 0 0 1 0 0 1 0 ;
            0 0 0 0 0 0 1 0 0 1 ;
            -1 1 0 0 0 0 0 0 0 0 ;
            1 0 -1 0 0 0 0 0 0 0 ];
    A_l = [ 0; 0; 0 ];
    A_u = [ 1; 1; 1; 0; 0 ];
    
    
end
if ( S==4 )
    A   = [ 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 0 0 ;
            0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 0 ;
            0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 ;
            0 0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 ];
    A_l = [ 0; 0; 0; 0 ];
    A_u = [ 1; 1; 1; 1 ];
end
% ... starting values and structure for 'Prob'
S_param  = [ m; sig; P];
if ( S==3 )
    S_param  = [ m; sig; P; 0.02; 0.02; 0.02];
end
if ( S==4 )
    S_param  = [ m; sig; P; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01];
end
nparams  = length(S_param);
lb       = -inf.*ones(nparams,1);
ub       = inf.*ones(nparams,1);
lb(1:S,1)  = ml;
ub(1:S,1)  = mu;
lb(S+1,1)  = 0.1;
ub(S+1,1)  = 1;     % THINK ABOUT HOW TO PARAMETERISE THIS UPPER LIMIT FOR THE STD
if ( S==2 )
    lb(nparams-S+1:nparams,1) = 0.60.*ones(S,1); 
    ub(nparams-S+1:nparams,1) = 0.999.*ones(S,1);
end
if ( S==3 )
    lb(nparams-(S*2)+1:nparams-S,1) = 0.70.*ones(S,1);  % diagonal elements 
    lb(nparams-S+1:nparams,1)       = 0.001.*ones(S,1); % off-diagonal elements
    ub(nparams-(S*2)+1:nparams,1)   = 0.999.*ones(S*2,1); % diagonal elements
end
if ( S==4 )
    lb(nparams-(S*3)+1:nparams-(S*2),1) = 0.70.*zeros(S,1);     
    lb(nparams-(S*2)+1:nparams,1)       = 0.001.*zeros(S,1);   
    ub(nparams-(S*3)+1:nparams,1)       = 0.999.*ones(S*3,1);
    
end
% ... structure for 'Prob.user'
Prob.user.dat = dat;
Prob.user.S   = S;
Prob.user.T   = T;
% ... calling optimisation module
options = optimset('Display','iter','LargeScale','off', ...
                             'LevenbergMarquardt', 'on', 'HessUpdate', 'steepdesc', ...
                             'MaxFunEvals', maxiter, 'TolFun', 1e-8);
[param, fval, exitflag, outpt, la, g, H] = fmincon('regime_likeli', ...
                                       S_param,A,A_u,[],[],lb,ub,[],options,Prob);
[ lik, Pr ] = regime_likeli(param,Prob);
Pr          = Pr(2:length(Pr),:);
se          = sqrt(diag(pinv(H)));
p_out       = zeros(length(Pr),2);
p_out(1:length(param),:) = [param se];
out_.pr   = Pr;
out_.est  = param;
out_.se   = se;
out_.flag = exitflag;