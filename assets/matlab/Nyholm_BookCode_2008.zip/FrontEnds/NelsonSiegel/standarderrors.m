function [ se ] = standarderrors(X)
%
% Calculates the standard errors of estimated parameters based on the hessian matrix 
% i.e. the matrix of second derivatives of an optimised function.
%
% Inputs:
%       X.function  = function handle to the function of interest
%       X.params    = parameter values at which the hessian is calculated 
%
% Output:
%       se          = the hessian matrix
f  = X.function;
x0 = X.params;

% ... initialise parameters ...
k       = length(x0);
hessian = zeros(k,k);
grdd    = zeros(k,1);
%eps     = 6.0554544523933429e-6;
eps      = 1e-4; 
% ... Computation of stepsize (dh) ...
ax0 = abs(x0);
if ( x0~=0 );
    dax0 = x0./ax0;
else;
    dax0 = 1;
end;
tmp = [ax0 (1e-2)*ones(k,1)]';
dh = eps.*max([ax0 (1e-2)*ones(k,1)]')'.*dax0;
xdh = x0+dh;
dh = xdh-x0;           % This increases precision slightly 
ee = eye(k).*repmat(dh,1,k);
 
% ... Computation of f0=f(x0) ...
f0 = sum(f(x0));
 
% ... Compute forward step ...
for ( j=1:k );
    grdd(j,1) = sum(f(x0+ee(:,j)));
end;
 
% ... Compute "double" forward step ...
for ( i=1:k )  
    for ( j=i:k )   
        hessian(i,j) = sum(f(x0+(ee(:,i)+ee(:,j))));
        if ( i~=j );
            hessian(j,i) = hessian(i,j);
        end;
    end
end

% ... Compute the Hessian ...
H = (((hessian - repmat(grdd,1,k)) - repmat(grdd',k,1)) + f0) ./ (dh*dh');
% ... Compute standard errors ...
se = real(sqrt(diag(pinv(H))));
