function [ ln_lik ] = WB_NS_filter( s_param )
%
% Model:
%   Observation equation :  y_t(tau)   = L * beta_t + e_t
%   State equation       :  beta_t     = k + A1*beta_(t-1) +  q_t
%                           
% inputs:
%   dat      - matrix of yield observations ( nObs by nTau; last obs = most recent obs )
%   L        - loading matrix for the observation equation
%   k        - constants in the state equation
%   A        - AR matrices for the state equation [A1 A2 A3 ... An]
%   R        - var/covar mat of e
%   Q        - var/covar mat of v

% ... Unpacking variables and data ...
global X;
dat     = X.Y';
tau     = X.tau;
restR   = X.restR;
nTau    = length(tau);
dimBeta = 3;

% .... Setting up parameters....
kk  = s_param(1:3,1);
l_  = s_param(4,1);
AA  = diag(s_param(5:7,1));
Q_  = diag(s_param(8:10,1));     % variance in state eq
R_  = diag(s_param(11:end,1));   % variance in obs eq
if ( restR==1 )                     % equal variances in obs eq
    R_ = diag(s_param(11,1).*ones(nTau,1));
end

% ... Setting up variables ...
[njunk nObs]  = size(dat);
lik           = ones(nObs,1);    % collects the log likelihood function values  

% Kalman filter initiate variables
%      notation
%        Beta_LL   -> beta(t-1|t-1) 
%        Beta_TL   -> beta(t|t-1)
%        Beta_TT   -> beta(t|t)
%
%        P_TL      -> covariance of the betas
%        P_TT 
%        N_TL      -> prediction errors  
%        f_TL      -> prediction error variance
Beta_TL     = zeros(dimBeta,nObs);
Beta_LL     = zeros(dimBeta,nObs);           % Beta_(t-1|t-1)
Beta_TT     = zeros(dimBeta,nObs);           % Beta_(t  |t  )    
P_LL        = eye(dimBeta).*150;             % P_(t-1|t-1)       Initial variance on P_LL
P_TL        = eye(dimBeta).*150;             % P_(t  |t-1)       Initial variance on P_TL
P_TT        = eye(dimBeta).*150;             % P_(t  |t  )       Updated P
N_TL        = zeros(nTau,1);                 % Prediction error in measurement eq
f_TL        = zeros(nTau,nTau);              % variancs of prediction error
% ...................Kalman filter..................

% ... Calc loading matrix
L       = [ ones(nTau,1) (1-exp(-l_.*tau))./(l_.*tau) (1-exp(-l_.*tau))./(l_.*tau)-exp(-l_.*tau) ];
B_start = L\dat(:,1); 
Beta_TL(:,1)=B_start; Beta_LL=B_start; Beta_TT=B_start;
% ... STARTING ITERATION LOOP
t = 2;
while t <= nObs
    Y_t = dat(:,t);                            % yields at time t to the measurement eq  
    % ... Initialising filter values
    Beta_LL(:,t)   = Beta_TT(:,t-1);
    P_LL           = P_TT;
    % ... Prediction step
    Beta_TL(:,t)   = kk + AA * ( Beta_LL(:,t)-kk ); 
    P_TL           = AA * P_LL * AA' + Q_;
    % ... Prediction error
    N_TL           = Y_t - L * Beta_TL(:,t);
    % ... Variance on prediction error
    f_TL           = L * P_TL * L' + R_; 
    % ... Calculating marginal densities
    pinvf_TL       = pinv(f_TL); 
    lik(t,1)       = exp(-0.5*log((2*pi)*det(f_TL)) - 0.5 * (N_TL'*pinvf_TL*N_TL));
    K_gain         = P_TL * L' * pinvf_TL;
    Beta_TT(:,t)   = Beta_TL(:,t) + K_gain * N_TL;
    P_TT           = P_TL - K_gain * L * P_TL;
    t = t+1;
end
ln_lik     = -1*sum(log(lik(2:end,:)));

if isnan(ln_lik) | isinf(ln_lik) | ~isreal(ln_lik) 
     tempo = 1e+4;
end

X.factors = Beta_TT';
X.ln_lik  = log(lik);
X.K_gain  = K_gain;
X.L_hat   = L;
X.f_TL    = f_TL;

