function [Beta, u, Res, optim, X] = WB_NS_code(Y, tau, L_limits, typ2)  
%
%  ================================================================
%              WhiteBox: Nelson-Siegel yield cuves (ver. 1.0)
%  ================================================================
%
%   PURPOSE
%   -------
%       The purpose of this WhiteBox is to allow the user to plot and estimate the Nelson-Siegel 
%           yield curve model. Following Diebold & Li (2006) the model can be written in this way: 
%
%           Y_t(tau) = H*beta_t + e_t            [Observation Equation]
%           beta_t   = k + F * beta_(t-1) + v_t  [State / Transition Equation]
%
%           where Y_t(tau) - is the yield at time t for maturities tau
%                 tau      - holds the vector of maturities e.g. (3,6,60,120) months
%                 H        - is the factor-loading structure of the NS model
%                          - its dimensions is (number of maturities -by- 3)  
%                            the first column is just a vector of ones     
%                            the second colmun is {1-exp[-lambda.*tau]}/{lambda.*tau} 
%                            the third column
%                            is{1-exp[-lambda.*tau]}/{lambda.*tau} - exp(lambda.*tau) 
%                 lambda   - is the time-decay factor
%                 beta     - holds the three yield curve factors: level, slope and curvature
%                 e and v  - are residuals
%
%   CONTENT
%   -------
%       This WhiteBox consists of two parts:
%
%       (1) the upper panel of the box, called "Nelson-Siegel Yield Curve Plotting" allows you to 
%           plot a Nelson-Siegel yield curve on the basis of parameters entered
%
%       (2) the lower panel of the box, called "Nelson-Siegel Estimation"
%           allows you to estimate the parameters of the model via different techniques:
%
%               ( Lambda ) calculates one lambda for the whole data set by minimising the   
%                           sum of squared residuals from a set of OLS regressions where the 
%                           value of the lambda parameter is varied over a grid of values;
%
%               ( Factors) calculates the yield curve factors: level, slope
%                           and curvature for the data and given a fixed
%                           value for lambda - an OLS approach is used;
%
%               ( LambdaOverTime ) calculates a time-varying lambda parameter
%                                   i.e. one lambda parameter for each date covered
%                                   by the data sample - the yield curve factors are estimated 
%                                   using a state space model and the lambda parameter is estimated 
%                                   using the two-step outlined under the option ( Lambda );
%
%               ( Lambda_Factors ) estimates one lambda for the whole
%                                   sample and at the same time the yield curve factors are 
%                                   estimated. This is done using a
%                                   state-space modelling approach.
%                                  
%   INPUTS
%   ------
%       (1) for the upper panel: "Nelson-Siegel Yield Curve Plotting"
%
%               lambda    - Maturity is given in monthhs so this value is
%                               typically between 0.01 and 0.20
%               Level     - is the yield-level the curve tends to when the maturity approaches infinite
%               Slope     - is the difference between the level and the yield
%                               at maturity=0
%               Curvature - is represents the convexity/concavity of the
%                               yield curve
%           
%       (2) for the lower panel: "Nelson-Siegel Estimation"            
%
%               Number of maturities - is the number of yield curve
%                                       observations available in the maturity dimension
%               Number of yields     - is the number of dates covered by
%                                       the yield curve data
%
%               The above two inputs helps the WhiteBox to define the input
%               areas, which is done when the button "Populate Input Area" is pressed.
%
%               The imput area consists of three distinct areas:
%
%               (i)
%                   "Enter Lambda", "Lambda" holds the value for the lambda parameter relevant 
%                       for the estimation methods requiring a fixed value for this parameter  
%
%                   "Enter Lambda", "Lower" holds the lower value for the
%                       possible grid of lambda values for the estimation
%                       methods requiring a fixed value for this parameter
%
%                   "Enter Lambda", "Lower" holds the upper value for the
%                       possible grid of lambda values for the estimation
%                       methods requiring a fixed value for this parameter
%
%                   The distance between "upper" and "lower" is split into
%                       a 100 steps and the relevant calculations are then
%                       performed for 101 different values of lambda from
%                       its "lower" to its "upper" value
%
%             (ii)
%                   "Enter Maturities" holds the values for the maturities at which yields are 
%                       observed. This data can be copy-pasted from Excel
%                   
%
%             (iii)
%                   "Enter Yields" holds the values for the yields observed at each date and 
%                       maturity covered. This data can be copy-pasted from Excel
%
%   ACTIVATION
%   ----------
%       (1) the upper panel of the box, called "Nelson-Siegel Yield Curve Plotting" is activated 
%               by pressing the button labelled "Plot Curves"      
%
%       (2) the lower panel of the box, called "Nelson-Siegel Estimation" is activated by first 
%               pressing the button labelled "Populate Input Area". 
%           After the input area has been populated with data for the relevant inputs, the user 
%               can choose an estimation method in the field "Estimate"
%
%           Here after estimations are carried out when the user presses the button labelled 
%               "Estimate"
%
%   OUTPUT
%   ------
%       is generated accordding to the estimation method chosen
%
%   REQUIRED FILES
%   --------------
%       
%       WB_NS.m           - is the main GUI file
%       WB_NS.fig         - is the GUI front figure file
%       WB_NS_code.m      - is the main calculation file
%       WB_NS_filter.m    - calculates the likelihood function for the
%                             Nelson-Siegel model using the Kalman-filter
%       standarderrors.m  - is a general support file that calculates the
%                               standard errors of parameter estimates
%
%   REFERENCES
%   ----------
%       Diebold, F.X. and C. Li, 2006, Forecasting the Term Structure of
%           Interestrates, Journal of Econometrics, 130, 337-364
%
%
%
% date: January 2008
% report bugs to: ken.nyholm@ecb.int
%
global X;
 nTau          = length(tau);
[ nObs njunk ] = size(Y); 
if ( typ2==0 )             % estimate factors using fixed lambda [FACTORS]
    Beta = [];
    L    = L_limits(1,1);
    H    = [ones(nTau,1) ...
               (1-exp(-L.*tau))./(L.*tau) ...
               (1-exp(-L.*tau))./(L.*tau)-exp(-L.*tau)];
    Beta   = H\Y';                
    u      = (Y'-H*Beta)';
    Beta   = Beta';
    Res    = 0;
    optim  = 0;
    X      = 0;
elseif ( typ2==1 )         % estimate lambda using a two-step procedure [LAMBDA]
    Beta = [];
    nIter = 100;
    L_d   = L_limits(1,2);
    L_u   = L_limits(1,3);
    dL    = (L_u-L_d)/nIter; 
    L_    = L_d;
    for ( k=1:nIter )
        H = [ones(nTau,1) ...
                 (1-exp(-L_.*tau))./(L_.*tau) ...
                 (1-exp(-L_.*tau))./(L_.*tau)-exp(-L_.*tau)];
        Beta     = H\Y';                
        u        = (Y'-H*Beta)';
        Sum_u2   = sum(sum(u.^2));
        Res(k,:) = [ Sum_u2 L_ ];
        L_ = L_+dL;
    end
    optim = find(Res(:,1)==min(Res(:,1)));
    Beta  = 0;
    u     = 0;
    X     = 0;
elseif ( typ2==2 )         % LambdaOverTime 
    warning off all 
    msgbox('It may take some time before the results are ready.....Please wait....','Calculating....')
    [nObs njunk] = size(Y);
    Res          = [];
    X            = [];
    X.Y          = Y;
    X.tau        = tau;
    X.restR      = 1;         % =1 -> variances in obs eq all equal
    nTau         = length(tau);
    L_res        = [];
    % ... Starting parameters
    const_start  = [ 5; -3; 0.25; 0.08 ];                 % constants in obs eq
    lb_const     = [ 0 ;-10;-10; 0.01 ];
    ub_const     = [ 20 ; 10; 10; 1 ];
    F_start      = [ 0.90; 0.90; 0.90 ];                  % diagonal in obs eq 
    lb_F         = [ -0.995; -0.995; -0.995 ];
    ub_F         = [ 0.995; 0.995; 0.995 ];
    R_start      = 0.25.*ones(nTau,1);                    % e_t - observation equation
    lb_R         = 0.0001*ones(length(R_start),1);
    ub_R         = 10*ones(length(R_start),1);
    Q_start      = 0.25.*ones(3,1);                       % v_t - state equation
    lb_Q         = 0.0001*ones(3,1);
    ub_Q         = 10*ones(3,1);
    % ... Setting upstarting parameters and LB and UB ...
    s_param  = [ const_start ; F_start ; Q_start; R_start  ];
    lb       = [ lb_const; lb_F; lb_Q; lb_R ];
    ub       = [ ub_const; ub_F; ub_Q; ub_R ];
   
    options_ = optimset('LevenbergMarquardt', 'on', 'TolFun', 1e-6, 'TolX', 1e-6, 'Display', 'iter', 'LargeScale', 'off', ...
                      'MaxFunEvals', 25000, 'MaxIter', 25000 );     
    [ out_p, fval, exitfflag, Output, Lam, Grad, Hess ] = fmincon('WB_NS_filter', s_param , [], [], [], [], lb, ub, [], options_);
    
    % .... Second Step .... estimating the lambda for each t
    nIter = 100;
    L_d   = L_limits(1,2);
    L_u   = L_limits(1,3);
    dL    = (L_u-L_d)/nIter;
    for ( j=1:nObs )
        Beta  = X.factors(j,:)';    
        y     = Y(j,:);
        L_    = L_d;
        for ( k=1:nIter )
            H = [ones(nTau,1) ...
                     (1-exp(-L_.*tau))./(L_.*tau) ...
                     (1-exp(-L_.*tau))./(L_.*tau)-exp(-L_.*tau)];
           % Beta     = H\y';                
            u        = (y'-H*Beta)';
            Sum_u2   = sum(u.^2);
            Res(k,:) = [ Sum_u2 L_ ];
            L_ = L_+dL;
        end
        optim          = find(Res(:,1)==min(Res(:,1)));
        if (length(optim)>1)
            optim = optim(1,1);
        end
        L_res(j,1)  = Res(optim,2);
    end
     % .... calculating standard errors on parameter estimates
     Y.function = @WB_NS_filter;
     Y.params   = out_p;
     [se]       = standarderrors(Y);
     t_stat     = out_p./se; 
     X.params   = [out_p se t_stat];
     X.lambda   = L_res;
     Beta       = X.factors;
     u=0;
     Res=0;
     optim=0;
elseif ( typ2==3 )         % estimate factors and lambda using state space model
    warning off all 
    msgbox('It may take some time before the results are ready.....Please wait....','Calculating....')
    X         = [];
    X.Y       = Y;
    X.tau     = tau;
    X.restR   = 1;         % =1 -> variances in obs eq all equal // 0 otherwise
    nTau      = length(tau);
    % ... Starting parameters
    const_start  = [ 5; -3; 0.25; 0.08 ];                 % constants in obs eq
    lb_const     = [ 0 ;-10;-10; 0.01 ];
    ub_const     = [ 20 ; 10; 10; 1 ];
    F_start      = [ 0.90; 0.90; 0.90 ];                  % diagonal in obs eq 
    lb_F         = [ -0.995; -0.995; -0.995 ];
    ub_F         = [ 0.995; 0.995; 0.995 ];
    R_start      = 0.25.*ones(nTau,1);                    % e_t - observation equation
    lb_R         = 0.001*ones(length(R_start),1);
    ub_R         = 10*ones(length(R_start),1);
    Q_start      = 0.25.*ones(3,1);                       % v_t - state equation
    lb_Q         = 0.001*ones(3,1);
    ub_Q         = 10*ones(3,1);

    % ... Setting upstarting parameters and LB and UB ...
     s_param  = [ const_start ; F_start ; Q_start; R_start  ];
     lb       = [ lb_const; lb_F; lb_Q; lb_R ];
     ub       = [ ub_const; ub_F; ub_Q; ub_R ];
     
     options_ = optimset('LevenbergMarquardt', 'on', 'TolFun', 1e-6, 'TolX', 1e-6, 'Display', 'iter', 'LargeScale', 'off', ...
                       'MaxFunEvals', 25000, 'MaxIter', 25000 );     
     [ out_p, fval, exitfflag, Output, Lam, Grad, Hess ] = fmincon('WB_NS_filter', s_param , [], [], [], [], lb, ub, [], options_);
     %Beta = out_p;
     u=0;
     Res=0;
     optim=0; 
     % .... calculating standard errors on parameter estimates
     Y.function = @WB_NS_filter;
     Y.params   = out_p;
     [se]       = standarderrors(Y);
     t_stat     = out_p./se; 
     X.params   = [out_p se t_stat];
     Beta       = X.factors(2:end,:);
     u=0;
     Res=0;
     optim=0;

else
    msgbox('Please choose an estimation method....')
end


                
                
