%
% Chapter: Essential elements of Matlab
%
%   Example that shows likelihood estimation of a linear regression
%
%   ----NOTE----
%       A Y and a X matrix must exist in the Matlab workspace before you
%       can run this script. These matrices should conform with the following model:
%                                   Y = X*beta + e
%       i.e. the linear regression model
%       The code has been ammended to comply with an arbitrary dimension of
%       the X matrix.
%
%       The ordering of the variables in beta is now: 
%          b_hat[1:nVars,1]  -  are the regression coefficients 
%          b_hat[end,1]      -  is the estimate of the error term variance
%
% date: December 2006
% report bugs to: email@kennyholm.com
%

% --- Generating variables ---

% --- Initial and auxiliry variables/parameters ---
[T nVars] = size(X);
B_0 = [zeros(nVars,1); 0.50]; 
% --- Loglikelihood function ---
lnL = @(B_0) T/2*log(2*pi*B_0(end,1))+...
               1/(2*B_0(end,1))*sum( (Y-X*B_0(1:nVars)).^2 );  
% --- setting up the optimisation inputs ---
options_ = optimset('LevenbergMarquardt', 'on', 'LargeScale', 'off', 'Display', 'on', 'TolX', 1e-12, 'TolFun', 1e-12);
lb       = [-10.*ones(nVars,1); 0.001];
ub       = [10.*ones(nVars,1); 100];
[B_hat,Fval,Exitflag,Output,Lambda,Grad,Hess] = fmincon(lnL, B_0, [], [], [], [], lb, ub, [], options_);
% --- Calculating standard errors ---
u = Y-X*B_hat(1:nVars,1);
s1 = sqrt(diag((u'*u)/(T-nVars)*inv(X'*X)));  %Using error term variance calculated from residuals
s2 = sqrt (diag (B_hat(end,1)*inv(X'*X)));    %Using estimated error term variance for the calculations
s_hess = sqrt(diag(inv(Hess)));               %Using the information matrix // Hessian
% --- OUTPUT ---
disp(' ')
disp('...Estimation results... ')
disp(' ')
disp('      B_hat       StdErrs_1    StdErrs2     StdErrs3   ')
disp([B_hat [s1;0] [s2;0] s_hess])
disp(' ')
disp('......................')
disp('StdErrs_1  are calculated from the sum of squared resids')
disp('StdErrs_2  are calculated from the parameter estimate of the error term variance')
disp('StdErrs_3  are calculated from the Hessian matrix')

