function [ out_ ] = regime(dat,m,ml,mu,maxiter)
% Usage: [ out_ ] = regime(dat,m,ml,mu,maxiter)
%
% Estimate Univariate Regime Switching Model on data (dat)
%
%      dat      -   data to be used in the estimation
%      m        -   starting values for the mean
%                   number of states equal to nobs in m are estimated (max=4)
%      ml       -   lower bounds for the estimated parameters
%      mu       -   upper bounds for the estimated parameters 
%      maxiter  -   maximum number of iterations
%
% Output
%      out_.pr   = estimated state probabilities
%      out_.est  = estimates parameters
%      out_.se   = standard errors of estimated parameters
%
% tip: if the program doesn't converge or generate results that are not
% in line with your expectations, e.g. if you clearly visually can detect regime switches in data
% then please try to change the chosen starting values provided in the vector 'm' and/or
% the starting value for the volatility in line 28 and/or the constraints
% on the parameters contained in the transition probability matrices, see
% lines 76-81 for a two-state model, lines 86-91 for a three-state model
% and lines 97-102 for a four-state model

% ...checking and setting up data 
warning off all;
dat      = dat(:,1);           % ensuring that data is univariate
S        = length(m(:));       % number of states
sig      = std(dat)/3;         % starting value for the standard dev
                               %   if convergence is not obtained
                               %   immediately, then try to change this
                               %   starting value
P_diag   = 0.95;
[T,junk] = size(dat);
P        = ones(S,1).*P_diag;
%.............................................
% parameter constraints on transition matrices
%.............................................
if ( S==2 )
    A   = [];
    A_l = [];
    A_u = [];
end
if ( S==3 )
    A   = [ 0 0 0 0 1 0 0 1 0 0 ;
            0 0 0 0 0 1 0 0 1 0 ;
            0 0 0 0 0 0 1 0 0 1 ];
    A_l = [ 0; 0; 0 ];
    A_u = [ 1; 1; 1 ];
end
if ( S==4 )
    A   = [ 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 0 0 ;
            0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 0 ;
            0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 0 ;
            0 0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 1 ];
    A_l = [ 0; 0; 0; 0 ];
    A_u = [ 1; 1; 1; 1 ];
end
% ... starting values and structure for 'Prob'
S_param  = [ m; sig; P];
if ( S==3 )
    S_param  = [ m; sig; P; 0.02; 0.02; 0.02];
end
if ( S==4 )
    S_param  = [ m; sig; P; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01; 0.01];
end
nparams  = length(S_param);
lb       = -inf.*ones(nparams,1);   
ub       = inf.*ones(nparams,1);
lb(1:S,1)  = ml;
ub(1:S,1)  = mu;
if ( S==2 ) % Two state model
    lb(nparams-S+1:nparams,1) = zeros(S,1);    
    ub(nparams-S+1:nparams,1) = ones(S,1);
    % It is sometime necessary to restrict the diagonal elements of the
    % transition matrix to be strictly higher the zero and strictly lower
    % than one. This can be achieved via lines 72 and 73. To activate the
    % lines remove the '%' signs
    % lb(nparams-S+1:nparams-S+2,1) = [0.01;0.01];
    % ub(nparams-S+1:nparams-S+2,1) = [0.99;0.99];
end
if ( S==3 ) % Three state model
    lb(nparams-(S*2)+1:nparams,1) = zeros(S*2,1); 
    ub(nparams-(S*2)+1:nparams,1) = ones(S*2,1);
    % It is sometime necessary to restrict the diagonal elements of the
    % transition matrix to be strictly higher the zero and strictly lower
    % than one. This can be achieved via lines 82 and 83. To activate the
    % lines remove the '%' signs
    % lb(nparams-(S*2)+1:nparams-(S*2)+3,1) = [0.01;0.01;0.01];
    % ub(nparams-(S*2)+1:nparams-(S*2)+3,1) = [0.99;0.99;0.99];
end
if ( S==4 ) % Four state model
    lb(nparams-(S*3)+1:nparams,1) = zeros(S*3,1); 
    ub(nparams-(S*3)+1:nparams,1) = ones(S*3,1);
    % It is sometime necessary to restrict the diagonal elements of the
    % transition matrix to be strictly higher the zero and strictly lower
    % than one. This can be achieved via lines 82 and 83. To activate the
    % lines remove the '%' signs
    % lb(nparams-(S*3)+1:nparams-(S*3)+4,1) = [0.01;0.01;0.01;0.01];
    % ub(nparams-(S*3)+1:nparams-(S*3)+4,1) = [0.99;0.99;0.99;0.99];
end
% ... structure for 'Prob.user'
Prob.user.dat = dat;
Prob.user.S   = S;
Prob.user.T   = T;
% ... calling optimisation module
options = optimset('Display','iter','LargeScale','off', ...
                             'LevenbergMarquardt', 'on', 'HessUpdate', ...
                             'steepdesc', 'MaxFunEvals', maxiter, 'TolFun', 1e-8);
[param, fval, exitflag, outpt, la, g, H] = fmincon('regime_likeli', ...
                                       S_param,A,A_u,[],[],lb,ub,[],options,Prob);
[ lik, Pr ] = regime_likeli(param,Prob);
Pr          = Pr(2:length(Pr),:);
se          = sqrt(diag(pinv(H)));
p_out       = zeros(length(Pr),2);
p_out(1:length(param),:) = [param se];
out_.pr   = Pr;
out_.est  = param;
out_.se   = se;