function [LogL] = var_p_lik(pStart)
%
% Likelihood function for a VAR(p) model
%
global Dat p; 
for ( j=0:p )
    D{j+1} = Dat(p+1-j:end-j,:);
end
[nObs nVars] = size(D{1});
k  = pStart(1:nVars,1);
for ( j=0:p-1 )
    A{j+1} = reshape( pStart((nVars+1)+(j*nVars^2):...
                              (j+1)*nVars^2+nVars ), nVars, nVars );
end
%remain = pStart( p*nVars^2+nVars+1:end );
%temp   = reshape(remain,nVars,nVars);
%temp1  = tril(temp)+tril(temp)';
%O      = temp1-diag(diag(temp1))+diag(diag(temp));
eps    = D{1}-repmat(k',nObs,1);
for ( j=1:p )
    eps = eps - D{j+1}*A{j};
end
OO = zeros(nVars,nVars);
for ( j=1:nObs )
    OO = OO+eps(j,:)'*eps(j,:);
end
O = 1/nObs.*OO;
for ( j=1:nObs )
    epsi(j)  = eps(j,:)*pinv(O)*eps(j,:)';
end
LogL   = -(nObs-p)/2*log(det(pinv(O)))+1/2*sum(epsi);    
