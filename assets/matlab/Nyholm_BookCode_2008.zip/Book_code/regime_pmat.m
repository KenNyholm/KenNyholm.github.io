function [ P_mat ] = regime_pmat(S, S_param)
%
% transition matrices depending on the number of states
%
nparams = length( S_param(:) );
nobs_p  = nparams-S+1:nparams;

if ( S==2 )
    start_  = nparams-S+1;
    p11     = S_param(start_,1);
    p22     = S_param(start_+1,1);
    P_mat   = [ p11 1-p22;
               1-p11 p22 ];
end
if ( S==3 )
    start_  = nparams-(S*2)+1;
    p11     = S_param(start_,1);
    p22     = S_param(start_+1,1);
    p33     = S_param(start_+2,1);
    p21     = S_param(start_+3,1);
    p12     = S_param(start_+4,1);
    p23     = S_param(start_+5,1);
    P_mat   = [ p11 p12 1-p23-p33 ;
                p21 p22 p23 ;
                1-p11-p21 1-p12-p22 p33];
end
if ( S==4 )
    start_  = nparams-(S*3)+1;
    p11     = S_param(start_,1);
    p22     = S_param(start_+1,1);
    p33     = S_param(start_+2,1);
    p44     = S_param(start_+3,1);
    p21     = S_param(start_+4,1);
    p32     = S_param(start_+5,1);
    p12     = S_param(start_+6,1);
    p23     = S_param(start_+7,1);
    p34     = S_param(start_+8,1);
    p31     = S_param(start_+9,1);
    p13     = S_param(start_+10,1);
    p24     = S_param(start_+11,1);
    P_mat   = [ p11 p12 p13 1-p24-p34-p44 ;
                p21 p22 p23 p24 ;
                p31 p32 p33 p34 ;
                1-p11-p21-p31 1-p12-p22-p32 1-p13-p23-p33 p44 ];
end