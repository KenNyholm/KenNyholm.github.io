function [ err2 ] = NA_y_optim( pstart )
%
% Calculates the squared residuals from the no-arbitrage yield curve model
%   in order to estimate the parameters from the market price of risk
%   equation ... pstart
%
% Inputs:
%                   Y    : matrix of yield observations
%                   tau  : vector of maturities 
%                   beta : matrix of Nelson-Siegel factors
%
%         to call NA_a_b : a1, b1, m, F, S
%
global beta Y_org tau a1 b1 m F S Y_est;
[nObs nFact] = size(beta);  

p0  = pstart(1:3,1);
p1  = reshape(pstart(4:end,1),nFact,nFact);

[a b]  = NA_a_b(a1, b1, p0, p1, m, F, S, tau);
a(1,1) = a(1,1)*tau(1,1);   % to account for the fact that the maturity of the short rate is not 0
b(1,:) = b(1,:).*tau(1,1);  % to account for the fact that the maturity of the short rate is not 0
Y_est  = [ones(nObs,1) beta]*[a b]';
resid2 = (Y_org-Y_est).^2;
err2   = (sum(sum(resid2)));



