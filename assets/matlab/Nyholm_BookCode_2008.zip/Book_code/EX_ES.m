%
% Chapter: Risk and Return
%
% Example that verifies the closed form expression for the Expected
% Shortfall
%
% March 2007
% Ken Nyholm
clear all;
CI      = [ 0.90; 0.95; 0.975; 0.99; 0.999; 0.9999 ]; 
x       = randn(1e6,1);
nCI     = length(CI);
ES_sim  = zeros(nCI,1);
ES_calc = zeros(nCI,1);
for ( j=1:nCI )
    c = CI(j,1);
    ES_sim(j,1)  = sum((x<=norminv(1-c)).*x)/sum(X<=norminv(1-c));
    ES_calc(j,1) = -1/((1-c)*(2*pi)^0.5)*exp(-(norminv(c)^2)/2);
end
disp('Simulated and calculated numbers')
disp('      CI      ES_sim    ES_calc ')
disp([CI ES_sim ES_calc])
