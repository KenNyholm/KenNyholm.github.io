function [out] = frontier(in)  
%
% Chapter: Asset Allocation
%
%  Usage:
%       [out] = frontier(in)
%
%  in (structure):
%       .C    - covariance matrix r-by-r         
%       .R    - vector of expected returns r-by-1
%       .B    - matrix of lower and upper bounds r-by-2
%       .G    - matrix of group definitions ngroups-by-r
%       .GB   - matrix of group bounds      ngroups-by-2
%       .N    - number of points to be calculated on the frontier 1-by-1
%
%  out (structure):
%       .RR   - matrix of risk and return obs on the efficient frontier N-by-2
%       .W    - matrix of weights for the frontier points N-by-r  
%       .mvp  - vector of stdandard dev and return (in that order) for 
%                   the Min Var portfolio
%       .mvpW - weights for global minimum var portfolio
%
% date: October 2006
% report bugs to: email@kennyholm.com
%
warning off all
% --- Organising inputs ---
C=in.C; r=in.R(:); B=in.B; G=in.G; GB=in.GB; Np=in.N;
nAssets = length(r);
one     = ones(nAssets,1);
% --- Calculations for the global MVP ---
w_mvp   = inv(C)*one./(one'*inv(C)*one);
sig_mvp = sqrt(w_mvp'*C*w_mvp);
r_mvp   = w_mvp'*r;
% Optimisation without constraints
if ( isempty(B) & isempty(G) )
    X       = r'*inv(C)*r;
    Y       = r'*inv(C)*one;
    Z       = one'*inv(C)*one;
    D       = X*Z-Y^2;
    g       = 1/D*(X*(inv(C)*one)-Y*(inv(C)*r));
    h       = 1/D*(Z*(inv(C)*r)-Y*(inv(C)*one));
    r_min   = 0;
    r_max   = 2*max(r);
    incr    = (r_max-r_min)*1/(Np-1);
    zz      = 1;
    for ( j=r_min:incr:r_max )
        w_j       = g+h*j; 
        W_p(zz,:) = w_j'; 
        S_p(zz,1) = sqrt(w_j'*C*w_j);
        R_p(zz,1) = w_j'*r;
        zz=zz+1;
    end    
else
    options_ = optimset('LevenbergMarquardt', 'on', 'LargeScale', 'off', 'Display', 'off', 'TolX', 1e-12, 'TolFun', 1e-12);
    [W_max]  = fmincon(@(w)-w'*r, w_mvp, G, GB, one', 1, B(:,1), B(:,2), [], options_);
    [W_min]  = fmincon(@(w)w'*C*w, w_mvp, G, GB, one', 1, B(:,1), B(:,2), [], options_);
    r_min    = W_min'*r;
    r_max    = W_max'*r;
    incr     = (r_max-r_min)*1/(Np-1);
    zz       = 1;
    for ( j=r_min:incr:r_max )
        [w_j]  = fmincon(@(w)w'*C*w, w_mvp, G, GB, [one'; r'], [1; j], B(:,1), B(:,2), [], options_);
        W_p(zz,:) = w_j';
        S_p(zz,1) = sqrt(w_j'*C*w_j);
        R_p(zz,1) = w_j'*r;
        zz=zz+1;
    end
    if ( r_min==r_max )
        W_p = repmat((1/nAssets),Np,nAssets);
        S_p = repmat(sqrt(W_p(1,:)*C*W_p(1,:)'),Np,1);
        R_p = repmat(W_p(1,:)*r,Np,1);
    end
end

out.RR   = [S_p R_p];
out.W    = W_p;
out.mvp  = [sig_mvp r_mvp];
out.mvpW = w_mvp;