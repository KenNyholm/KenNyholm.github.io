function [a b] = NA_a_b(a1, b1, p0, p1, m, F, S, tau)
%
% Calculates a and b for a no-arbitrage yield curve model 
%
% Inputs:
%           a1 : from short rate equation            
%           b1 : from short rate equation
%           p0 : from market price of risk
%           p1 : from market price of risk
%           m  : const in dynamic factor evolution
%           F  : AR matrix in dynamic factor evolution
%           S  : lower triangual matrix error term covar mat 
%                  in the dynamic factor evolution
%           tau: vector of maturities
%
% Update 14 January 2008
%    Correction in the calculation of A and B is implemented - 
%                  thanks to Arjan Berkelaar for spotting this
a        = [];
b        = [];
tau      = tau(:);
b1       = b1(:);
nTau     = length(tau);
nFact    = length(b1);
A_t      = zeros(1,nTau);     
A_t(1,1) = -a1;
B_t      = zeros(nFact,nTau); 
B_t(:,1) = -b1;


%for ( j=2:nTau )  % <- old version 
for ( j=2:tau(end,1) )
    A_t(1,j) = A_t(1,j-1) + B_t(:,j-1)'*( m-S*p0 )+0.5*( B_t(:,j-1)'*S*S'*B_t(:,j-1) ) - a1;
    B_t(:,j) = B_t(:,j-1)'*( F-S*p1 ) - b1';
end

%a = -A_t'./tau;                  %<- old version
%b = -B_t'./repmat(tau,1,nFact);  %<- old version
a = -A_t(tau)'./tau;   
b = -B_t(:,tau)'./repmat(tau,1,nFact);  
