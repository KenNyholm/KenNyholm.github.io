%
% Chapter: Asset Allocation
%
%   Example that shows how the "frontier" function can be used
%
% date: October 2006
% report bugs to: email@kennyholm.com
%

r   = [ 3.25; 5.75; 7.5; 12.3 ];      
C   = [ 25.0 24.5 33.0 37.5;  
        24.5 49.0 50.0 63.0;
        33.0 50.0 121.0 66.0;
        37.5 63.0 66.0 225.0 ];
B   = [zeros(4,1) ones(4,1)];
G   = [0 -1 -1 -1];
GB  = [-0.25];
N   = 30;
% --- Without constraints ---
in.R  = r; in.C  = C; in.B  = []; in.G  = []; in.GB = []; in.N  = N;
[out1] = frontier(in);
% --- With constraints ---
in.R  = r; in.C  = C; in.B  = B; in.G  = G; in.GB = GB; in.N  = N;
[out2] = frontier(in);
% --- Plots ---
x   = (0:0.1:20)';
cml = 1.35+0.8*x;
figure
plot(out1.RR(1:10,1),out1.RR(1:10,2),'k:','linewidth',1), xlabel('Risk'), ylabel('E[R]')
hold on
plot(out2.RR(:,1),out2.RR(:,2),'k:','linewidth',1), xlabel('Risk'), ylabel('E[R]')
hold on
plot(out1.mvp(1,1),out1.mvp(1,2),'ko','linewidth',1), xlabel('Risk'), ylabel('E[R]')
hold on
plot(x,cml,'k-','linewidth',1)
