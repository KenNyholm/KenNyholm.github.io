%
% Chapter: Risk and Return
%
%   Example that calculates risk measures
%
% date: November 2006
% report bugs to: email@kennyholm.com
%

clear all;
clc;
% --- load and sort data ---
Dat   = xlsread('C:\Users\Ken Nyholm\Dropbox\A_book\MATLAB_\Book_code\Data','Equity');
stepp = 0.5;
[nObs junk] = size(Dat);
% --- calc summary stats ---
P     = Dat(:,1);
Ret_s = sort(price2ret(P)).*100; 
avg      = mean(Ret_s); sig = std(Ret_s);
nObs_99  = floor(.01*nObs); nObs_95 = floor(.05*nObs);
VaR_99   = Ret_s(nObs_99,1); ES_99  = mean(Ret_s(1:nObs_99-1,1));
VaR_95   = Ret_s(nObs_95,1); ES_95  = mean(Ret_s(1:nObs_95-1,1));
VaR_95_N = avg-norminv(0.95,0,1)*sig; 
VaR_99_N = avg-norminv(0.99,0,1)*sig;
% --- generate normal pdf ---
x        = (VaR_99:stepp:max(Ret_s))'; 
ret_norm = pdf('norm',x,avg,sig);
% --- generate bar plot of observed returns ---
[bar1 bin] = hist(Ret_s,25);
bar1_adj   = bar1'./nObs./(bin(1,2)-bin(1,1));
figure
bar(bin', bar1_adj,'w')
hold on
plot(x,ret_norm,'k-','linewidth',2)
% --- generate output table ---
disp('...Results...')
disp(sprintf('VaR(99)= %6.2f   Based on Normal Dist: %6.2f  ', [VaR_99 VaR_99_N]))
disp(sprintf('VaR(95)= %6.2f   Based on Normal Dist: %6.2f  ', [VaR_95 VaR_95_N]))
disp(sprintf('ES(99) = %6.2f   ES(95) = %6.2f  ', [ES_99 ES_95]))