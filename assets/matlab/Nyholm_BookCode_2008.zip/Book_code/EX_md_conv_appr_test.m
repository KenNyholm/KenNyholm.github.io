%
%  Chapter: Risk and Return
%  Testing the modified duration and convexity approximation formulas in 
%
max_ = 100;    % the maximum number of time periods to investigate 
% ... assigning the input parameters to IN structure
X.Y  = 0.06;   % yield
X.C  = 6.5;    % coupon
X.N  = 0;      % initial number of years
% ... generating containers for the results
md          = zeros(max_,1);
md_approx   = zeros(max_,1);
conv        = zeros(max_,1);
conv_approx = zeros(max_,1);
conv_approx_1 = zeros(max_,1);

p           = zeros(max_,1);
y           = X.Y;
c           = X.C;
for ( j=1:max_ )
    X.N=j;
    [out]            = bond(X);   % calling the bond function
    p(j,1)           = out.P;     % assign outputs
    md(j,1)          = out.MD;    % assign outputs
    conv(j,1)        = out.Conv;  % assign outputs
    md_approx(j,1)   = 1/y*(1-1/(1+y)^j);
    conv_approx(j,1) = 2*y/y^3*(1-1/(1+y)^j-y*j/(1+y)^(j+1));
    
    DP1(j,1)    = ((100*y-c)/(1+y)^j)/out.P;

end
% ... plotting results
figure
subplot(2,1,1), plot(md,'k-'), xlabel('Bond maturity'), ylabel('Modified duration')
hold on
plot(md_approx,'k--')
subplot(2,1,2), plot(conv,'k-'), xlabel('Bond maturity'), ylabel('Convexity')
hold on
plot(conv_approx,'k--')

DP = (p(1:end-1)-p(2:end))./p(1:end-1);
figure
plot(DP1(2:end), 'k-')
hold on
plot(DP, 'k--')