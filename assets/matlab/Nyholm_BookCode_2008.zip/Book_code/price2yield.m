function [out] = price2yield(in)
%
% Chapter: Risk and Return 
%
%  Usage:
%       [out] = price2yield(in)
%
%  in (structure):
%       .P    - is the price of the cashflow  1-by-1       
%       .CF   - cashflow [-price, cpn1, cpn2,...,cpn(r)+principal] r-by-1         
%       .t    - timing of cashflows in years [0;1;2;...;r]  r-by-1
%                 e.g. 6 months should be written as 0.5
%  out (structure):
%       .Y    - vector of yields 
%
% date: October 2006
% report bugs to: email@kennyholm.com
%
warning off all; clear y;
P    = in.P;
CF   = in.CF(:); 
t    = in.t(:); 
nObs = length(CF);
% --- Defining the function ---
Fx = @(y)(-P+CF'*(y.*ones(nObs,1)).^(t))^2;
% --- Finding the optimum
options_ = optimset('LevenbergMarquardt', 'on', 'LargeScale', 'off', 'Display', 'off');
[D]      = fmincon(Fx, 1, [], [], [], [], 0, 2, [], options_);
out.Y    = 1/D-1;