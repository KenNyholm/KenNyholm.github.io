function [lik] = regime_normaldensity(mean_,sigma_,dat)
%
% normal density with mean1 and variance sigma1^2
% data is dat
%
eps = dat - mean_;
lik = inv(sqrt(2*pi*sigma_^2))*exp(-(eps .*eps)./(2*sigma_^2));