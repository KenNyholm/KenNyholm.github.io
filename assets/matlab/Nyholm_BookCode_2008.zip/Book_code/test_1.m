%
%  The limit of modified duration
%
max_ = 100;
y    = 0.06;
X.Y  = y;
X.C  = 7;
X.N  = 0;
md   = zeros(max_,1);
md_1 = md;
md_2 = md;
md_3 = md;
p    = zeros(max_,1);
conv = zeros(max_,1);
for ( j=1:max_ )
    X.N=j;
    [out]     = bond(X);
    p(j,1)    = out.P;
    md(j,1)   = out.MD;
    conv(j,1) = out.Conv; 
    md_1(j,1) = 1/(1+y)*(1-(1+y)^(-j))/(1-(1+y)^(-1));
    md_2(j,1) = 1/y-1/(y*(1+y)^j);
end
figure
plot(md,'k'), title('MD')
hold on
plot(md_1,'g')
hold on
plot(md_2,'r')
figure
plot(md_1./md, 'g')
hold on
plot(md_2./md, 'r')
figure
plot(p), title('Price')
figure
plot(conv), title('Convexity')