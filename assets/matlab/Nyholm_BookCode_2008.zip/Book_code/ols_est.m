function [out] = ols_est(in)
%
% Estimates a linear regression
%    Y = X*b + e
%
% Input variables collected in the in structure
%    in
%      .Y  
%      .X
%      .k    (=1 -> constant)
%
% Output structure
%    out
%       .beta      - parameters estimates
%       .std_err   - standard errors
%       .R2        - R squared 
%       .u         - residuals
Y=in.Y; X=in.X; k_flag=in.k;
if (k_flag == 1);
   X = [ones(length(X),1) X];
end
beta    = X\Y;
u       = Y-X*beta;
std_err = sqrt( diag((u'*u)/(length(Y)-length(beta))*pinv(X'*X)) );
R2      = beta'*X'*X*beta/(Y'*Y);
out.beta    = beta;
out.std_err = std_err;
out.R2      = R2;
out.u       = u;