%
% Chapter: Essential elements of Matlab
%
%   Example that shows how to simulate a linear autoregression:
%       r(t) = k + a*r(t-1) + b*r(t-2) + c*r(t-3) + u(t)
%       allowing for parameter and innovation uncertainty
%
% date: October 2006
% report bugs to: email@kennyholm.com
%

% --- load data ---
R     = xlsread('C:\A_projects\A_book\Data\Data','Rates');
r_org = R(:,1); 
% --- Inputs ---
b     = [ 0.087; 1.394; -0.612; 0.203; 0.174 ];
s     = [ 0.037; 0.039; 0.065; 0.041; 0.010  ];
init_ = [ 0.64; 0.76; 0.97; -0.097];
nObs  = 622;
nSims = 500;
Res   = zeros(nObs,nSims);
bSim  = zeros(5,nSims);
% --- Calculations ---
for ( j=1:nSims )  % loop over simulations
    b_hat    = inf.*ones(length(b),1);
    while ( sum(b_hat(2:4,1))>=1 )
        b_hat    = b + s.*randn(5,1);
    end
    Y        = zeros(nObs,1);
    Y(1:3,1) = init_(1:3,1); 
    u        = 0 + sqrt(b_hat(5,1)).*randn(nObs,1);
    u(4,1)   = init_(4,1);
    for ( k=4:nObs );  % loop over observations
        Y(k,1) = b_hat(1,1) + b_hat(2,1)*Y(k-1,1) + ...
                              b_hat(3,1)*Y(k-2,1) + ...
                              b_hat(4,1)*Y(k-3,1) + u(k,1);
    end
    Res(:,j)  = Y;
    bSim(:,j) = b_hat;
end
% --- generate stats ---
bSim_m = mean(bSim')';
bSim_s = std(bSim')';
disp('original and simulates parameters...')
disp([b bSim_m])
disp('original and simulates standard errors...')
disp([s bSim_s])
% --- plot simulated and orginal series ---
figure
plot(Res)
hold on
plot(r_org,'k-','LineWidth',2)
% --- plot distribution of simulated parameters ---
figure
x_1   = ( bSim_m(1,1)-4*bSim_s(1,1):bSim_s(1,1)/100:bSim_m(1,1)+4*bSim_s(1,1) )';
pdf_1 = normpdf(x_1, bSim_m(1,1), bSim_s(1,1) );
x_2   = ( bSim_m(2,1)-4*bSim_s(2,1):bSim_s(2,1)/100:bSim_m(2,1)+4*bSim_s(2,1) )';
pdf_2 = normpdf(x_2, bSim_m(2,1), bSim_s(2,1) );
% --- subplot 1
[temp1 bin] = hist(bSim(1,:)',15);
hist_obs    = temp1'./nObs./(bin(1,2)-bin(1,1));
subplot(1,2,1), bar(bin', hist_obs), title('Distribution for the constant');
hold on
plot(x_1,pdf_1);
% --- subplot 2
[temp1 bin] = hist(bSim(2,:)',15);
hist_obs    = temp1'./nObs./(bin(1,2)-bin(1,1));
subplot(1,2,2), bar(bin', hist_obs), title('Distribution for 1st. AR parameter');
hold on
plot(x_2,pdf_2);

