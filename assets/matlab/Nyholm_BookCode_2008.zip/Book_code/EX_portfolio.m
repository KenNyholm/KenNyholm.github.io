%%
% Using DAX data to illustrate the frontier.m function
% 
%
% date          : January 2010
% report bugs to: ken.nyholm@gmail.com

%% Loading data from Excel (requires daxData.xls)
% Here the data is read from the Excel file 'daxData.xls' using the
% built-in xlsread.m function.
[ X, txt ] = xlsread('daxData.xls');
names = txt(1,:)';
dates = txt(:,1);
[ nObs nAssets ] = size(X);
%% Plotting returns series
figure
plot(X), title('Returns of Dax constituents'), ylabel('Return');
set(gca, 'XTickLabel', dates)

%% Calculating the covariance matrix
C       = cov(X);
Cor_Mat = corr(X);
R = mean(X)';
figure
plot(eig(C), ':*'), title('Eigenvalues of covariance matrix')

%% Applying the frontier.m function
%The following described the inputs and outputs from the frontier.m
%function:
%        [out] = frontier(in)
% 
%   in (structure):
%        .C    - covariance matrix r-by-r         
%        .R    - vector of expected returns r-by-1
%        .B    - matrix of lower and upper bounds r-by-2
%        .G    - matrix of group definitions ngroups-by-r
%        .GB   - matrix of group bounds      ngroups-by-2
%        .N    - number of points to be calculated on the frontier 1-by-1
% 
%   out (structure):
%        .RR   - matrix of risk and return obs on the efficient frontier N-by2
%        .W    - matrix of weights for the frontier points N-by-r  
%        .mvp  - vector of stdandard dev and return (in that order) for 
%                    the Min Var portfolio
%        .mvpW - weights for global minimum var portfolio
%
%Two sets of output is generated. The first constains an unconstrained
%solution and the second an optimisation problem where weights are
%constrained to be positive, i.e. we impose a constraint on short-sales. 
%
in.C  = C;
in.R  = R;
in.B  = []; 
in.G  = [];
in.GB = [];
in.N  = 20;

in_.C  = C;
in_.R  = R;
in_.B  = [zeros(nAssets,1) ones(nAssets,1)];
in_.G  = [];
in_.GB = [];
in_.N  = 20;

[ out ]  = frontier(in);
[ out_ ] = frontier(in_);
%% Plotting the Results
% Here we plot the efficient frontier for the constrained and
% unconstrained solutions.
%
figure
subplot(3,1,1), plot(out.RR(:,1), out.RR(:,2),'k:x','linewidth',1), title('Efficient Frontier')
hold on
plot(out.mvp(1,1),out.mvp(1,2),'ko','linewidth',1), xlabel('Risk'), ylabel('E[R]')
hold on
plot(out_.RR(:,1), out_.RR(:,2),'r:x','linewidth',1)
subplot(3,1,2), area(out.W), title('Optimal Weights Unconstrained Solution')
subplot(3,1,3), area(out_.W), title('Optimal Weights Constrained Solution')
%subplot(2,1,2), bar(out.W,'stack','YDataSource','out.W')




