%
% Estimates a multi-factor No-Arbitrage yield curve model
%    program NA_est.m
%  
%   Y_dat : yield curve data (dim-[ nObs x nTau ]) in percent e.g. in the format 10.50%
%   tau   : vector of maturities in months 
%
% Update 14 January 2008
%   - Scaling of Yield data from x% to x%/1000
%            this has a surprising large effect on convergence of fmincon
%   - A heuristic measure is implemented in line 41 to ensure that none of the autoregressive 
%            coefficients in F are not larger than abs(1)  
%   - A correction is implemented in NA_a_b.m - thanks to Arjan Berkelaar
%   - The convergence criterion is set to 1e-12

Y_org = Y_dat./1000;      
                         
nTau = length(tau);
nObs = length(Y_org);
r    = Y_org(:,1);
Y    = Y_org;
%
% Extract Nelson-Siegel factors
%
L = 0.07;     % fixing lambda, in an ad-hoc way, in the NS model, to 0.07
H = [ ones(nTau,1) ...
      (1-exp(-L.*tau))./(L.*tau) ...
      (1-exp(-L.*tau))./(L.*tau)-exp(-L.*tau)];
beta_tmp  = (H\Y')'; 
beta =(beta_tmp-repmat(mean(beta_tmp),nObs,1))./repmat(std(beta_tmp),nObs,1);
%beta = beta_tmp;
%
% Estimate m,F,S from the dynamic evolution of NS factors 
%    using OLS
%
Y_tmp = [ beta(2:end,:) ];
X_tmp = [ ones(nObs-1,1) beta(1:end-1,:) ];
[ Z ] = inv(X_tmp'*X_tmp)*(X_tmp'*Y_tmp);
m     = Z(1,:)';
F_tmp = Z(2:end,:);
F     = (abs(F_tmp)>=1).*(sign(F_tmp).*0.98) + (abs(F_tmp)<1).*F_tmp; % 
err   = beta(2:end,:) - ( repmat( m',nObs-1,1 ) + beta(1:end-1,:)*F );
S_mat = 1/nObs*(err'*err);
S     = chol(S_mat)'; %  chol(S_mat,'lower');            
%
% Estimate a1 and b1 from the short rate equation
%
X_tmp = [ ones(nObs,1) beta ];
[ z ] = inv(X_tmp'*X_tmp)*(X_tmp'*r);
a1    = z(1,1);
b1    = z(2:end,1)';
r_est = X_tmp*z;  % just to check the fit of the short rate equation

%
% Estimates the market price of risk parameters by 
%   minimising the squared residuals from the yield curve equation
%
global beta Y_org tau a1 b1 m F S Y_est; % using global variables
p0_tmp = [ 0; 0; 0 ]; 
p1_tmp = [ 1 1 1;
           1 1 1;
           1 1 1 ];
pstart   = [ p0_tmp(:); p1_tmp(:) ];
nParams   = length(pstart);
lb        = [-0;-35; -0; ones(nParams-3,1).*-35];
ub        = [ 35; 0; 20; ones(nParams-3,1).*35];
options_  = optimset('LevenbergMarquardt','on','TolFun',1e-12,'TolX',1e-12, 'Display','iter', 'LargeScale', 'off', ...
                                'MaxFunEvals', 25000, 'MaxIter', 25000);

[ out_p, fval, exitfflag ] = fmincon(@NA_y_optim, pstart, [], [], [], [], lb, ub, [], options_);
p0 = out_p(1:3,1)
p1 = reshape(out_p(4:end,1),3,3)

%
% Plotting results
%
subplot(3,1,1), plot(Y_org.*1000), title('Observed yields')
subplot(3,1,2), plot(Y_est.*1000), title('Estimated yields')
subplot(3,1,3), plot(Y_org.*1000-Y_est.*1000), title('Estimation errors')
F