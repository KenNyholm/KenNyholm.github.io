%function [out] = var_p(in)
%
% Chapter: Econometric tools 
%
%  Estimates a VAR model with p number of lags
%
%  Usage:
%       [out] = bond(in)
%
%  in (structure):
%       .Dat  - Matrix containing data          nObs-by-nVars       
%       .p    - number of lags  
%  out (structure):
%       . - 
%       . - 
%       . - 
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
%Dat = in.Dat;
%p   = in.p;
% generate data
warning off all;
global Dat p;
p = 2;
[nn nVars] = size(Dat);
nParams    = nVars + p*(nVars^2); %+ nVars^2;
pStart     = 0.1.*ones(nParams,1);
LB = -20.*ones(nParams,1); UB = -LB;
options_ = optimset('LevenbergMarquardt', 'on', 'LargeScale', 'off', 'Display', 'on', 'Tolfun', 1e-12, 'TolX', 1e-12 );
[Est,fval,flag,outp,lambd,grad,hess] = fmincon(@var_p_lik, ...
                           pStart, [], [], [], [], LB , UB, [], options_);
disp('Parameter Estimates')
disp('===================')
disp('')
disp('Constants')
k=Est(1:nVars);
disp(k)
disp('')
disp('Autoregressive parameters')
for ( j=0:p-1 )
    AOut{j+1} = reshape( Est((nVars+1)+(j*nVars^2):(j+1)*nVars^2+nVars ), nVars, nVars );
    disp(sprintf('A_%1.0f', j+1))
    disp(AOut{j+1})
end

