%% Frontier resampling
% This example shows how to generate an efficient frontier that is 
% relatively stable against sampling uncertainty as regards the mean
% and covariance matrix.
%
% We start by simulating some return data. Naturally, the simulated data
% should be substituted by real-life data. However, for illustrative
% purposes, we rely here on simulated data. This also affords us the
% opportunity to demonstraate how the cholesky decomposition works.

% ... Inputs
%randn('seed',0);                             % fixing the seed 
nObs  = 250;                                  % number of observations
C =  [ 64.0000   60.8000   60.8000   60.8000;
       60.8000   64.0000   60.8000   60.8000;
       60.8000   60.8000   64.0000   60.8000;
       60.8000   60.8000   60.8000   64.0000 ];

means = [15.00 15.00 15.00 15.00 ];           % mean returns

% ... simulating the return data
[ nAssets junk ] = size(C);
U   = chol(C);
n   = randn(nObs,nAssets);
dat = repmat(means,nObs,1)+n*U;

% -----------------------------------------------------------------------
% Q1: Confirm empirically that the above algorithm generates data having 
%     the desired properties, i.e. dimension, covariance and means
%
% Q2: Estimate the efficient frontier from the simulated data, and comment 
%     the results
%
% Q3: Implement the efficient frontier resampling methodology as mentioned
%     on class
% -----------------------------------------------------------------------




%
% A1 - we simply increase the number of observations (nObs), and calculate 
%      the covariance and mean of the simulated data, then we compare the 
%      obtained results to the input variables
%

%%
% A2 - as seen on class yesterday...
%
%
%

% ... Calculate covariance of data
C_ = cov(dat);
R_ = mean(dat);
% ... Unconstrained
in.C  = C_;
in.R  = R_;
in.B  = []; 
in.G  = [];
in.GB = [];
in.N  = 20;
% ... Constrained
in_.C  = C_;
in_.R  = R_;
in_.B  = [zeros(nAssets,1) ones(nAssets,1)];
in_.G  = [];
in_.GB = [];
in_.N  = 20;

[ out ]  = frontier(in);
[ out_ ] = frontier(in_);

figure
subplot(3,1,1), plot(out.RR(:,1), out.RR(:,2),'k:x','linewidth',3), title('Efficient Frontier')
hold on
plot(out.mvp(1,1),out.mvp(1,2),'ko','linewidth',1), xlabel('Risk'), ylabel('E[R]')
hold on
plot(out_.RR(:,1), out_.RR(:,2),'r:x','linewidth',3)
subplot(3,1,2), area(out.W), title('Optimal Weights Unconstrained Solution')
subplot(3,1,3), area(out_.W), title('Optimal Weights Constrained Solution')

%%
% A3 - Implementing the frontier resampling method
%
%
%
nPort  = 10;                         % number of portfolios on the frontier
nRep   = 250;                        % number of resamplings
W_tot  = zeros(nPort,nAssets);       % container for results
W_tot1 = zeros(nPort,nAssets,nRep);
Count_problems = 0;
for ( j=1:nRep )
    j
    z     = randi(nObs,nObs,1);
    dat_  = dat(z,:);
    Ctmp  = cov(dat_);
    Rtmp  = mean(dat_)';
    tst   = eig(Ctmp);
    if ( min(tst<0) )
        Ctmp = C;
        Rtmp = means';
        Count_problems = Count_problems+1;
    end
    in1.C  = Ctmp;
    in1.R  = Rtmp;
    in1.B  = [zeros(nAssets,1) ones(nAssets,1)]; 
    in1.G  = [];
    in1.GB = [];
    in1.N  = nPort;
   [ out1 ]  = frontier(in1);
    W_tot    = W_tot+out1.W; 
    W_tot1(:,:,j) = out1.W; 
end
W_sample  = W_tot./nRep;
W_sample1 = mean(W_tot1,3);
