%
% Chapter: Econometric tools
%
%   Example that illustrates the cholesky decomposition
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
disp('The covariance matrix')
C = [ 7.9440 7.8265 8.3193 6.8492;
      7.8265 7.7473 8.2614 6.8304;
      8.3193 8.2614 8.8664 7.4661;
      6.8492 6.8304 7.4661 7.1715 ]
disp('Upper triangular from cholesky decomposition')
U = chol(C)
disp('Calculating transpose(U)*U')
disp(U'*U)
n = randn(500000,4);
R = n*U;
disp('Covariance matrix of simulated random variables')
disp(cov(R))