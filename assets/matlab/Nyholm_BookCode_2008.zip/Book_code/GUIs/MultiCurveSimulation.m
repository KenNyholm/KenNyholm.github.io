function varargout = MultiCurveSimulation(varargin)
% TEST3 M-file for test3.fig
%      TEST3, by itself, creates a new TEST3 or raises the existing
%      singleton*.
%
%      H = TEST3 returns the handle to a new TEST3 or the handle to
%      the existing singleton*.
%
%      TEST3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TEST3.M with the given input arguments.
%
%      TEST3('Property','Value',...) creates a new TEST3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before test3_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to test3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help test3

% Last Modified by GUIDE v2.5 04-Oct-2007 16:03:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MultiCurveSimulation_OpeningFcn, ...
                   'gui_OutputFcn',  @MultiCurveSimulation_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before test3 is made visible.
function MultiCurveSimulation_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to test3 (see VARARGIN)

% Choose default command line output for test3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes test3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MultiCurveSimulation_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

handles.nMaturities = str2double(get(hObject,'String'));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
handles.nCurves = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
handles.nHorizons = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
handles.nSims = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      POPULATE THE INPUT FORM
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles          = guidata(hObject);
nMaturities      = handles.nMaturities;
nCurves          = handles.nCurves;



%.....MATURITIES
dat = nan(nMaturities,nCurves);
for ( j=1:nCurves )
    colnames(1,j) = cellstr(strcat('Curve ', num2str(j)));
end
uicontrol('Style','text','String','Enter Maturities', 'Position', [100 235 80 10]);
handles.uitable_maturities = uitable(dat,colnames,'Position', [10 10 265 220]);

%.....STARTING BETAS
dat = nan(3,nCurves); 
for ( j=1:nCurves )
    colnames(1,j) = cellstr(strcat('Curve ', num2str(j)));
end
uicontrol('Style','text','String','Enter Starting Betas', 'Position', [90 360 100 15]);
handles.uitable_betas = uitable(dat,colnames,'Position', [10 270 265 90]);

%.....LAMBDAS
dat = nan(1,nCurves); 
for ( j=1:nCurves )
    colnames(1,j) = cellstr(strcat('Lambda ', num2str(j)));
end
uicontrol('Style','text','String','Enter Lambdas', 'Position', [90 455 100 15]);
handles.uitable_lambdas = uitable(dat,colnames,'Position', [10 395 265 60]);

%.....SENSITIVITIES FOR SPREAD CURVES
dat = nan(nCurves-1,3); 
colnames = {'a', 'b', 'c' }; 
uicontrol('Style','text','String','Enter Spread Curve Sensitivities', 'Position', [350 455 160 15]);
handles.uitable_abc = uitable(dat,colnames,'Position', [280 395 265 60]);

%.....PARAMETERS FOR THE STATE EQUATION - MEAN AND AR
nTal = 2*(nCurves-1);
dat  = nan(3+nTal,1+3+nTal); 
for ( j=1:1+3+nTal )
    colnames(1,j) = cellstr(strcat('AR', num2str(j)-1));
end
colnames(1,1) = {'Mean'};

uicontrol('Style','text','String','Parameters - State EQ', 'Position', [350 360 120 15]);
handles.uitable_Mean_F = uitable(dat,colnames,'Position', [280 200 350 160]);

%.....PARAMETERS FOR THE STATE EQUATION - VARIANCE Q
nTal = 2*(nCurves-1);
dat  = nan(3+nTal,3+nTal); 
colnames = colnames(1,1);
for ( j=1:3+nTal )
    colnames(1,j) = cellstr(strcat('Q', num2str(j)));
end
uicontrol('Style','text','String','Variance Matrix - State EQ', 'Position', [350 170 130 15]);
handles.uitable_Q = uitable(dat,colnames,'Position', [280 10 350 160]);


%.....VARIANCE MATRIX FOR OBS EQ - R
dat      = nan(1,  nCurves); 
colnames = colnames(1,1);
for ( j=1:nCurves )
    colnames(1,j) = cellstr(strcat('Curve', num2str(j)));
end
uicontrol('Style','text','String','Variance Matrix - Obs EQ', 'Position', [650 360 130 15]);
handles.uitable_R = uitable(dat,colnames,'Position', [640 200 280 160]);

guidata(hObject,handles)


%++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      RUN YIELD SIMULATIONS SIMULATIONS
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles     = guidata(hObject);
nCurves     = handles.nCurves;
nHorizons   = handles.nHorizons;
nSims       = handles.nSims;

%.............................
%  EXTRACTING THE DATA 
%.............................
tau_     = str2double(cell(handles.uitable_maturities.getData));
beta_    = str2double(cell(handles.uitable_betas.getData));
lambdas_ = str2double(cell(handles.uitable_lambdas.getData));
abc_     = str2double(cell(handles.uitable_abc.getData));
Mean_F_  = str2double(cell(handles.uitable_Mean_F.getData));
Q_       = str2double(cell(handles.uitable_Q.getData));
R_       = str2double(cell(handles.uitable_R.getData));

%.............................................
%  CALLING THE YIELD SIM FUNCTION FUNCTION
%.............................................

[ y_out_, tau_] = MCS_ext_NS_gui_code( nCurves, nHorizons, nSims, tau_, beta_, lambdas_, abc_, Mean_F_, Q_, R_ );
handles.y_out_  = y_out_;
handles.tau_    = tau_;
guidata(hObject,handles)



%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      CALCULATE RETURNS ON THE BASIS OF SIMULATED YIELDS
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles   = guidata(hObject);
y_est_    = handles.y_out_;
tau_      = handles.tau_;
nCurves   = handles.nCurves;
nHorizons = handles.nHorizons;
nSims     = handles.nSims;

Pt   = [];
Ptp1 = [];

for ( j=1:nCurves )
    nTau(j,1) = length(tau_{j})
end
for ( c=1:nCurves )   % over curves
for ( m=1:nTau )
        [] = MCS_bond_gui_code();

end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      GRAPH YIELDS
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles   = guidata(hObject);
y_out     = handles.y_out_;
tau       = handles.tau_;
nCurves   = handles.nCurves;
nHorizons = handles.nHorizons;
nSims     = handles.nSims;

%
% Collecting results for 
%    y{curve}.{horizon}(for all maturities across all simulations)
%
for ( c=1:nCurves )
    for ( t=1:nHorizons+1 )
        for ( s=1:nSims ) 
            y{c}.h{t}(:,s) = y_out{s}.curve{c}(:,t);   
        end
    end
end

%Average yields across time
n_1  = ceil(nSims*0.01);
n_5  = ceil(nSims*0.05);
n_25 = ceil(nSims*0.25);
n_50 = ceil(nSims*0.50);
n_75 = ceil(nSims*0.75);
n_95 = floor(nSims*0.95);
n_99 = floor(nSims*0.99);

for ( j=1:nCurves )
    for ( k=1:nHorizons+1 )
        tmp           = y{j}.h{k}(:,:)';
        s_tmp         = sort(tmp);
        y_avg{j}(:,k) = mean(tmp);
        y_1{j}(:,k)   = s_tmp(n_1,:)'; 
        y_5{j}(:,k)   = s_tmp(n_5,:)';
        y_25{j}(:,k)  = s_tmp(n_25,:)';
        y_50{j}(:,k)  = s_tmp(n_50,:)';
        y_75{j}(:,k)  = s_tmp(n_75,:)';
        y_95{j}(:,k)  = s_tmp(n_95,:)';
        y_99{j}(:,k)  = s_tmp(n_99,:)'; 
    end
end
figure('Name','Average Yields')
for ( j=1:nCurves )
    subplot(nCurves,1,j), surf([1:1:nHorizons+1]',tau{j}(:), y_avg{j}), xlabel('Horizon'), ylabel('Maturity'), zlabel('Yield(%)')
end
for ( j=1:nCurves )
    for ( k=1:length(tau{j}) )
        tmp = [y_1{j}(k,:)' y_5{j}(k,:)' y_25{j}(k,:)' y_50{j}(k,:)' y_avg{j}(k,:)' y_75{j}(k,:)' y_95{j}(k,:)' y_99{j}(k,:)'];
        titl = ['Curve ', num2str(j), '  Maturity ', num2str(k), '  ...for CIs: 1, 5, 25, 50, avg, 75, 95, 99'];
        figure('Name',titl)
        plot(tmp)
    end
end


%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      GRAPH RETURNS
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles     = guidata(hObject);

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      EXPORT RESULTS
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles     = guidata(hObject);

[file,path] = uiputfile('*.mat','Save Workspace As');

%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%
%      PORTFOLIO OPTIMIZATION
%
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles     = guidata(hObject);

