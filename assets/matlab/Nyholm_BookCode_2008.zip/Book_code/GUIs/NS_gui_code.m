function [Beta,u,Res,optim ] = NS_gui_code(Y, tau, L_limits, typ2)  
%
%   Calculates Nelson-Siegel yield curve factors
%      or the lambda (by a simplistic two-step approach)
%
%   INPUTS:
%           Y        - matrix of yields (nObs,nMaturities)
%           tau      - vector of maturities (nMaturities,1)
%           L_limits - start_lambda, lower, upper
%           typ1     - indicator 0->maturities in months  1->maturities in years
%           typ2     - inicator  0->estimate factors      1->estimate lambda
%
%   OUTPUTS:
%
%
% date: October 2007
% report bugs to: email@kennyholm.com
%
nObs = length(tau);
if ( typ2==0 )  % estimate factors
    L    = L_limits(1,1);
    H    = [ones(nObs,1) ...
               (1-exp(-L.*tau))./(L.*tau) ...
               (1-exp(-L.*tau))./(L.*tau)-exp(-L.*tau)];
    Beta   = H\Y';                
    u      = (Y'-H*Beta)';
    Beta   = Beta';
    Res    = 0;
    optim  = 0;
else 
    nIter = 50;
    L     = L_limits(1,1);
    L_d   = L_limits(1,2);
    L_u   = L_limits(1,3);
    dL    = (L_u-L_d)/nIter; 
    L_    = L_d-dL;
    for ( k=1:nIter )
        H = [ones(nObs,1) ...
                 (1-exp(-L_.*tau))./(L_.*tau) ...
                 (1-exp(-L_.*tau))./(L_.*tau)-exp(-L_.*tau)];
        Beta     = H\Y';                
        u        = (Y'-H*Beta)';
        Sum_u2   = sum(sum(u.^2));
        Res(k,:) = [ Sum_u2 L_ ];
        L_ = L_+dL;
    end
    optim = find(Res(:,1)==min(Res(:,1)));
    Beta = 0;
    u    = 0;
end
