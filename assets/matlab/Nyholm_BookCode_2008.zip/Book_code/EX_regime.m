%
% Chapter: Econometric tools
%
%   Example that estimates a regime switching model
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
Dat = xlsread('C:\A_projects\A_book\Data\Data','Macro');
[ out_ ] = regime(Dat(:,2),[4;-2],[-10;-10],[10;10],2000);