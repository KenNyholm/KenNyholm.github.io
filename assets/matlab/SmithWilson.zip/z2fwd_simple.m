function [ fwd ] = z2fwd_simple(in_)
%
% Calculation of the simple forward rate
%
% Inputs:
%
%        Y   - zero coupon rate in decimal form
%        tau - maturity for the rate observations in years
%
% Ken.Nyholm@googlemail.com  
% date: 14 september 2012
%

Y   = in_.Y ;
tau = in_.tau;

nObs     = length(Y);
fwd      = zeros(nObs,1);
d2       = ((1+Y(2:end)).^(tau(2:end,1)));
d1       = ((1+Y(1:end-1)).^(tau(1:end-1,1)));
fwd      = [Y(1,1);(d2./d1).^(1./(tau(2:end,1)-tau(1:end-1,1)))-1];

