function [SW_out] = F_SW(prob)
%  
% Function that implements the Smith-Wilson methodology
%
% Input:
%          prob.C        - matrix of coupon payments ( nBonds by nCashflows )  
%          prob.tau      - Maturities for the bonds  ( nBonds by 1 )
%          prob.nCoupon  - Coupon frequency          ( scalar )
%          prob.SW.aplha - convergence speed         ( scalar )
%          prob.nCFs     - number of cashflows       ( scalar )
%          prob.SW.y_inf - ultimate forward rate as discrete compound
%                          percentage rate e.g. 4.2  ( scalar ) 
%
% Output:
%           SW_out.p_fit     - SmithWilson prices
%           SW_out_p_fit1    - SmithWilson prices and SW interpolation
%           SW_out.tau_fit   - maturities
%           SW_out.y_fit     - Smith Wilson yields 
%           SW_out.y_fit1    - Smith Wilson yields and SW interpolation
%         
% Ken.Nyholm@googlemail.com  
% date: 14 september 2012
%

a_         = prob.SW.alpha;
tau_observ = prob.tau./12;               
nCFs       = prob.nCFs;
y_inf      = log(1+prob.SW.y_inf./100);
Cmat       = prob.C;
nCoupon    = prob.nCoupon;               
nObs       = length(tau_observ);         
tau        = (1/nCoupon:1/nCoupon:tau_observ(end,1))';


SWFunc = @(t,u,r_inf,a) exp(-r_inf.*(t+u)).*(a.*min(t,u)- ...
                        exp(-a.*max(t,u)).*sinh(a.*min(t,u)));
W = zeros(nCFs,nCFs);
z = 0;

for ( u_=1:1:nCFs )
    v = 0;
    z = z+1;
    for ( j_=1:1:nCFs )
        v=v+1;
        W(v,z) = SWFunc( tau(j_,1), tau(u_,1), y_inf, a_);
    end
end
m      = ones(nObs,1);                   
u      = exp(-y_inf.*tau);               
params = inv(Cmat*W*Cmat')*(m-Cmat*u);

SW_out.Wmat   = W;
SW_out.u      = u;
SW_out.params = params; 

tau_fit = [ (1/12:1/12:11/12)'; (1:1:150)' ];
p_fit   = zeros(length(tau_fit),1);
for ( j=1:length(tau_fit) )
    K          = SWFunc(tau_fit(j,1),tau,y_inf,a_);
    p_fit(j,1) = exp(-y_inf*tau_fit(j,1)) + (K'*Cmat')*params;
end
y_fit = ((1./p_fit).^(1./tau_fit))-1;

%%
% storing output
%
SW_out.p_fit   = p_fit;
SW_out.tau_fit = tau_fit;
SW_out.y_fit   = y_fit;


 