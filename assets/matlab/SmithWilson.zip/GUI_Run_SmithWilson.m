function [SW_out_trad] = GUI_Run_SmithWilson(input_)
%
% This code performs the calculation of the Smith-Wilson 
%   interpolation and extrapolation methodology. 
%
% Usage: 
%      Run_SmithWilson
%
% Needs external functions:
%
%      F_SW.m          - implements the Smith-Wilson method 
%      z2fwd_simple.m  - implements forward rate calculations                                
%                            
% Inputs:
%
%      bb         - SwapData dimension: number of maturies-by-2   
%                   structure: col1 = maturities in years, at which rates are observed
%                              col2 = swap rates in percentages (not decimal form, e.g. 1.4 (for
%                                                               1.4% and not 0.014)
%                   note     : the input swap rates should be adjusted for
%                               CCP and credit risk. This is not done by
%                               the matlab code.
%
%      coupon_freq - dimension: 1-by-1
%                    structure: scalar that contains the coupon frequency
%                               for the observed curve
%
%      conv_years  - dimension: 1-by-1
%                    structure: scalar that contains the number of years
%                               after the last liquid point (the last maturity
%                               included in "SwapData") at which
%                               convergence to the UFR should be achieved.
%
%       UFR_       - dimension: 1-by-1
%                    structure: scalar that contains the UFR level in
%                               percentages, e.g. 4.2.
%
%       alpha_     - dimension: 1-by-1
%                    structure: scalar that contains the starting value for the convergence speed
%                               parameter of the SmithWilson method
%
%       min_diff   - dimension: 1-by-1
%                    structure: scalar that contains the convergence
%                               criteria for the forward curve, i.e. the accepted
%                               error at the horizon at which the forward rate should
%                               converge to the UFR. The number should be provided in
%                               percentages (the standard value is 3bp i.e. min_diff=0.03)
%       plotting_  -  = 1 -> output graphs will be produced
%                     = 0 -> no output graphs will be produced 
%
%       plot_alpha -  = 1 -> user information is printed if alpha needs to be reoptimised
%                     = 0 -> no user information is printed if alpha needs to be reoptimised
%
%
%
%  Outputs:                              
%       
%       curve_    - dimension: 161-by-2 
%                    structure: matrix that holds the maturities and the
%                               discount curve. The curve is calculated for
%                               maturities 1m-150years. maturities are
%                               provided in years and rates in percantages.
%
%       forward_   - dimension: 161-by-2
%                    structure: matrix that holds the maturities and the
%                               forward curve. The forward curve is calculated for
%                               maturities 1m-150years. maturities are
%                               provided in years and forward rates in percantages.
%
%       alpha_fit  - dimension: 1-by-1
%                    structure: scalar that holds the re-optimised value of
%                               the alpha parameter
%
% Ken.Nyholm@googlemail.com  
% date: 14 september 2012
%
%
plotting_  = input_.plotting_;     % =1 -> output graphs will be produced
                                   % =0 -> no output graphs will be produced 
plot_alpha = input_.plot_alpha;                    % =1 -> user information is printed if alpha needs to be reoptimised
                                   % =0 -> no user information is printed if alpha needs to be reoptimised
%% Inputs provided by GUI

SwapData       = input_.bb;
coupon_freq    = input_.coupon_freq;
conv_years     = input_.conv_years;
UFR_           = input_.UFR_;
alpha_         = input_.alpha_;
min_diff       = input_.min_diff;

[ nTau nCols ] = size(SwapData);   
                                   
%% Setting up the matrix of coupon cashflows
%
nom_    = 100;
maxDur  = SwapData(end,1);
nObs    = nTau;
nCFs    = coupon_freq*maxDur;
cfMatI  = zeros(nObs, nCFs);
cfMat_  = zeros(nObs, nCFs);
temp_   = SwapData(:,1).*coupon_freq;

for ( j=1:nObs )
    cfMatI(j,:) = [ ones(1,temp_(j,1)) zeros(1,nCFs-temp_(j,1)) ];
end
cfMat_ = cfMatI.*repmat( (SwapData(:,2)./coupon_freq),1,nCFs );
for ( j=1:nObs )
    cfMat_(j,SwapData(j,1)*coupon_freq) = cfMat_(j,SwapData(j,1)*coupon_freq) + nom_; 
end

%% Calculating the Smith-Wilson interpolation and extrapolation 
%
prob.C        = cfMat_./100;         % CF payment matrix in decimal form
prob.tau      = SwapData(:,1).*12;   % maturity in months
prob.nCoupon  = coupon_freq;
prob.SW.alpha = alpha_;
prob.nCFs     = nCFs;
prob.SW.y_inf = UFR_;

[SW_out_trad] = F_SW(prob);        % running the smith-wilson function

%% Calculating the forward curve and testing the UFR convergence criteria
% 
SW_tau              = SW_out_trad.tau_fit;
SW_y1               = SW_out_trad.y_fit;
fwd_chk             = find(SW_tau >= SwapData(end,1)+conv_years );
in1.Y               = SW_y1;
in1.tau             = SW_tau;
[Fwd_fit]           = z2fwd_simple(in1);
diff_bp             = UFR_-100.*Fwd_fit(fwd_chk(1,1),1); 
SW_out_trad.fwd_fit = Fwd_fit;
SW_out_trad.alpha   = prob.SW.alpha;
SW_out_tmp.fwd      = Fwd_fit; 
SW_out_trad.nCoupon = coupon_freq;

if ( abs(diff_bp)> min_diff )
    if ( plot_alpha==1 )
        msgbox('The UFR is not reach within the specified number of years. The relationship between the alpha parameter and the convergence criterion is found. The discount curve will subsequently be recalculated..... Please wait.','Information...','help')
    end
    tst_alpha = [];
    SW_tau    = []; 
    SW_p      = [];
    SW_y      = [];
    SW_y1     = [];
    for (j=1:900)
        prob.SW.alpha = j/1000;
        [SW_out_tmp]   = F_SW(prob); 
        SW_tau         = SW_out_tmp.tau_fit; 
        SW_p           = SW_out_tmp.p_fit;
        SW_y           = SW_out_tmp.y_fit;
        SW_y1          = SW_out_tmp.y_fit;
        in1.Y          = SW_y1;
        in1.tau        = SW_tau;
        [Fwd_fit]      = z2fwd_simple(in1);     
        diff_bp        = UFR_-100.*Fwd_fit(fwd_chk(1,1),1);         
        tst_alpha(j,:) = [ prob.SW.alpha diff_bp ];
    end
    if ( plot_alpha==1 )
        figure
        plot(tst_alpha(:,1),tst_alpha(:,2),'b-'),title('Alpha and Conv. Criterion')
        hold on
        plot(tst_alpha(:,1),ones(length(tst_alpha),1).*min_diff,'-r')
        hold on
        plot(tst_alpha(:,1),-ones(length(tst_alpha),1).*min_diff,'-r')
    end
    tst            = abs(tst_alpha(:,2));
    indx_alpha     = find(tst<=min_diff);
    prob.SW.alpha  = tst_alpha(indx_alpha(1,1),1);
    [ SW_out_tmp ] = F_SW(prob); 
    SW_tau         = SW_out_tmp.tau_fit; 
    SW_p           = SW_out_tmp.p_fit;
    SW_y           = SW_out_tmp.y_fit;
    SW_y1          = SW_out_tmp.y_fit;
    in1.Y          = SW_y1;
    in1.tau        = SW_tau;
    [Fwd_fit]      = z2fwd_simple(in1);     
    diff_bp        = UFR_-100.*Fwd_fit(fwd_chk(1,1),1);         
    tst_alpha(j,:) = [ prob.SW.alpha diff_bp ];
    if ( plot_alpha==1 )
        msgbox(['Re-optimised alpha= ', num2str(prob.SW.alpha) ] ,'Results...','help')
    end
    SW_out_tmp.fwd_fit  = Fwd_fit; 
    SW_out_tmp.alpha    = prob.SW.alpha;
    SW_out_trad         = SW_out_tmp;
    SW_out_trad.fwd_fit = Fwd_fit; 
    SW_out_trad.alpha   = prob.SW.alpha;
    SW_out_trad.nCoupon = coupon_freq;
end

%% Reorganising output
%
curve_    = [ SW_out_trad.tau_fit SW_out_trad.y_fit.*100];
forward_  = [ SW_out_trad.tau_fit SW_out_trad.fwd_fit.*100];
alpha_fit = [ SW_out_trad.alpha ];
tot       = [curve_ forward_(:,2) [alpha_fit;zeros(length(curve_)-1,1)] ];

SW_out_trad.curve_    = curve_;
SW_out_trad.forward_  = forward_;
SW_out_trad.alpha_fit = alpha_fit; 

if ( plotting_==1 )
    figure
    titlen=['Calculated Discount Curve - with alpha= ', num2str(alpha_fit)];
    plot(curve_(:,1), curve_(:,2)), title(titlen), xlabel('Maturity (years)'),ylabel('Rate in %')
    
    figure
    titlen=['Calculated Discount and Forward Curves - with alpha= ', num2str(alpha_fit) ];
    plot(curve_(:,1), [curve_(:,2) forward_(:,2) ]), title(titlen), xlabel('Maturity (years)'), ylabel('Rate in %')
    legend('Discount Curve','Forward Curve','Location','SouthEast')
    
    figure
    titlen = ['Calculated Discount Curve and Input Swap Data'];
    indx_  = find( curve_(:,1)==SwapData(end,1) );
    plot(curve_(1:indx_,1), curve_(1:indx_,2)), title(titlen), xlabel('Maturity (years)'),ylabel('Rate in %')
    hold on
    plot(SwapData(:,1), SwapData(:,2),'ro-'), legend('Discount Curve','Swap Data','Location','SouthEast')

    scrsz   = get(0,'ScreenSize');
    p1      = [100 scrsz(4)/3 scrsz(3)/2.60 scrsz(4)/2];
    p2      = [20 20 scrsz(3)/2.85 scrsz(4)/2.2];
    f       = figure('Position', p1);
    cnames  = {'Maturity','Dicount Curve','Forward Curve', 'Alpha' };
    cformat = {'numeric', 'numeric', 'numeric', 'numeric' };
    t       = uitable('Parent',f,'Data',tot,'ColumnName',cnames,'ColumnFormat',cformat,'Position',p2);
            
 end
    
