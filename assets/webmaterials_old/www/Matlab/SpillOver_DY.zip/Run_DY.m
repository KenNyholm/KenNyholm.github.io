%% Run the Diebold Yilmaz function 
%

% Load data
load('diebold_yilmaz.mat')
dat_ = returns;

% Inputs to the SpillOver_DY function are: SpillOver_DY(VAR_lag, nMA_lags, data, plot_)
%
nObs = length(returns);
[ Out_, Spill_indx, IRF_o, IRF_g, V_decom_o, V_decom_g ] = SpillOver_DY(2, 4, dat_, 0);

%% Rolling Window calculations
%
WL      = 104;
x_start = [ 1:1:nObs-WL+1 ]';
x_slut  = [ WL:1:nObs ]';
n_iter  = length(x_start);
indx_   = zeros(n_iter,1);

h = waitbar(0,'Iterating, please wait...');
for ( j=1:n_iter )
    waitbar(j/n_iter,h)
    [ Out_, Spill_indx, IRF_o, IRF_g, V_decom_o, V_decom_g ] = SpillOver_DY(2, 4, dat_(x_start(j,1):x_slut(j,1),:), 0);
    indx(j,1) = Spill_indx(2,1);
end
close(h)
figure
plot(indx)