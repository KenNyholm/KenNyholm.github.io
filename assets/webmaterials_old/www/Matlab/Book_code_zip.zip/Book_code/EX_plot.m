function [] = EX_plot(zz,yy,xx)
%
% Function that plot 2 and 3 dimentional graphs 
%  on the basis of user input
%
% input
%   zz   - data to be plottet (nObs-by-nSeries)
%   yy   - y axis data (nObs-by-1, or left empty for 2D plot)
%   xx   - x axis data (nSeries-by-1)
%
if ( nargin==3 )
    figure
    surf(xx,yy,zz)
elseif ( nargin==2 ) 
    figure
    plot(yy,zz)
else
    disp('please provide data for plotting')
end
