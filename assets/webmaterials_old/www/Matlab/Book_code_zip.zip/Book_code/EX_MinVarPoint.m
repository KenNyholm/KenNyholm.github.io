%
% Chapter: Asset Allocation
%
%   Example that shows the efficient frontier and calculates the minimum
%   variance portfolio
%
% date: October 2006
% report bugs to: email@kennyholm.com
%

% --- Example of symbolic calculations of the minimum variance portfolio
syms x y z r ic i f;
f    = 1/(x*z-y^2)*(x*ic*i-y*ic*r)+1/(x*z-y^2)*(z*ic*r-y*ic*i)*(y/z);
simplify(f)

% --- Confirming the above using numbers ---

% --- Input values ---
r   = [ 3.25; 5.75; 7.5; 12.3 ];      
C   = [ 25.0 24.5 33.0 37.5;  
24.5 49.0 50.0 63.0;
33.0 50.0 121.0 66.0;
37.5 63.0 66.0 225.0 ];
one = ones(4,1);
% --- Doing the calculations ---
w_mvp    = inv(C)*one./(one'*inv(C)*one)
sig_mvp = sqrt(w_mvp'*C*w_mvp)
r_mvp    = w_mvp'*r


