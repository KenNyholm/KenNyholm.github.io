function [out_] = my_fun(x,k,a1,a2)
out_ = k+a1.*x+a2.*x.^2;
