function varargout = NelsonSiegelExample(varargin)
% NELSONSIEGELEXAMPLE M-file for NelsonSiegelExample.fig
%      NELSONSIEGELEXAMPLE, by itself, creates a new NELSONSIEGELEXAMPLE or raises the existing
%      singleton*.
%
%      H = NELSONSIEGELEXAMPLE returns the handle to a new NELSONSIEGELEXAMPLE or the handle to
%      the existing singleton*.
%
%      NELSONSIEGELEXAMPLE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NELSONSIEGELEXAMPLE.M with the given input arguments.
%
%      NELSONSIEGELEXAMPLE('Property','Value',...) creates a new NELSONSIEGELEXAMPLE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before NelsonSiegelExample_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to NelsonSiegelExample_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help NelsonSiegelExample

% Last Modified by GUIDE v2.5 15-Oct-2007 10:23:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @NelsonSiegelExample_OpeningFcn, ...
                   'gui_OutputFcn',  @NelsonSiegelExample_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before NelsonSiegelExample is made visible.
function NelsonSiegelExample_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to NelsonSiegelExample (see VARARGIN)

% Choose default command line output for NelsonSiegelExample
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes NelsonSiegelExample wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = NelsonSiegelExample_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in plot_curve.
function plot_curve_Callback(hObject, eventdata, handles)
% ... Organising data 
handles   = guidata(hObject);
Lambda    = handles.Lambda;
Level     = handles.Level;
Slope     = handles.Slope;
Curvature = handles.Curvature;
% ... Constructing NS curve and sensitivities
nTau = 120;
tau  = [1:1:nTau]';
H    = [ ones(nTau,1) (1-exp(-Lambda.*tau))./(Lambda.*tau) ...
                      (1-exp(-Lambda.*tau))./(Lambda.*tau)-exp(-Lambda.*tau) ]; 
Y    = H*[Level;Slope;Curvature];
% ... Plotting results
axes(handles.axes1_loading_structure);  % Plot for H matrix
plot(H);
axis([1 120 0 1.2]);
set(gca,'XTick',[12:24:120]);
axes(handles.axes2_Yield_Curve);        % Plot for Y
plot(Y,'LineWidth',2);
axis([1 120 0 Level+1]);
set(gca,'XTick',[12:24:120]);


function edit1_Callback(hObject, eventdata, handles)
handles.Lambda = str2double(get(hObject,'String'));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
handles.Level = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
handles.Slope = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
handles.Curvature = str2double(get(hObject,'String'));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%
%
% ... END OF THE PART OF THE GUI THAT PLOTS THE NS CURVE
%
%

% --- Executes on button press in Estimate.
function Estimate_Callback(hObject, eventdata, handles)
% hObject    handle to Estimate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%
% EXTRACTING DATA
%
handles            = guidata(hObject);
uitable_lambdas    = str2double(cell(handles.uitable_lambdas.getData));
uitable_maturities = str2double(cell(handles.uitable_maturities.getData));
uitable_Yields     = str2double(cell(handles.uitable_Yields.getData));
tst                = get(handles.Estimate_panel,'SelectedObject');
Estimate_          = get(tst,'String');

[nObs nMaturities] = size(uitable_Yields);
if ( strcmp(Estimate_, 'Factors') )
    [Beta,u,Res,optim ] = NS_gui_code(uitable_Yields, uitable_maturities, uitable_lambdas, 0);
 %...
 %... Constructing Output
 %... 
 %... Betas
    c_Beta=corr(Beta);   
    figure; plot(Beta); title('Estimates factors'); xlabel('Obs#'); ylabel('Value'); 
    figure; 
    uitable(Beta, {'Level', 'Slope', 'Curvature'}, 'Position', [10 30 270 350]);
    uicontrol('Style','text','String','Factors', 'Position', [70 385 80 15]);    
    
    uitable(c_Beta, {'Level', 'Slope', 'Curvature'}, 'Position', [300 310 250 70]);
    uicontrol('Style','text','String','Correlation of factor', 'Position', [330 385 200 15]);

 %... residuals
    c_u = corr(u);
    m_u = mean(u);
    figure; surf(u); title('Residuals'); xlabel('Maturity#'); ylabel('Obs#'); zlabel('Value');
    for ( j=1:nMaturities )
        colnames(1,j) = cellstr(strcat('Res_tau ', num2str(j)));
    end
    figure; uitable(u, colnames, 'Position', [50 30 450 350]);
    uicontrol('Style','text','String','Residuals', 'Position', [180 385 80 15]);    
    figure; uitable(c_u, colnames, 'Position', [50 180 450 160]);
    uicontrol('Style','text','String','Correlation of Residuals', 'Position', [150 345 280 15]);    
    figure; bar(m_u); title('Average Residuals'); xlabel('Maturity#');
else
    [Beta,u,Res,optim] = NS_gui_code(uitable_Yields, uitable_maturities, uitable_lambdas, 1);
 %...
 %... Constructing Output
 %...
    figure; plot(Res(:,2),Res(:,1)./nObs); title('Sum Resid^2'); xlabel('Lambda'); ylabel('Squared error'); 
    optimal_L     = cellstr(strcat('Optimal Lambda= ', num2str(Res(optim,2))));
    uicontrol('Style','text','String',optimal_L, 'Position', [150 345 280 15]);    
end


% --- Executes on button press in Populate_Input_Area.
function Populate_Input_Area_Callback(hObject, eventdata, handles)
% hObject    handle to Populate_Input_Area (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles     = guidata(hObject);
nMaturities = handles.nMaturities;
nYields     = handles.nYields;

dat_mat         = nan(nMaturities,1);
dat_Y           = nan(nYields,nMaturities);
dat_lambda_full = nan(1,3);
for ( j=1:nMaturities )
    colnames(1,j) = cellstr(strcat('Y_tau ', num2str(j)));
end
% ... populate input area
uicontrol('Style','text','String','Enter Lambda', 'Position', [315 260 80 15]);
uitable_lambdas    = uitable(dat_lambda_full, {'Lambda', 'Lower', 'Upper'}, 'Position', [310 220 250 35]);
uicontrol('Style','text','String','Enter Maturities', 'Position', [315 195 80 15]);
uitable_maturities = uitable(dat_mat, {'tau'}, 'Position', [310 40 105 150]);
uicontrol('Style','text','String','Enter Yields', 'Position', [600 195 100 15]);
uitable_Yields     = uitable(dat_Y, colnames,'Position', [430 40 385 150]);

handles.uitable_lambdas    = uitable_lambdas;
handles.uitable_maturities = uitable_maturities;
handles.uitable_Yields     = uitable_Yields;
guidata(hObject,handles)

function edit5_Callback(hObject, eventdata, handles)
%
handles.nMaturities = str2double(get(hObject,'String'));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function edit6_Callback(hObject, eventdata, handles)
%
handles.nYields = str2double(get(hObject,'String'));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%
%
% ... END OF THE PART OF THE GUI THAT ESTIMATES NS FACTORS
%
%
