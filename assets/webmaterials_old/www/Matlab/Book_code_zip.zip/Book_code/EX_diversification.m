%
% Chapter: Asset Allocation
%
%   Example that shows the effect of portfolio diversification
%
% date: October 2006
% report bugs to: email@kennyholm.com
%

% --- Input parameters ---
nObs = 100;
bgn  = 2;
xx   = (bgn+1:1:nObs)';
temp = tril(rand(nObs,nObs));
temp = temp+temp';
std  = rand(nObs,1)+1;
corr = temp-diag(diag(temp))+diag(ones(nObs,1));
cov  = (std*std').*corr;
for ( j=1:nObs-bgn )
    C           = cov(1:j+bgn,1:j+bgn);
    w           = 1/j.*ones(j+bgn,1);
    sig2(j,1) = w'*C*w; 
end
sig2pct = sig2./sig2(1,1).*100;
figure
plot(xx,sig2pct),xlabel('Number of assets in portfolio'),...
           ylabel('Risk %');