function [out] = bond(in)
%
% Chapter: Risk and Return 
%
%  Calculates the price, modified duration and convexity of a coupon bond
%          having annual payments
%
%  Usage:
%       [out] = bond(in)
%
%  in (structure):
%       .Y    - yield of the bond 1-by-1  e.g. 0.053 = 5.3%       
%       .C    - coupon of the bond 1-by-1 e.g. 5 (=5% bond) 
%       .N    - years to maturity 1-by-1  e.g. 2.5 (=2 years and 6 months)
%  out (structure):
%       .P    - Price of the bond
%       .MD   - Modified duration of the bond
%       .Conv - Convexity of the bond
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
y    = in.Y; c = in.C; n = in.N;
p    = c/y*( 1-1/(1+y)^n ) + 100/(1+y)^n;
md   = 1/p*( c/y^2*(1-1/(1+y)^n) - n/(1+y)^(n+1)*(100-c/y) );
conv = (1/p)*(1/(1+y)^2*( (n+1)*n/(1+y)^n*(100-c/y) - 2*c/(1+y)^(n-2)*(1/y^3 + n/((1+y)*y^2)) ) + 2*c/y^3);
out.P=p; out.MD=md; out.Conv=conv;  
