%
% Chapter: Econometric Tools
%
%   Example that shows how to estimate the Nelson-Siegel model
%       by linear regresison
%
%       Y=H*beta+e
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
Res  = [];
Y    = [2.17 2.47 2.85 3.39 4.01 4.31 ... 
             4.48 4.58 4.65 4.70 4.74 4.77 4.79]';
tau  = [1 3 6 12 24 36 48 60 72 84 96 108 120]';
nObs = length(Y);
for ( k=1:50 )
    L = k/200+0.01;
    H = [ones(nObs,1) ...
          (1-exp(-L.*tau))./(L.*tau) ...
              (1-exp(-L.*tau))./(L.*tau)-exp(-L.*tau)];
    Beta = H\Y;               
    u        = Y-H*Beta;              
    stderr   = sqrt( diag ((u'*u)/(length(Y)-4)*pinv(H'*H) ));  
    Sum_u2   = sum(u.^2);
    Res(k,:) = [ Sum_u2 Beta' L stderr' ];
end
optim = find(Res(:,1)==min(Res(:,1)));
disp('Optimal Nelson-Siegel parameters & standard errors')
disp('--------------------------------------------------')
disp('    Level    Slope     Curvature   Lambda')
disp(Res(optim,2:end-3))
disp(Res(optim,end-2:end))
