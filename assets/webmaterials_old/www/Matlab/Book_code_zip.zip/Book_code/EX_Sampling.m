%
% Sampling example
%
clear all;
warning off all
nObs    = 250;
nIter   = 500;
a       = 0.99;
f       = zeros(nObs,1);
g       = zeros(nObs,1);   %  
C       = [ 18.6 15.6 17.9 15.8 11.3;
            15.6 21.4 19.6 19.9 10.9;
            17.9 19.6 36.3 28.2 15.8;
            15.8 19.9 28.2 35.8 16.1;
            11.3 10.9 15.8 16.1 38.6 ];
w       = [ 0.51; 0.29; 0.00; 0.02; 0.18 ];
iShift  = -10;
%
% Calc theoretical VaR
%
VaR_base = -norminv(a)*sqrt(w'*C*w);
ES_base  = exp(-(norminv(a)^2)/2)/((1-a)*(2*pi)^0.5)*sqrt(w'*C*w);
ES_S     = zeros(nIter,2);
%
% simulating portfolio returns
%
for ( j=1:nIter )
    D_ratio   = zeros(nObs,1);
    disp( sprintf('Percentage completed %3f', 100*j/nIter) )
    eps1       = randn(nObs,length(C))*chol(C);
    rp         = eps1*w;
    rp_IS      = (eps1+iShift)*w;
    for ( k=1:nObs )
        f(k,1) = exp(-0.5* ( rp_IS(k,1)^2/(w'*C*w) ) );         % unshifted
        g(k,1) = exp(-0.5* (( (rp_IS(k,1)+iShift)-mean(rp_IS(:,1)+iShift) )^2/(w'*C*w) ) ); % shifted
    end
    ES_S(j,1)  = -mean([rp<=VaR_base].*rp) * 1/(1-a);
    ES_S(j,2)  = -mean([rp_IS<=VaR_base].*rp_IS .* (f./g) ) * 1/(1-a) ;
end
disp('Means')
mean(ES_S)
disp('Variances')
var(ES_S)
disp('Theoretically calculated expected shortfall')
ES_base
figure
subplot(1,2,1), plot(ES_S(:,1),'k-'), title('Standard Estimate'), axis( [0 nIter 0 max(ES_S(:,1))] )
subplot(1,2,2), plot(ES_S(:,2),'k-'), title('Importance Sampling Estimate'), axis( [0 nIter 0 max(ES_S(:,1))] )
