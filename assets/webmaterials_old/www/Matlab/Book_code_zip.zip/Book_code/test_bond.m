%
% Test of the bond pricing function:
%      

%...Sensitivities... 
c = 15;     % coupon 
n = 10;     % maturity
a_ = c/2;
b_ = c+a_;
s_ = (b_-a_)/1000;
k  = 1;
for ( j=a_:s_:b_ )
    in.Y      = j/100;
    in.C      = c;
    in.N      = n;
    [out]     = bond(in);
    res_(k,:) = [ in.Y in.C in.N out.P out.MD out.Conv ]; 
    k = k+1;
end
figure
subplot(3,2,1:2), plot(res_(:,1),res_(:,4)), title('price to yield')
subplot(3,2,3), plot(res_(:,1),res_(:,5)), title('MD to yield')
subplot(3,2,4), plot(res_(:,4),res_(:,5)), title('MD to price')
subplot(3,2,5), plot(res_(:,1),res_(:,6)), title('Conv to yield')
subplot(3,2,6), plot(res_(:,4),res_(:,6)), title('Conv to price')
