%
% Example that illustrates the use of 3-dimentional matrices and 
%   indexed structures to store data
%
clear all;
for (j=1:10000)
    rdim         = floor(rand()*20)+1; 
    ex_dat1      = randn(rdim,5);
    ex_dat2      = randn(5,5);
    struct.A{j}  = ex_dat1;
    Mat3D(:,:,j) = ex_dat2; 
end