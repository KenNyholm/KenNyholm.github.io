%
% Calculating the closed form expression for Vasicek(1977) model  
%
% The following notation is used:
%              dr = k(theta-r) dt + s dz  and p is market price of risk
%
% Plotting a Vasicek yield curve
%
tau  = (1:1:60)';
nTau = length(tau);
p=0.20; s=0.25; k=0.30; theta=5; r=4;
y_inf = theta - p*s/k - s^2/(2*k^2);
% Calculate A, B and the yield curve
B = (exp(-k.*tau)-1)./k;
A  = B.*(((p*s)/k)-theta) - theta.*tau + (p.*s.*tau)./k + ...
         (s^2/(4*k)).*( -(B.^2) + ...
              (2*exp(-k.*tau)-2)./(k^2) + (2.*tau)./k );
y = -(1./tau).*(A+B.*r);
figure;
plot(tau,y)

% Loop to illustrate inverse and upward sloping curves
y_inf = theta - p*s/k - s^2/(2*k^2);
z = 1;
for ( r=y_inf-1:0.05:y_inf+1 )
    Y_(:,z) = -(1./tau).*(A+B.*r);
    r_(z,1) = r;
    z = z+1;
end
figure
surf(r_,[1:1:60]',Y_), xlabel('Starting rate'), ylabel('Maturity (months)'), zlabel('yield (%)')



