%
% Chapter: Risk and Return
%
%   Example that shows how to calculate the yield of different bonds
%
% date: January 2007
% report bugs to: email@kennyholm.com
%
k  = (1:1:5)';
P  = [100.00; 99.50; 93.75; 89.45; 91];
CF = [105.0 0.0 0.0 0.0 0.0;
      5.5 105.5 0.0 0.0 0.0;
      4.0 4.0 104.0 0.0 0.0;
      3.5 3.5 3.5 103.5 0.0;
      4.5 4.5 4.5 4.5 104.5 ];
%... Calculating spot rates 
D = inv(CF)*P;
R = D.^(-1./k)-1;
%... Calculating Forwards
F = ((1+R(2:end,1)).^k(2:end,1)./(1+R(1:end-1,1)).^k(1:end-1,1))-1;
F = [R(1,1);F];
%... Calculating Yields
for ( j=1:5 )
    in.P  = P(j,1);
    in.CF = CF(j,1:j);
    in.t  = (1:1:j)';
    [out] = price2yield(in);
    yield(j,1)=out.Y;
end

[yield R F]