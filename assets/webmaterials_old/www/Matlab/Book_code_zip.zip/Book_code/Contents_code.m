%
% Overview of the matlab code used in the course
%
% Disclaimer:
%   All code and examples are are provided 'as is' without warranty of
%   any kind (what so ever). In particular, it is not guaranteed that the 
%   code is error free, efficiently programmed or that the results of the 
%   code meet your requirements. 
%   Code and examples can be used free of charge and can be amended 
%   if needed. Please acknowledge the origin of the code, should you  
%   choose to use it.  
%
% Bug reports:
%   Please report bugs to email@KenNyholm.com      
%
% File/Function                   Description:
% ============================================
%   bond.m                      - Function that calculates the price, 
%                                   modified duration, convexity of a bond
%
%   frontier.m                  - Function that calculates the efficient 
%                                   portfolio frontier
%
%   frontier_1.m                - As above but should work in version prior 
%                                   to 7.x                 
%
%   ols_est.m                   - Function that estimates a linear
%                                   regression
%
%   price2yield.m               - Function that estimates the bond yield
%
%   regime.m                    - Function that estimates regime-switching
%                                   models
%       regime_likeli.m         -       used by regime.m
%       regime_normaldensity.m  -       used by regime.m
%       regime_pmat.m           -       used by regime.m
%
%   var_p.m                     - Function that estimates a VAR(p) model
%       var_p_lik.m             -       used by var_p.m
%
%   test_bond.m                 - Provides a test of bond.m
%
%   Ex_randn.m                  - Example that plots a matrix of normally 
%                                   distributed random numbers 
%
%   EX_BondPriceSensitivity.m   - Example that calculates bond prices for
%                                   different levels of yields
%
%   EX_chol.m                   - Example that illustrates the cholesky
%                                   decomposition
%
%   EX_dist.m                   - Example plot normal distributions
%
%   EX_diversification.m        - Example that shows the effect of
%                                   portfolio diversification
%
%   EX_frontier_fx.m            - Example that shows how the frontier.m
%                                   function can be used
%
%   EX_likeli_1.m               - Example that shows likelihood estimation
%                                   of a linear regression
%
%   EX_MinVarPoint.m            - Example that shows the efficient frontier
%                                   and calculates the minimum variance 
%                                   portfolio
%
%   EX_NS.m                     - Example that shows how to estimate the 
%                                   Nelson-Siegel model by OLS
%
%   EX_plot.m                   - Example that shows how to create a
%                                   function that produces 2 and 3 
%                                   dimentional plots of data
%
%   EX_regime.m                 - Example that estimates a regime switching
%                                   model
%
%   EX_return.m                 - Example returns for fixed income
%                                   securities using the pricing function
%                                   and the taylor series approximation
%
%   EX_RiskMeasures.m           - Example that calculates risk measures 
%                                   (VaR and expected shortfall)
%
%   EX_sim.m                    - Example that shows how to simulate a
%                                   linear autoregression allowing for 
%                                   parameter and innovation uncertainty
%
%   EX_YieldCalc.m              - Example that shows how to calculate the
%                                   yield of different bonds
