%
% Example to plot a vector of random numbers
%
r = randn(10,1);
plot(r,'ko')
xlabel('Observation number')
ylabel('Value')
