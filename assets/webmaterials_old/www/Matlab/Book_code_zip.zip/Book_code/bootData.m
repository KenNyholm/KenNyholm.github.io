function [ out ] = bootData(in)
%
% function to bootstrap data
%
% inputs:
%         in.dat    - original data
%         in.nDraws - number of data points generated
%
% output:
%         out.Sdat  - resampled data
%
dat_         = in.dat;
nDraws       = in.nDraws;
[nObs nVars] = size(dat_);
z            = randi(nObs,nDraws,1);
out.Sdat     = dat_(z,:);
