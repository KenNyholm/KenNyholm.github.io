%
% This example file illustrates 
%     (1) the time varying nature of the inputs to the
%     portfolio optimisation exercise (mean hist return and cov mat), and thus
%     that care should be exercised when choosing how to generate expected
%     returns and covariances for the purpose of portfolio optimisation.
%
%     Historical returns (averages) and the historical covariances are 
%     calculated for an example data set on a rolling-window basis. For
%     each sub-sample of data, the efficient frontier and its composition 
%     is shown.
%
%     (2) that the efficient frontier is time varying
%
%     (3) that the return distributions are time varying
%
%     (4) how to resample the efficient frontier
%
%     (5) a simulation based example 
%
% Input: Dat - data matrix (nObs x nAssets)
%
% Date  : October 2009
% Author: Ken Nyholm
%

%%
% ----- Loading data for the analyses of historical properties of returns -----
%  US Srate, US Bond, Equity DE, Equity US, Equity AZ
%  coverage 1977 - 2009, monthly data
load('Dat1.mat');

%% 
%
% -----  Time varying returns and Covariances -----
%
step_      = 120;                                                           % Specify calculation window [ obs ]
step_size  = 3;                                                             % 
[ nObs nAssets ] = size(Dat);
temp_dat_1 = Dat(1:step_,:);
temp_dat   = [ temp_dat_1 ; zeros(nObs-step_,nAssets) ];
xx         = (1:1:nObs)';
zz         = zeros(nObs,1);
avg_dat    = mean(temp_dat_1).*12;
C          = corr(temp_dat_1);
corr_dat   = triu(corr(temp_dat_1)).*(triu(corr(temp_dat_1))<1);
std_dat    = std(temp_dat_1);
one        = ones(nAssets,1);

scr_sz = get(0,'ScreenSize');
figure('Position',[scr_sz]);
h0 = subplot(3,1,1), plot(xx,Dat, ':b'), title('Total data series'), xlabel('Time'), ...
%set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'}), set(gca,'XTick',[0 36 156 276 384]);
set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'},'XTick',[0 36 156 276 384]);
hold on;
h1 = subplot(3,1,1), plot(xx,temp_dat,'-k','LineWidth',2,'YDataSource','temp_dat');

h2 = subplot(3,1,2), bar(avg_dat,'YDataSource','avg_dat'), title('Expected return'), xlabel('Asset Class'), ylim([-5 20]),...
set(gca,'XTickLabel',{'US Srate','US Bond', 'Equity DE','Equity US', 'Equity AZ'}, 'XTick',[1 2 3 4 5]);

h3 = subplot(3,1,3), bar(corr_dat,'YDataSource','corr_dat'), title('Upper triangular of corr matrix'), xlabel('Asset Class'), ylim([-1 1]),...
set(gca,'XTickLabel',{'US Srate','US Bond', 'DE Equity','US Equity ', 'AZ Equity'},'XTick',[1 2 3 4 5]);
pause
for ( ii = 1:step_size:nObs-step_ )
    temp_dat_1 = Dat(ii:ii+step_,:);
    avg_dat    = mean(temp_dat_1).*12;
    C          = corr(temp_dat_1);
    corr_dat   = triu(corr(temp_dat_1)).*(triu(corr(temp_dat_1))<1);
    std_dat    = std(temp_dat_1);
    temp_dat   = [ zeros(ii-1,nAssets); temp_dat_1 ; zeros(nObs-ii-step_,nAssets) ];
    
    refreshdata(h0,'caller'); drawnow;
    hold on;
    refreshdata(h1,'caller'); drawnow;
    refreshdata(h2,'caller'); drawnow;
    refreshdata(h3,'caller'); drawnow;
    pause(.2);
end
%%
%
% ----- Time varying return distributions -----
%
step_      = 120;                                                           % Specify calculation window [ obs ]
step_size  = 3;                                                             % 
[ nObs nAssets ] = size(Dat);
temp_dat_1 = Dat(1:step_,:);
temp_dat   = [ temp_dat_1 ; zeros(nObs-step_,nAssets) ];
xx         = (1:1:nObs)';
zz         = zeros(nObs,1);
one        = ones(nAssets,1);

scr_sz = get(0,'ScreenSize');
figure('Position',[scr_sz]);
h0 = subplot(3,1,1), plot(xx,Dat, ':b'), title('Total data series'), xlabel('Time'), ...
%set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'}), set(gca,'XTick',[0 36 156 276 384]);
set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'},'XTick',[0 36 156 276 384]);
hold on;
h1 = subplot(3,1,1), plot(xx,temp_dat,'-k','LineWidth',2,'YDataSource','temp_dat');

[usL2, usL1] = hist(temp_dat_1(:,2),15);
[usE2, usE1] = hist(temp_dat_1(:,4),15);
usL2      = usL2./length(temp_dat_1);
usE2      = usE2./length(temp_dat_1);
usL2_norm = pdf('norm',usL1,mean(temp_dat_1(:,2)),std(temp_dat_1(:,2)));
usE2_norm = pdf('norm',usE1,mean(temp_dat_1(:,4)),std(temp_dat_1(:,4)));
usL2_norm = usL2_norm./sum(usL2_norm); 
usE2_norm = usE2_norm./sum(usE2_norm);

h2 = subplot(3,1,2), plot(usL1,usL2,'XDataSource','usL1','YDataSource','usL2'), title('US long rate'), ...
                            xlabel('Return'), ylabel('Frequency'), xlim([-20 20]), ylim([0 0.5]);
hold on
h4 = subplot(3,1,2), plot(usL1,usL2_norm,':r','XDataSource','usL1','YDataSource','usL2_norm','LineWidth',2);

h3 = subplot(3,1,3), plot(usE1,usE2,'XDataSource','usE1','YDataSource','usE2'), title('US Equity'), ...
                            xlabel('Return'), ylabel('Frequency'), xlim([-20 20]), ylim([0 0.5]);
hold on
h5 = subplot(3,1,3), plot(usE1,usE2_norm,':r','XDataSource','usE1','YDataSource','usE2_norm','LineWidth',2);
                        
pause
for ( ii = 1:step_size:nObs-step_ )
    temp_dat_1 = Dat(ii:ii+step_,:);
    temp_dat   = [ zeros(ii-1,nAssets); temp_dat_1 ; zeros(nObs-ii-step_,nAssets) ];

    [usL2, usL1] = hist(temp_dat_1(:,2));
    [usE2, usE1] = hist(temp_dat_1(:,4));
    usL2=usL2./length(temp_dat_1);
    usE2=usE2./length(temp_dat_1);
    usL2_norm = pdf('norm',usL1,mean(temp_dat_1(:,2)),std(temp_dat_1(:,2)));
    usE2_norm = pdf('norm',usE1,mean(temp_dat_1(:,4)),std(temp_dat_1(:,4)));
    usL2_norm = usL2_norm./sum(usL2_norm); 
    usE2_norm = usE2_norm./sum(usE2_norm);

    refreshdata(h0,'caller'); drawnow;
    hold on;
    refreshdata(h1,'caller'); drawnow;
    refreshdata(h2,'caller'); drawnow;
    refreshdata(h3,'caller'); drawnow;
    pause(.1);
end


%%
%
% ----- Time varying efficient frontier -----
%
step_      = 120;                                                           % Specify calculation window [ obs ]
step_size  = 12;                                                             % Obs added and excluded from the window at each iteration
[ nObs nAssets ] = size(Dat);
temp_dat_1 = Dat(1:step_,:);
temp_dat   = [ temp_dat_1 ; zeros(nObs-step_,nAssets) ];
xx         = (1:1:nObs)';
zz         = zeros(nObs,1);
avg_dat    = mean(temp_dat_1).*12;
CC         = cov(temp_dat_1).*12;
one        = ones(nAssets,1);

% ... Estimating the efficient frontier for the 1st sample
in.C  = CC;
in.R  = avg_dat(:);
in.B  = [zeros(nAssets,1) ones(nAssets,1)];
in.G  = []; 
in.GB = [];
in.N  = 10;
[ out ] = frontier_1( in );
RiskRetX = out.RR(:,1);
RiskRetY = out.RR(:,2);
Weights = out.W;

scr_sz = get(0,'ScreenSize');
figure('Position',[scr_sz]);
h0 = subplot(3,1,1), plot(xx,Dat, ':b'), title('Total data series'), xlabel('Time'), ...
set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'},'XTick',[0 36 156 276 384]);
hold on;
h1 = subplot(3,1,1), plot(xx,temp_dat,'-k','LineWidth',2,'YDataSource','temp_dat');

h2 = subplot(3,1,2), plot(RiskRetX,RiskRetY, 'LineWidth',3,'XDataSource','RiskRetX','YDataSource','RiskRetY'), title('Efficient Frontier'), xlabel('Stdev'),...
              ylabel('E[r]'), xlim([0 25]), ylim([0 20]);

h3 = subplot(3,1,3), bar(Weights,'stack','YDataSource','Weights'), title('Portfolio Weights'), .... 
    xlabel('Point on Efficient Frontier'), ylim([0 1]), legend('US Srate','US Bond', 'DE Equity','US Equity ', 'AZ Equity'), ...
    set(gca,'XTickLabel',{'1','2', '3','4', '5', '6' ,'7', '8','9', '10' }, 'XTick',[1 2 3 4 5 6 7 8 9 10]);

pause
for ( ii = 1:step_size:nObs-step_ )
    temp_dat_1 = Dat(ii:ii+step_,:);
    avg_dat    = mean(temp_dat_1).*12;
    C          = cov(temp_dat_1).*12;
    temp_dat   = [ zeros(ii-1,nAssets); temp_dat_1 ; zeros(nObs-ii-step_,nAssets) ];
    
    in.C  = C;
    in.R  = avg_dat(:);
    in.B  = [zeros(nAssets,1) ones(nAssets,1)];
    in.G  = []; 
    in.GB = [];
    in.N  = 10;
    [ out ] = frontier_1( in );
    RiskRetX = out.RR(:,1);
    RiskRetY = out.RR(:,2);
    Weights = out.W;
    
    refreshdata(h0,'caller'); drawnow;
    hold on;
    refreshdata(h1,'caller'); drawnow;
    refreshdata(h2,'caller'); drawnow;
    refreshdata(h3,'caller'); drawnow;
    %pause(.5);
end



%%
%
%  ----- Resampling the efficient frontier -----
%  
%
randn('seed',1);
iteri      = 10;                          % number of times the frontier is resampled
step_      = 120;                         % Specify calculation window [ obs ]
step_size  = 24;                          % Obs added and excluded from the window at each iteration
[ nObs nAssets ] = size(Dat);
temp_dat_1 = Dat(1:step_,:);
temp_dat   = [ temp_dat_1 ; zeros(nObs-step_,nAssets) ];
xx         = (1:1:nObs)';
zz         = zeros(nObs,1);
avg_dat    = mean(temp_dat_1).*12;
C          = cov(temp_dat_1).*12;
one        = ones(nAssets,1);

% ... Estimating the efficient frontier for the 1st sample
in.C = C;
in.R  = avg_dat(:);
in.B  = [zeros(nAssets,1) ones(nAssets,1)];
in.G  = []; 
in.GB = [];
in.N  = 10;
[ out ] = frontier_1( in );
RiskRetX = out.RR(:,1);
RiskRetY = out.RR(:,2);
Weights  = out.W;

scr_sz = get(0,'ScreenSize');
figure('Position',[scr_sz]);
h0 = subplot(3,2,[1 2]), plot(xx,Dat, ':b'), title('Total data series'), xlabel('Time'), ...
set(gca,'XTickLabel',{'1977','1980','1990','2000','2009'},'XTick',[0 36 156 276 384]);
hold on;
h1 = subplot(3,2,[1 2]), plot(xx,temp_dat,'-k','LineWidth',2,'YDataSource','temp_dat');

h2 = subplot(3,2,3), plot(RiskRetX,RiskRetY, 'LineWidth',3,'XDataSource','RiskRetX','YDataSource','RiskRetY'), title('Efficient Frontier'), xlabel('Stdev'),...
              ylabel('E[r]'), xlim([0 25]), ylim([0 20]);

h3 = subplot(3,2,4), bar(Weights,'stack','YDataSource','Weights'), title('Portfolio Weights'), .... 
    xlabel('Point on Efficient Frontier'), ylim([0 1]), legend('US Srate','US Bond', 'DE Equity','US Equity ', 'AZ Equity'), ...
    set(gca,'XTickLabel',{'1','2', '3','4', '5', '6' ,'7', '8','9', '10' }, 'XTick',[1 2 3 4 5 6 7 8 9 10]);

resamplX = RiskRetX;
resamplY = RiskRetY;
resamplW = Weights;

h4 = subplot(3,2,5), plot(resamplX, resamplY, 'LineWidth',3,'XDataSource','resamplX','YDataSource','resamplY'), ... 
                          title('Resampled Efficient Frontier'), xlabel('Stdev'),...
                          ylabel('E[r]'), xlim([0 25]), ylim([0 20]);
h5 = subplot(3,2,6), bar(resamplW,'stack','YDataSource','resamplW'), title('Resampled Portfolio Weights'), .... 
    xlabel('Point on Efficient Frontier'), ylim([0 1]), legend('US Srate','US Bond', 'DE Equity','US Equity ', 'AZ Equity'), ...
    set(gca,'XTickLabel',{'1','2', '3','4', '5', '6' ,'7', '8','9', '10' }, 'XTick',[1 2 3 4 5 6 7 8 9 10]);

pause
for ( ii = 1:step_size:nObs-step_size )
    temp_dat_1 = Dat(ii:ii+step_,:);
    avg_dat    = mean(temp_dat_1).*12;
    C          = cov(temp_dat_1).*12;
    temp_dat   = [ zeros(ii-1,nAssets); temp_dat_1 ; ...
                   zeros(nObs-ii-step_,nAssets) ];
    
    in.C = C;
    in.R  = avg_dat(:);
    in.B  = [zeros(nAssets,1) ones(nAssets,1)];
    in.G  = []; 
    in.GB = [];
    in.N  = 10;
    [ out ] = frontier_1( in );
    RiskRetX = out.RR(:,1);
    RiskRetY = out.RR(:,2);
    Weights = out.W;
    
    for ( jj = 1:iteri )       
        r_sample_      = ceil(step_.*rand(step_+1,1));
        temp_dat_s     = temp_dat_1(r_sample_,:); 
        avg_dat        = mean(temp_dat_s).*12; 
        CC             = cov(temp_dat_s).*12;
        one            = ones(nAssets,1);
        R_holder(:,jj)    = avg_dat;
        CC_holder(:,:,jj) = CC;
         
        % ... Estimating the efficient frontier for the 1st sample
        in.C    = CC;
        in.R    = avg_dat(:);
        in.B    = [zeros(nAssets,1) ones(nAssets,1)];
        in.G    = []; 
        in.GB   = [];
        in.N    = 10;
        [ out ] = frontier_1( in );
        RiskRetX_s(:,jj) = out.RR(:,1);
        RiskRetY_s(:,jj) = out.RR(:,2);
        Weights_s(:,:,jj)= out.W;
    end

    resamplW         = mean(Weights_s,3);
    for ( kk=1:in.N )
        %tempR_s(:,kk) = resamplW(kk,:) * mean(R_holder,2);
        %tempS_s(:,kk) = resamplW(kk,:) * mean(CC_holder,3) * resamplW(kk,:)';
        tempR_s(:,kk) = resamplW(kk,:) * mean(temp_dat_1)'.*12;
        tempS_s(:,kk) = resamplW(kk,:) * (cov(temp_dat_1).*12) * resamplW(kk,:)';
    end
    
    resamplX = sqrt(tempS_s');
    resamplY = tempR_s';
    
    refreshdata(h0,'caller'); drawnow;
    hold on;
    refreshdata(h1,'caller'); drawnow;
    refreshdata(h2,'caller'); drawnow;
    refreshdata(h3,'caller'); drawnow;
    refreshdata(h5,'caller'); drawnow;
    refreshdata(h4,'caller'); drawnow;
    
    %pause(.5);
end
%%
% ----- Loading data for the factor analysis -----
% US yields 3	6	12	24	36	60	84	120 months maturity, SPX Index DAX Index
% coverage 1970 - 2008, monthly observations
%load('Dat2.mat');

%%
%
%  ----- Examining the factor structure of data -----
%  

sim_obs  = 12;
sim_iter = 10000;
tau_     = [ 3;12;120 ];
n_tau    = length(tau_);
lambda   = 0.08;

C=[ 0.0049   -0.0045   -0.0038    0.0017    0.0029    0.0010    0.0002   -0.0024 0.0012 0.0077;
   -0.0045    0.0055    0.0012   -0.0015   -0.0017   -0.0002    0.0001    0.0011 0.0030 0.0020;
   -0.0038    0.0012    0.0072   -0.0020   -0.0039   -0.0017   -0.0005    0.0034 0    0;
    0.0017   -0.0015   -0.0020    0.0025    0.0000   -0.0008    0.0000    0.0000 0    0;
    0.0029   -0.0017   -0.0039    0.0000    0.0038    0.0010   -0.0001   -0.0021 0    0;
    0.0010   -0.0002   -0.0017   -0.0008    0.0010    0.0027    0.0003   -0.0023 0    0;
    0.0002    0.0001   -0.0005    0.0000   -0.0001    0.0003    0.0012   -0.0012 0    0;
   -0.0024    0.0011    0.0034    0.0000   -0.0021   -0.0023   -0.0012    0.0034 0    0;
    0.0012    0.0030    0         0         0         0         0         0      0.01 0;
    0.0077    0.0020    0         0         0         0         0         0      0    0.02 ];
[CC r] =chol(C);

FC =  diag([1.2;0.3;0.2;2.1]);
G = [ ones(n_tau,1) (1-exp(-lambda.*tau_))./(lambda.*tau_) (1-exp(-lambda.*tau_))./(lambda.*tau_)-exp(-lambda.*tau_) zeros(n_tau,1);
         0.5/12 0 0 0.7;
         0.4/12 0 0 0.6];
     
F = [ 0.98 0.00 0.00 0.00;
      0.00 0.90 0.00 0.00;
      0.00 0.00 0.65 0.00;
      0.00 0.00 0.00 0.90 ];
  
m = ([7.00 -1.5 0.10 1]*(eye(4)-F))';
beta(:,1) = [ 7; -2.0; 0.35; 1 ];

for ( zz=1:sim_iter )
    errs   = (randn(sim_obs,4)*chol(FC))';
    errs_R = randn(1,5).*[0 1.5 4 0 0]; 
    for ( jj=2:sim_obs )
        beta(:,jj) = m + F*beta(:,jj-1) + errs(:,jj);  
    end
    Y   = (G*beta)';
    R = ([prod((1+Y(:,1:3)./1200)) prod(1+Y(:,4:5)./100)]-1).*100+errs_R;
    R_tot(zz,:) = R;
end
figure
hist(R_tot(:,1),50), title('Bond 3M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,2),50), title('Bond 12M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,3),50), title('Bond 120M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,4),50), title('EQ US'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,5),50), title('EQ DE'), xlabel('Return'), ylabel('Frequency');

% portfolios to be evaluated
w = [ 0.20 0.20 0.20 0.20 0.20 ;
      1.00 0.00 0.00 0.00 0.00 ;
      0.00 1.00 0.00 0.00 0.00 ;
      0.00 0.00 1.00 0.00 0.00 ;
      0.00 0.00 0.00 1.00 0.00 ;
      0.00 0.00 0.00 0.00 1.00 ;
      0.80 0.10 0.10 0.00 0.00 ;
      0.70 0.10 0.10 0.10 0.00 ;
      0.70 0.00 0.00 0.15 0.15 ;
      0.60 0.10 0.10 0.10 0.10 ;
      0.50 0.50 0.00 0.00 0.00 ;
      0.40 0.40 0.20 0.00 0.00 ;
      0.40 0.10 0.10 0.20 0.20 ;
      0.40 0.30 0.20 0.10 0.00 ;
      0.20 0.30 0.30 0.20 0.00 ;
      0.10 0.10 0.10 0.70 0.00 ;
      0.00 0.50 0.00 0.50 0.00 ;
      0.00 0.25 0.25 0.50 0.00 ;
      0.00 0.00 0.20 0.40 0.40 ;
      0.00 0.00 0.10 0.45 0.45 ;
      0.00 0.00 0.00 0.50 0.50 ];
  
[ n_ps junk ] = size(w);
sum_sim       = zeros(n_ps,2);
crit_obs      = floor(sim_iter*0.05);
for ( zz=1:n_ps )
    p_ret = sort(R_tot*w(zz,:)');
    ES    = mean(p_ret(1:crit_obs,1));
    ER    = mean(p_ret);
    sum_sim(zz,:) = [ES ER];
end
[sort_ES, II] = sort(sum_sim(:,1));
sort_R = sum_sim(II,2);

figure
subplot(3,1,1), plot(sort_R,'-*','LineWidth',3), title('Portfolio Return')
subplot(3,1,2), bar(sort_ES), title('Expected Shortfall 95% level');
subplot(3,1,3), bar(w(II,:),'stack'),legend('Bond 3M', 'Bond 12M', 'Bond 120M', 'EQ US', 'EQ DE'), title('Portfolio Weights') 

