%
% Chapter: Risk and Return
%
%   Example that calculates bond prices for different levels of yields
%
% date: November 2006
% report bugs to: email@kennyholm.com
%
Bond1 = [ 3 3 3 3 103 ];
Bond2 = [ 3 3 3 3 3 3 3 3 3 103 ];
Bond3 = [ 15 15 15 15 115 ];
Bond4 = [ 15 15 15 15 15 15 15 15 15 115 ];
pt1   = [1:5]';
pt2   = [1:10]';
P1 = 0; P2 = 0; P3 = 0; P4 = 0;
for ( j=1:300 )
    y  = j/1000;
    D1 = (1./(1+y).^pt1).*ones(5,1);
    D2 = (1./(1+y).^pt2).*ones(10,1);
    P1(j,1) = Bond1*D1;
    P2(j,1) = Bond2*D2;
    P3(j,1) = Bond3*D1;
    P4(j,1) = Bond4*D2;
end
xx = [0.1:0.1:30]';
figure
plot(xx,P1,'k')
hold on; plot(xx,P2,'k:')
hold on; plot(xx,P3,'k')
hold on; plot(xx,P4,'k:'), xlabel('Rate %'), ylabel('Price')