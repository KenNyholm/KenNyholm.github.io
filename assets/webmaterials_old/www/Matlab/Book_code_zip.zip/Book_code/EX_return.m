%
% Example of calculating returns for fixed income securities
%
% This script applies 3 ways to approximate returns:
%       a) using formula (2.20) on page 49 of the lecture notes
%              i.e. the difference in prices
%       b) using formula (2.12) on page 46 of the lecture notes
%              i.e. the taylor series approximation
%       c) log(p_{t}/p_{t-1}) i.e. as (a) but without maturity shortening
%
% Input:
%       y     - vector of yields for which returns should be calculated
%       tau   - maturity for the yield i.e. the maturity of the bond index for
%                 which returns are calculated in months
%       freq  - observation frequency for yield vector in months 
%                 e.g. =1 if monthly observation frequency 
%       c     - coupon for the bond index (=-1 means that the yield at t-1 
%                 is used according with an assumption that the index 
%                 consists of par bonds at each point in time when it 
%                 is priced) 
%   
clear DP_a Ret_a DP_b Ret_b DP_c Ret_c diff_DP diff_Ret diff_Ret_c;
cc     = -1;
freq   = 1;
nObs   = length(y);
p_t    = zeros(nObs-1,1);
p_tp1  = zeros(nObs-1,1);
Coupon = zeros(nObs-1,1);
MD     = zeros(nObs-1,1);
Conv   = zeros(nObs-1,1);
Dy     = (y(2:end,1)-y(1:end-1,1))./100;
%
%...Calculating prices, Modified duration and Convexity
%
for ( j=1:nObs-1 )
    in_t.Y   = y(j,1)/100;
    in_tp1.Y = y(j+1,1)/100;
    if ( cc==-1 )
        in_t.C   = y(j,1);
        in_tp1.C = y(j,1);
    else
        in_t.C   = cc;        
        in_tp1.C = cc;
    end
    in_t.N      = tau/12;
    in_tp1.N    = (tau-freq)/12;
    [out_t]     = bond(in_t);
    [out_tp1]   = bond(in_tp1);
    p_t(j,1)    = out_t.P;
    p_tp1(j,1)  = out_tp1.P;
    Coupon(j,1) = in_t.C;    
    MD(j,1)     = out_t.MD;
    Conv(j,1)   = out_t.Conv;
end
DP_a     = (p_tp1-p_t)./p_t;
Ret_a    = DP_a + Coupon./1200; 
DP_b     = -MD.*Dy+1/2.*Conv.*Dy.^2;
Ret_b    = DP_b + Coupon./1200;
DP_c     = log(p_tp1(2:end,1)./p_tp1(1:end-1));
Ret_c    = DP_c + Coupon(1:end-1)./1200;
diff_DP  = DP_a-DP_b; 
diff_Ret = Ret_a-Ret_b;
diff_Ret_c = Ret_a(2:end)-Ret_c;
figure
subplot(3,2,1), plot(DP_a), title('Price changes method a')
subplot(3,2,2), plot(Ret_a), title('Returns method a')
subplot(3,2,3), plot(DP_b), title('Price changes method b')
subplot(3,2,4), plot(Ret_b), title('Returns method b')
subplot(3,2,5), plot(diff_DP), title('Price changes method a minus b')
subplot(3,2,6), plot(diff_Ret), title('Returns method a minus b')
figure
subplot(3,1,1), plot(DP_c), title('Price changes method c')
subplot(3,1,2), plot(Ret_c), title('Returns method c')
subplot(3,1,3), plot(diff_Ret_c), title('Returns method a minus c')
