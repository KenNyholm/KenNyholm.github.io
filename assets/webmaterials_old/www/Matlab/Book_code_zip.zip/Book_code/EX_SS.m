%
% Chapter: Econometric Tools
%
%   Example that shows how to estimate the Sevnsson-Soderlind model
%       by linear regresison
%
%       Y=H*beta+e
%
% date: August 2009
% report bugs to: email@kennyholm.com
%
warning off
Res  = [];
Y    = [2.17 2.47 2.85 3.39 4.01 4.31 ... 
             4.48 4.58 4.65 4.70 4.74 4.77 4.79]';
tau  = [1 3 6 12 24 36 48 60 72 84 96 108 120]';
nObs = length(Y);
z = 1;
for ( j=1:200)
        L2 = j/400+0.01;
    for ( k=1:50 )
        L1 = k/200+0.01;
        G = [ones(nObs,1) ...
              (1-exp(-L1.*tau))./(L1.*tau) ...
              (1-exp(-L1.*tau))./(L1.*tau)-exp(-L1.*tau) ...
              (1-exp(-L2.*tau))./(L2.*tau)-exp(-L2.*tau)];
        alpha    = G\Y;               
        u        = Y-G*alpha;              
        stderr   = sqrt( diag ((u'*u)/(length(Y)-4)*pinv(G'*G) ));  
        Sum_u2   = sum(u.^2);
        Res(z,:) = [ Sum_u2 alpha' L1 L2 stderr'];
        z=z+1;
    end
end
optim = find(Res(:,1)==min(Res(:,1)));
disp('       Optimal Svensson-Soderlind parameters & standard errors')
disp('       ----------------------------------------------------------------')
disp('       Level       Slope        Curvature1    Curvature2     Lambda1     Lambda2')
disp(Res(optim,2:end-4))
disp(Res(optim,end-3:end))
