%
% Example of symbolic calculations in Matlab
%    Calculating first and second derivatives of the affine bond pricing equation 
%

syms r P A B t;

P = exp(A+B*r);
disp('first derivative of P with respect to r')
diff(P,r)
disp('second derivative of P with respect to r')
diff(diff(P,r))
