%
% Chapter: Risk and Return
%
%   Example that shows how to calculate the yield of different bonds
%
% date: October 2006
% report bugs to: email@kennyholm.com
%
j  = (1:1:5)';
P  = [100.00; 99.50; 93.75; 89.45; 91];
CF = [105.0 0.0 0.0 0.0 0.0;
      5.5 105.5 0.0 0.0 0.0;
      4.0 4.0 104.0 0.0 0.0;
      3.5 3.5 3.5 103.5 0.0;
      4.5 4.5 4.5 4.5 104.5 ];
D = inv(CF)*P;
R = D.^(-1./j)-1;
for ( j=1:5 )
    in.P  = P(j,1);
    in.CF = CF(j,1:j);
    in.t  = (1:1:j)';
    [out] = price2yield(in);
    yield(j,1)=out.Y;
end
[yield R]