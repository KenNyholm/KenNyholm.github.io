%
%  plot of distributions
%
if (1)
    mu = [0 0];
    V  = [1 1.2; 1.2 4];
    x1  = (-4:0.1:4)';
    x2  = (-7:0.1:7)';
    z1  = pdf('norm', x1, mu(1,1), sqrt(V(1,1)));
    z2  = pdf('norm', x2, mu(1,2), sqrt(V(2,2)));
    R   = mvnrnd(mu',V,10000);
    RR  = mvnpdf(R, mu, V);
    figure
    subplot(2,1,1), plot(x1,z1,'k-');
    hold on
    subplot(2,1,1), plot(x2,z2,'k-');
    subplot(2,1,2), plot3(R(:,1),R(:,2),RR,'k.')
    view([0 90])
end
x = (-25:.01:8)';
y = pdf('ev',x,-1,3);
plot(x,y,'k-','linewidth',2)
sum(x'*y./sum(y))