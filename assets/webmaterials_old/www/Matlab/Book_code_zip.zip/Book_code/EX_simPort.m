%%
%
%  ----- Simulating a factor model and test portfolios for optimisation -----
%  

sim_obs  = 12;
sim_iter = 10000;
tau_     = [ 3;12;120 ];
n_tau    = length(tau_);
lambda   = 0.08;

C=[ 0.0049   -0.0045   -0.0038    0.0017    0.0029    0.0010    0.0002   -0.0024 0.0012 0.0077;
   -0.0045    0.0055    0.0012   -0.0015   -0.0017   -0.0002    0.0001    0.0011 0.0030 0.0020;
   -0.0038    0.0012    0.0072   -0.0020   -0.0039   -0.0017   -0.0005    0.0034 0    0;
    0.0017   -0.0015   -0.0020    0.0025    0.0000   -0.0008    0.0000    0.0000 0    0;
    0.0029   -0.0017   -0.0039    0.0000    0.0038    0.0010   -0.0001   -0.0021 0    0;
    0.0010   -0.0002   -0.0017   -0.0008    0.0010    0.0027    0.0003   -0.0023 0    0;
    0.0002    0.0001   -0.0005    0.0000   -0.0001    0.0003    0.0012   -0.0012 0    0;
   -0.0024    0.0011    0.0034    0.0000   -0.0021   -0.0023   -0.0012    0.0034 0    0;
    0.0012    0.0030    0         0         0         0         0         0      0.01 0;
    0.0077    0.0020    0         0         0         0         0         0      0    0.02 ];
[CC r] =chol(C);

FC =  diag([1.2;0.3;0.2;2.1]);
G = [ ones(n_tau,1) (1-exp(-lambda.*tau_))./(lambda.*tau_) (1-exp(-lambda.*tau_))./(lambda.*tau_)-exp(-lambda.*tau_) zeros(n_tau,1);
         0.5/12 0 0 0.7;
         0.4/12 0 0 0.6];
     
F = [ 0.98 0.00 0.00 0.00;
      0.00 0.90 0.00 0.00;
      0.00 0.00 0.65 0.00;
      0.00 0.00 0.00 0.90 ];
  
m = ([7.00 -1.5 0.10 1]*(eye(4)-F))';
beta(:,1) = [ 7; -2.0; 0.35; 1 ];

for ( zz=1:sim_iter )
    errs   = (randn(sim_obs,4)*chol(FC))';
    errs_R = randn(1,5).*[0 1.5 4 0 0]; 
    for ( jj=2:sim_obs )
        beta(:,jj) = m + F*beta(:,jj-1) + errs(:,jj);  
    end
    Y   = (G*beta)';
    R = ([prod((1+Y(:,1:3)./1200)) prod(1+Y(:,4:5)./100)]-1).*100+errs_R;
    R_tot(zz,:) = R;
end
figure
hist(R_tot(:,1),50), title('Bond 3M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,2),50), title('Bond 12M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,3),50), title('Bond 120M'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,4),50), title('EQ US'), xlabel('Return'), ylabel('Frequency');
figure
hist(R_tot(:,5),50), title('EQ DE'), xlabel('Return'), ylabel('Frequency');

% portfolios to be evaluated
w = [ 0.20 0.20 0.20 0.20 0.20 ;
      1.00 0.00 0.00 0.00 0.00 ;
      0.00 1.00 0.00 0.00 0.00 ;
      0.00 0.00 1.00 0.00 0.00 ;
      0.00 0.00 0.00 1.00 0.00 ;
      0.00 0.00 0.00 0.00 1.00 ;
      0.80 0.10 0.10 0.00 0.00 ;
      0.70 0.10 0.10 0.10 0.00 ;
      0.70 0.00 0.00 0.15 0.15 ;
      0.60 0.10 0.10 0.10 0.10 ;
      0.50 0.50 0.00 0.00 0.00 ;
      0.40 0.40 0.20 0.00 0.00 ;
      0.40 0.10 0.10 0.20 0.20 ;
      0.40 0.30 0.20 0.10 0.00 ;
      0.20 0.30 0.30 0.20 0.00 ;
      0.10 0.10 0.10 0.70 0.00 ;
      0.00 0.50 0.00 0.50 0.00 ;
      0.00 0.25 0.25 0.50 0.00 ;
      0.00 0.00 0.20 0.40 0.40 ;
      0.00 0.00 0.10 0.45 0.45 ;
      0.00 0.00 0.00 0.50 0.50 ];
  
[ n_ps junk ] = size(w);
sum_sim       = zeros(n_ps,2);
crit_obs      = floor(sim_iter*0.05);
for ( zz=1:n_ps )
    p_ret = sort(R_tot*w(zz,:)');
    ES    = mean(p_ret(1:crit_obs,1));
    ER    = mean(p_ret);
    sum_sim(zz,:) = [ES ER];
end
[sort_ES, II] = sort(sum_sim(:,1));
sort_R = sum_sim(II,2);

figure
subplot(3,1,1), plot(sort_R,'-*','LineWidth',3), title('Portfolio Return')
subplot(3,1,2), bar(sort_ES), title('Expected Shortfall 95% level');
subplot(3,1,3), bar(w(II,:),'stack'),legend('Bond 3M', 'Bond 12M', 'Bond 120M', 'EQ US', 'EQ DE'), title('Portfolio Weights') 
